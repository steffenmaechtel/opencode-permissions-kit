-- MariaDB dump 10.19-11.8.8-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	11.8.8-MariaDB-ubu2404-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1787421183,1787421183,0,0,0,0,2,'{\"7ae937749804f816ba10a93778568060c9e77e20\":{\"identifier\":\"t3information\"},\"09822459ec512739d85bb1b9102e49fd7ad3bb68\":{\"identifier\":\"docGettingStarted\"}}','76b15a27e9ed88119251f0cea8b44a2e7b451002','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('2c0022a273c7a258ea532a21645eef09d9cf3caa83af3a4173f05931f782abd0','[DISABLED]',2,1787421188,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"04a2d8fd95a0515df3bcb8c6d6e15ff0491de63977476e5836875353240074c9\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1787420770,1787420770,0,0,0,0,NULL,'a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\"}',0,NULL,'','_cli_','$argon2id$v=19$m=65536,t=16,p=1$MUo5ckxZdDNLQ0RUWU9hUw$9wH4GQa9bAJrRJtppJS4Yq/6fM+Bnso56Ao7n0TDaPI','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL),
(2,0,1787420770,1787420770,0,0,0,0,NULL,'a:5:{s:10:\"moduleData\";a:2:{s:28:\"dashboard/current_dashboard/\";s:40:\"76b15a27e9ed88119251f0cea8b44a2e7b451002\";s:10:\"web_layout\";a:3:{s:8:\"viewMode\";i:1;s:10:\"showHidden\";b:1;s:9:\"languages\";a:1:{i:0;i:0;}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:2:{s:28:\"dashboard/current_dashboard/\";s:40:\"9706fc8e62fc0a8644145f09e15cb5e8a7c13217\";s:10:\"web_layout\";s:40:\"9706fc8e62fc0a8644145f09e15cb5e8a7c13217\";}}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\"}',0,NULL,'','admin','$argon2i$v=19$m=65536,t=16,p=1$Q1pYaE94aUJENkczVGtTTg$H37OMDuTwbv8pTnuBIkXfbrDmmzIMySqoB3hZOoYAI0','',0,NULL,'','admin@localhost','',1,3,NULL,1,'en',NULL,'',NULL,'',1787421183,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'1_85e239543ee49ee9',1818957190,'x����vG�%:�O���\03#�e�=.���%[Sr��=5K�$� �@�꾽�}�y���1or���ODd�%ٖ�r���E�W|�8g�}NDfLd���o�����������Ń�}���W�n�;�QU탣���/&_��ӏ�������O����u����\\7��^��^v�i2��n�������l������h������Xl���v����Z��6�<9}���/�d�,V۫�f�:O���ղKv�d�����M��M�%�n�l�כY�L��ɓ�\nݺ�Ϗ7����z�\r\n]����e2�tӝ�����U�I�}3�n.�L��y�\\̺�ׯWs\\���ߝ|���xP�l}�r�8��%Y�6#��*Y��.l�|�-��]�Wh��<��w�b�l:<2�-nБ�n�E5���֛��ϩ=�����N�0��탓��˫u>^o�O�� ����e��dz�X�$��ቝ}φeq<::�P�t��%~�Y�&O4��{o݋��f7���b��x4�n ����xG��t�=��鑚�\\��I.��b���?J.6�٣����-�c{rV�Ϻl>oڳ�����j�|���|V�y{2�nO.���x���SV7U���͏ �壣����^t���ދu��l�Z�hQ�w&��HOLg���P�%Z���rٍfS��rDM�<\n����h��?:��?_��_y�<��ݡ���t����|=x��Y�����yb#q��)z�Q��Q�A����GGi�&�����b	���ǿ��}��Q���r�\n�NЦ/^�_�:�4MOP���^Mw���ѓ��E�Ey���-ڬ-g�l��uQd�q:�ǥ��\"oF�\"/�:�G�7�i��򴬪\"ï¹�̪����q�eu��Wڦ�Ó��UU���U�<���uY4�kPFY5y����.w��QuQ���\\9.�:O�\Z�s㬪�ֹq�fyU;4.��j���K���]��:kkT=n��9ǖW�t�9��fU���j�\\\rQ��iXX>nr6����y���۴���mi�\\�\'!��pe�Ec�x{U5�)��YT9��U{��y�6����eަո�kWT�j#I��k][�{��b!��PHӌ���\\�;+I{�4��\rR��3�`���G%v��|ѤelD[6i����\\���˜c[�0m���U�21Tåt1Ί2�\n�ƮI�6h�u�Qv)��渑cl�-/�]�kf�1�I�Ө�S6��Y�8�8U6YZ�T]�%Z�?u*���b�JI���z[�-+�\r��Ң����q�6iQ��a�2��A��\"u9dQ���\n�{YTПQ�x0�\"kU0zӘ��򲈦pu��T\\6�������\n\"�J5Qw+��S�!ն���A��S�:�_F\\em��\n�3�+\n�D��jGG���1����i�5̵nZH�������*�q�v�|PIV��k\Zru�j��y��\r�8k9��L���EeDu�W�����Y¤�lX[�-��V�7��e�\ZQp�4���\Z�`C�X_D��m� �V�{��a-��!�L�«	>�o�\Z�T�g���W�b3�P���4m9��N]8P+Za�\ZZ\r7͛���Zi��Ը�ښ�u�ƌ�\Z��@H�P��`�g�4fXOo����˼$F�i�;�t^��ܵTz��ؔ��À�\n\n�P��U]a\\�Qo�d�b����U�Sk�2m���\0Td�,�n1�ո�i\Z����x����a7�Ft��p�룓�f]�M�ä�\0mS���z�Er೐l]	gb�d|���l9������Xø���.ӳ�h��Ӑ��=ˉJm��q��T����l�l#Br�C��	*���1#�r�.X)O�Ap]NZ�]��b\Z!S�WY\n9��5u\n�\0��s�K���ǎJ����aٶo_��p���%�E�`hr$\"-�;�a�@NI[�2�>��{�޳���{�Nܣ{,�\\���J[X�Q�-����P~Fd��Y]&�á1��EmF�y`��^���П�lj��{R_Pʋ��[�Vf�-�\Z�3M\0j�c��2y�#��,H\\�&/�ft��-IUٶrॠ����_^W,\\�/Kh]��8�e�b	L��݀BhŌ��W��0������\r�Dp ���P�eQs`�K6�T	�i��6���	���C%�p7���e3\Z��݈솨�{t[��7d�\'G��;\Z��K֟�������&��zҒ��c�Ӫ�	�p	�ǆ�y]v0�qZ��J$5�\"���4��#N�])\'dW((K��\\���G,��p�\nۑ7�I���5��o@>�@dM�2B|��٭�Z`h1���ǰV���(���9aʵ�գ��zzL��@��d�	C�@j�qL����	$�N�,��^%�*(��o�v<�����d~y�zʔ��CV�ܠ?`㩈q8�\r�S�73�[!Q�b!��(T�(��y(Da�<#��x����\"��Mj.`2~8aS$�������t�(��*ϱŝY�\"a��\0>O&46�(���c-��|�jG��![]�Q�4�����t`l�i4F���Ҽ�,��1h\r�\\���{�_�^7{Hm�	�b�%5���E9&�>�g �/��E�t���ʂħt>no�3F���Ң��\r�_����I� l��!��#y��U�^A�Z�>�\n���SZR��첢%K��83�\"D��1��y�}<n��+3\"�H��+�ly�g\"��QA<pF�G��c-�[��\n�{�JQ�l\Z�\'�\"+�c�b���\\dY2dp�L2`���Q����N�2M����5��!x࿩�6�n��Z���������Yt*��|!�	��H�c��\Z=�ے�3��Pg�q֣����\\���4�.4B�GN���1[xR�:���ԧq(c<G$Q9�Q���!3!f S\0zy3��A�H+�Q0��1	zԫz��>���Є`(y!(\r-\rz�-4o�Q�����b:��}���By�p��Or�6��m�ny�Y:��4�P!�m}z~RZ�<\n^]�|�H��]\rR~�ǊjMoS��5��\r�|�UX5�HBS��Q��$S����\Z�1�	r�X�\"��3U����r�5Ӕ	�&W��Qwi�*U�<*.�i��x��L���T	��0.I\"����%����\Z�\" Rt@�;_�A�-Gy�Mf�\nV8ܐH�\\�-��2*[�S�꣎�z&Q�f�Շ�5�.B�eLВD�͎���6���y��կCv�V�ܧ!�v�����=��&�I�ao-V�xk��&��@��y��ĕ�X}�Ԍ���F��l<c�C>�Ml����[ܺg�Qo*m�\'�6n�lܲ�c�E�TZ��;�@����p*jgZ����4%��n�0��$�3�GN!w�����\0�P��o+p6�G{H>�4���H�gT}x�S�i�>E30t/������`�65-�����)�q��M���#70�;2u����M�L=(����xy�b�h��`�D�m9l���o��ǦJJI2��YG������ٳ���T�\"�����z��_Z���� _若ݻ��6���߽x��5{7w4�w�n���yw�x$�D��R�G�}� 2ﭘ�q�=���qoʴez��ڊ�ՖYy��X*fH���ِj�+�Sm��w������)��6�?�k[jg��%�=����������!\'�v�{�Gͱl�8��������\rL�ִ沟(9d�~�x`�1�<�HK�\r<rL+�#b%e{&�؃Ե\'ݦ7o̺3�,�8+س&)hV�-�شK���~KS���1C2!�;�2��9���������)�0A\'A�c�z+��9%a��\\e_��˱@E��!�۽\r.��������u�U�&�Ig�F��c`�����q�mg^���o\nޡ�O��9�m�2��ׄ�>-�ĴDVx�p�@�W\Z\r|XA sP9F�!�7Nm,�����Z,m���\Z�W��>=\"��C��]!��ZW��F5�T�b�zy��6f\n��!�\'��\'1��llc\0�i<M\\Cs��w8\'�Ye��ȩ\n�!FЪm�Ƨ�XY�6�����l�A�[����dk�- .�h��4J�n�ڂ�LC�6���)�@,�����ɲB��,�\0	3	�1_��~X���䔭�ob+������V!��8�����ͤ2ʘ�7d>�m��1BoPQAHˀȽ�C�t\n?���L\'m�o`:�Mt��0��fL\'��\'C���8`:����8����1\r�؃����w�أ�I���%gPqs}kaD�WE��`-����I�\".�0��y13H�!N�DT��+��>K�\0�\"��M��G8�3Q�mǖ����o�d�����>Y1�9D���]:�s��fq�L��%��8�%ܿ� ̧i��q̥˖,(�h��ؓQX��9B?ûL(�Q��Bf���4\'-I���2D$�af�3۩��8�Q&���{��`\nV�W�X�KkQE\\w����d���0����R\'gD�sL%�?������;q�l�[���	�^qa�q��/�\r��A�Ns���T�Ih���\n����P���̄n(\r�3��픞�&�g��u��\'LA��C1VN�p�}<l�?�\n��\ZiM�C����mR�+�����T\n��Z�B~�?�Gr<����v!;ΡA�A�x�Oq��*ÿT���\\&�Ba���\Z��R����b:)<;+mڶ�B[I$`�`o<�MYgU��(,�#��Pf��sUTi+,�P�(JѶ��tWWG\r��a~�r(<=��YS+@aU��RA�)����*��JN���J=�՜��A�jr�^� �uy\r�i�!dʕ0�T�DHl�O��ԇ�Kiw�����ӫr�&H��MifQlXz����,js$Ru�\rw�46�<8���������A�L��Cq�Fa��8���ι�\'�C7H6๊�ft�A�Eu�T\\���\Za�hu��x��q\r8d�ma\"t��Y+j8�\Z \Z׵����K(S��J\rg\"*���n�S%����Z���EITZ���rv%�BCR�֣���b��k1	N��-F����,3ΘAZ��R��24�\'�{�֪mPΊ�[-@oK�F��2qY��+N{6���4��\Z@Kg�!0V�h���sY�������P\rz��B�}N��\\}O�El\0̈́\Z)���e!0\0mO�6R�u�%Y1�m�+���Xx�J��mj�\Z4\"�(77�X�JPF^��*��@���3�1�������뇀(�Lj$��M�	;+���Q�+Z�^��R�\"�Ca�\\�&��t(GPK�8�#�K@��5\\�~�s-���U$\Z���Y.�6݄VW(E4��2q�䫘�O��8�jf��d\"ޤ�/��B�z�v(e��>7��\rcP���]�ت�r{�#�U���hc���-���	�\0וN@㙝�N)�\"*\0W�0��ㆂeu2Q�yVCN\\Ȏ��/V�S^�C&\r�Oc�8�J�8�W\'�-�VJ�P�-8���]��D�]��`�eړ�ʔ�mC��ƴ9��X\\�]\'�X��\0�u\n̩*������fĶ`{-#1�@�8z�\'�cQ�A���n���D��/�}��̘�4 �B:�S,m.�L}ⱖ��6�ӷ�.�Tr�U�(rɹ2̧az�&��%1��P3���� \n�W���N���.	�@CE@�����9�|��2��e�%���]���F�مRzK*]�(m��X.��	t)/8����B��R.gH���C��)�Q	�@\0��W\\\"F�J\\���8�	��eZx�Ɯ�Q��2%��M�x\nrkhQ�IL���\":ExC�wv�$��|�;����#�@�S$p�p̦��ߚ�G�\Z�Y/�J�f�<r:��BX7NCk[NC�|���HfZ�͚�[.��L��2z��-�d7Ж�:���a���Xo�\0�N��I�Vx���BhL�@��r��J^�����^S�޴�T�J�D��pײ�<�x\"@�Y��Kez(R����,�x�X#�B��|��Bf��敏<Z��k���N��.�@\0끟j�\n�,���*��o�@Pu�۔�A~/=r����*KCf�\n�3��V�U\r�x��9� �A�G�[�\0����3�r��@���0-P�	�hF��٠���[-�Y����h��\0�i�<��������0��l�ha�;1:�pmG���]�a�x .X�	!�R^��^�-�i_h�l�a�h=:W1���\\�_��Wp�\"Xo\0ɤ���`3[�N *5\0 �ԡ<r�vo<\0̀u�B(L[pL\0�\0|u��d�PMK�~�-\"���.����mYX\r���_�\rE�m\n�9��㵘C�׋@��:�)AK�*T&�wt@S��`�����X�Y��4Gw2R�Rת�Ok�0̀3��\rs��V�U*bLz��\n��Ś�n�����i�;����hq}\r�e\"�њ��#Ї����!W��^K�\\X����\r�ʰ����O�����-�1$Q/�Gvz��Db�)A�P�\n֛I\"���B$�~�Y��\n�J!֬`Y�����-\"��ͲA�x@��a��!�c�zg���2E��I�J�I-Vi8Cn����$&�?υw^�\"��^�`H�7ȈM��&\Z4p��|D-�\'�쏹��B���F��uJ�3�\"���v�->R��\Z	oO��8G\0vʌ<F��Řcp��h�g�M/K��Q���p���dNw�Np��J7��+��ǣ��[e̟d>��H��B�xY�Ϡ}~6����3q�@!Li3>׸L��{��\Z����z%;�|��{%Pe��#BP)����(ė�B2>��c�\0e�A�M�-5~�Un�\0E���	P�PN��S��J�.:����k\"\"��b:�\n���� ��bv�js�bO��B1oi`Hї�k�ۆ��7\'iu5\'w9��xj�ޓ��|�L�Y�����Qx�b:N���3l����d�h��w�*��Z���Z][f�����\\���O/�[�fzHK[�gXP��j\\Q&K��-�����\0�9&F�U�e+ŋZA ��5����\Zh1���{��~K�n\0�\05d⭄�.x��)1�!!��25<�f��`\Z�.�\0��,�}k�S9��E��	���WT_�J���NK�P���ڂ�4�*IL3�D��=p��\"���s0�gXı�1�1����@�����q�ǈ`e�0�P�̥�^��!?W`�{�H8�~08:�e��nu=:���֫;[��������0\\MW�\\+\ng���1zE�<~�{��ܮ�vw����V?��	Zz������t���.�y�zt��\\w��4:�?#u�(|�\"w��)�{���KxξL�Z������-.��k�JoJVէ��ʟ���\Z�]�������yݟ���ta��O�z�{v��@��r��fy�������l��voK(\r��y���D�&�l����@rt�����8<��8��;쟎���\">\n�1�c��R�0<\Z\Z�R��Ƿ���%���]#8��U�=c�+\'<��~�Ân?����8r�,06����\\��i�\Z�K��é#ӟ���_�y2]��v�W�O����BG���>$���}A-��;Z�����Gn��h���u����\n=�RP*�U��\Z%����$>~XY��ߏ�r��]%�yer5�}�X�ۀ�� ��3�c<������O�7�������ۇ\'��CX�F�;8\0\r�N������7�e�C���\"�+˜o�W����@�w�b�&��߇�7�n۽��9ڻBT�ݶC���Gϩ��P)挧۫����w�wo���;��l���C_][/�wۮ�����!���rC�vO�G\"��8\Z�/ק�!O�=����\n��k& 9$�`I\\�\r	�@)y����>hKŴ?xF��\' KjNe&��o9�8_D�����!x�|t���Y����r��Jo�$b}U��դ �Y�78~��?ɶ��Ċl��/���-��;�3vU����7*mb��ը�?)&l��&z��`����f���|#�p��Ll�l�g�P���# 	���K\'�%��L��h��ԷʷǏL8�o�^����~�}�C���ڃ�� �\n�c�õq[�wZ�ū\r��8뜕�Y��=�+��%���ӌ���d�j�E~/-<�P ƴb�����[��.�AZM��1u��u�J�3	���):�Y��A(]+�ƲJ��5kc�&6�W�D�W|4�����l���$o�����N�B1��7e���q|4<��IC�|i�ձ�WD	⟺`ae囎�\"��)�U�ᖳ�Q���T>���\'�݌�O٩F]��16)_w�R��<*t��MTv�lsv��~N�/����L���4�I�����_u�x0W��u@\Z�CI%���VRx_�����bU�~U������վ�/������	����Y��<ބ�6��k�yT�Bj�Z�Bj��Z	�\r��wy���x|�^<Vi��ģ�Ѥ2�&T�9��¸,��(��jNZ����%���}g�R�����O���$�ؒ���R׊�Q-��:�V%�U�m�?\'�W�\r�Z\'B9��P�u�j�L��Jm��_I�qֺ�]�cQZ��ɢJ��j�����^�|_��w۪V)^J�MZ��}\"Ç���+(��� ��e�\0��}�Q����zM��#:@��r⁃�u�0�\nc����H6N8>1dgB�%����������������Z�Q�ު�����ۍ�~{\\�\n���uņ|����Dܞ�[�=�[�<�[�g0I�ǐ���&5�Di�.�K��\r4���2B��s�P��H(3������M�:���A��k����7�˳��fs\'�}s(�-r�oE�Ř���Gkj{�̞k�1m��yW�G�r~��<<1�\r�_�˃!����#^=�G��]qȔ��n.b��C��{{㋱��_o~\r]�NXDi��H�\\��F�����F��>\Z������k�{ɬ��F,#s�>��s�!�z0��_�jz3TW=�W�I1~�[��f4��Ο}��o\'�>?��+~C]�������l�	��N�GYz��ߛu����L����0v߽��}�Jܱw����<|����}!_���B�$���7P�~?]~Ïڇ,��R����[N1\nn���ӟ��koЫ����}�\n]�^����o����כU��_�/���M�yy�\\,��5����t����xru��w�j��]��w�	�g��y��5��󫠄w��߁�ܧ_ov�;���l��>_1�y�L��^�ك��+�����~�3d�#~�}t�}6�ќn�罏��4��r�s���C�o#��Q���KOr���\n�Z\\ҋ��M�����ei����b�aa��e;�������S�+��v3��%\'<P�v��j��u�m7~������������7��\\o�����~3��|~���\'���7��z��B�.�����l֍_t�WG���o����v�x�h�H������;yC��K^�Ң�73X���k�z�w�eYs�M���^ꊿZ�ͳ��us�O��������YuZ7Y9+���]��.OY\\�\'��t�Phw�9��>G�ۑBz����ٙ��-���Ʌ�=�%~��|�9�{h��I���N���-���R���\n|+2}\r�\n�b{�e�C�@\n��J�K������������X1#1+����!��V��(M�6l�&FaO2â��u�����_P�w���MN�_�+ß�!����϶�w�t7��U��W=�>��<��@��?8I������u�͊��ֺ���\nΞ���o���v��b�@��lɋ�f9��mr�����z�\\-���A�\0f;N>�%�-��3)���f�T-��n1=���f�Zov/:oVɳ+X�q��S!�����\"�\r5U�>d!�N��m��9�ݠ��$\r)=�m��6�K�a��@𭒖�����M���>��z��f��n�/��p�z�u�<��\\Y�E��geVwͩ���ȡOM*[E�ڝow��o��n�Un��gu��ܪ�L����+�N��l�Y�G|�`!*\Z��כ(pq�]L��W��dE�L��Ӧ:�Z���km�N����8���XBE>\\�?��`\Z\n���_NW�;*��ZC���5�d\Z\0�����-��}�0{ѭf�w�lwӗ[�>BCn*��V�JϠ<~�E�V�������ˉ��^�y\'�w xO�_�j�/eꚃ����z�׺��B��7�v��k�ʅZ���e\"P�:�W�x�R}����?۷�}y�ot����(pc����q�I7�]�]p��;�q���wm��f���a��Վ���f�(�l�\\�_��l\rdDq�<�\0���4���\r�v\'\nټ�.���T��4���\\��wT��Ng�&m8��K���n\'���WՓ-����ty�Z쀕�T(��o  �?3p���������K}v\Z#ӿ�{[���p�ѮGo����X��v¸팊�w<~kM����Lo�����pFU�*�����Z��i���K���Z?tPo����n�{k�i{�\r�CT�������������W����0[8�P)��PqW\Z/�3��Dq��������FO�|4�FO���_02P��;#ό����t��3�z�^��BQ�9�x�q\\D�;��r�8Eu;�].��;�P_t��������<86�\rwy����/@�_�J/�=�O!���n|�7V����ƌïE���Q��3�X����Q������O����㷞����Mﳦ;5��C�zxw��q}~�SC^����\Z�m�]�BL��b{\nc��]ka����Έ%�@���m(��O���l1pO-��Á�ngܪ�R��(5��ϲr�U/֠���XV���\"�&�M�s1H�2%,�j�f�7��ӈ��wj��v���z�g\0��v�~95,�}%ݟ�1N������w�x���w�w���2������k%���l$^)����]��u\0B}���%������\\��w���Dk�Ϝ�����癅EJ8� c����eL^����P\0\"�� h����ZxG����zT���O׋���ջ]F��8HhN���6�b-�R���|��b�@�;�\\��p<�\\���f��R�Pkk��yg�;g�qC��\0���\"�7@�ӗ!��Sp�!a��x�1<���	dB������L�*�᱁�j�G��[��P���v�	���{j�o1�進\rh_�{s��f+(��b�����y��s�uW<ۭ�B�0�4�|��߁d,�H~��߁�]��lu�$N�������bAa*�\'D��M�sb��;jcD���F\r/ְ������~�!�|�cm��-��@����G�P\Z���1��l�O�h��pz���G��C����|h�����i��}Q��g_\\,f���\\_�y���&��|��W��\ra����\Z0�֬��:����-8|�A���ϲ�x����#��x����_�Ln�S�V���b&OA��$�����]�n�ޏk��n>x2]\r-��l�8�hG���W#�����ȱz��\0�h[�_�M7�s��x����:f�7�Y\'�_�F�#ꆋ��<�����+�U5�[#��n���ȩ��Y3[\ZW�Q|\Z�+�US�Y�z���9Zss[�]����t\'D��ݠ������ܒ���]\\of�Q���M�H~ϕxɧ؎�)��1�������W����:���f}�t�Š�T���No\'����^�L����0P9��c�W\'j�^\Z��8��o/W[��e��g˗r�z�s�\\.���t����W�!��BE,�Ȃ�q��1�s�!$Z(5ݡ(�g�ʢlX���~>ի6�����a�L�����TiLA�n-Hd�,F]��BHӠUpey��d��!�rLS��)�z��gf�H��;.w�Q��,�;�2�[���;?y��e�����>���M��P�6�寧��-4޽��y�\r0ͯC�J6#O�o.��\n��.�愴V-9�^�-A���j6�<��X��\nx�K�q��K�s�D?�?�u��P�¨c��05`N������b�/��V�]�������T\rC[B$bHy0���Mw��#���X��Y�	��� �X�Н�oh��z3�iΈP,�/��l��]��-,٢�^�i-�,�j�]�E�;�+���=L)�nez�?������A��G����T��،��\\����a��-o�ϮԆ����7׫�-A}6�Zp�oq)�D��z�\0[z�M�t���.�k���A���ɇ׻��U�Ϻ�]wyJ�N������������R���l1GO�q�/f�;\\��W���m�٥q����З��������ؚ}�}�7cK�V;{@��F1}Pt�	��V�63���V\rT�lʹ��^Yp���O���O���w:6;�R��I�J���R����關�t~�w��Jc�m�D̲Y \n���:��|���;s�\'��d�^��M�����nЌ\\gz����֐[kf|�1.��j�c�^w���<�/�cd�<��G����o�_|��,n���Q���/�5#�Ԫ˽L�e(F�	37z�w��k�h~XăY��o�o|ZA1�1��ߝ�K*D�nٝA�=B{����\Z�������	:�jՆ���l1��o�D��/H�*o�YG��\r�6᝜I�ٱ�)��<5%}v�cf�uY�pf%��yɯ�w�.��߆����Q��J�)^�_�c%�:o��u9�����x+� ��4�g+�C�U���w({��e�)ʒe%�Jc}��<�eG��5��狮�&ѯK��ű%t��:���u���ˮ�YP�};����x��P0��S*�8^���,�JB�#h�����kO7��\0�²��Й�r���`Ⓡ���K���yx�^���\n�gS��~kc���9i�}W�\Z޸W��7��e2�=�3~pTT��/^�*{�>?��q,u_��B��\"JƏ��/�ŭϭ�j�����W��>:J��\\����Ճ��/^�_�cМn��O�ݖF�D[َ�B;g�97�l���q���.��8N��\Z��殐E^�u�sp���{וUUd�>�q���X�z��Ů�.�\r�-���YUeY�_U�Sو[2kWH~V��˶�N}N��Q5���㗌�<-j�΍�����E�m2�9��X[\"e�6�&-kkT���7��U�����suɽ󦩴�\\�����О��hܦ-���ȵsU����J[5Ec�x{Uq#\\������m��-���1��\\��Õ�}�6��m_�ֵ5�Ǻ�yڌ��PHӌ��Ȝ>�,is����ݯ�Z��[o�~�Q	��7<�}�c#ڲIS4<�\Z=��[�>�ܑ��P��j\\�E�K��qV��x������څZ[����W-�.��%�nh�p�L[?rTƥ�t�}tÖ���=���e��ڿ�[���]�?u*��͸Q��mU��z[�-+�\r�X�E�fé|\\�\r7,�\r����m/��E�rn��joo�{Yp��Q�x0�<|�]5SS^�����);+��zR��\"���s�^\\���U*u�[-VRg��)�˃R���U��W�+p�g�I]Q��\'���3n��\rǏ�1o�������>��v����T���g\"d��K�$��q�\rY���F6Φɲ��ȡ��q�o��v�%w��f٬�?ǖ�j+՛��2��l����h2ۦ��*�Ѡ���=��8���O��Z*�C7n[i[�|L�5�O�#��z�^�o\"��`C�@�Ӵ��:u\r�@�h�MTkn.�o#��ڰ%}05�u]�1�7�-F�%n��\n����̝��W�m��s_�|�-�r^��ܵTz��ؔ��Ðq7�P��~+{u�ۆ-�Xic�e��tyK���h�\"{g�u�M�ǅ7���Xp��B[<��UѰ�p�4UN�����0k��KI�[��ؖGʝ�z�Er�%�@������	m]�r���9F���)�6l��c��\Z;�O���iP��z?n[�\"+}��e�f���]�>�mm��Ҟ�vs��Q�e��pK�<�w�r(�Qh�L�v�FGR��B�ݿ���q�lÎJ���mg�m߾0���P��KnB�`hr$\"-��6��T$����q7i�^��l3�?<,���$���*��r\'��[�r�H����Hn(?�޾������;�̖;_�������+\0+�����-�0��4��``mwm���Oy��y�B��̟���\\C}�	�@�v,wZ#�u$������%ЌN�B�%�*�V��:�*�]o늅�e	���|�q8\n��Œ���	j#ݴ�V��I{�{�~������\r�Dp ���P�eQs`�K6�TI{L7��p��\'�J�v�}NP��!�/��\0M����+[��el��10���xr4P?��A;��d�)xY\Z�7;hb�<��\'-	J=&�K1����0	��{lX��\'���e��U\r�DR#/���A��Q�;�d���Ƃ���]� ����������Y =Qa;�6	���7nHR���D�D/#�����*����(�xk�\nJ�\"yYK���\\[��^���c�<��\'�M�p&]a�!���3�d�	��x@ѫDY�53�Mގp}�X���/�ZO�R�v�ʔ�l<1��!�08�V����E!Q�b!��(T�(��y(Da�<#�scg\'犠71���v�6�����x���<��ũ#*\n);�\n�slqg�Hw�EA �ϓ	�\r � ���A�\"(���Q�c�VEWk�)�b-=�1v\Z���-{�4o0��gZ�(W�(��ס��R�v»jI\r�.pQ·	����D�K*m(ݮ\'B�� �)�����Q�3��h-iC�ן\"�lh7�-h�.�H� zU��W���¹��<�ᔖ��2��h�d,��t�r&�@m�OċĔeF���AS`�-/�LD�\"7J\"��9�H1r��p+��B�}�Xi\"\n�M����Zd�>b�B�!�A��2��,�Z{�32U�ตT.��1�g5�S�F\"�i��5A�o걍�۳�����8��!o�ϢS	��AO�G�����ܖ$��D�:�3�\rW^���*5���v�qZ�8r\"�fc>���u��U�O!�2P�x�H�r2���CfB�@.�&\0��f��.�0V&�`�!c��W#�(}��	+�P�BP8\ZZ\Z��[�h0���h{��O�tRo�%0$���(�rm���\"`��\"�tci�B���.����xy�>�`�,�no�>\Z���)�-Ԛަd�����;����j`����+��I�ha7�52cX�̱\ZE��f66&�0����k�).M����ҨU��yT\\�ӈ��<��\"�y��(=a\\�DL\r�SKlGm55rE.@���w��?��[��&f����p�!����[V�e0T�T���G=h�L���D�qk�]�^9ʘ6�%�\0�m�-�l8�󶝫_��<�$عOC��\'D���{&.�Mܓ��&�Z�>4��«M�;���]�󌽉+�3����7;�6��8��+�s���=aڸŭ{6\Z5��F����}�ah����-;;�\\O�E��c�9H*��v�U�>AOSR�#kK0�`|�r7��N\n��!n��B�l����|*hPij�lϨ���,�U��}�f`�^zCC����mj\"Z�?|��+\\Sj㖩�,J�Gn`�!v<d��-����>�zP������&� ђ���<���r��uy��=\n�M���d8\"�:�|��r��q�g�����E�+��������p���A��Ki�w��m����{�Fk�n�hh���h�����Hf��7 ޥ�a�x�LAd�[1m��{Lۧ�ޔi��^I��� �-��T��T̐jS�!ՖWާ�B��B��)2��gSnsmf1~׶�΀kKB{d���;`��a�K�CN(��8����8�c��q��1d�5G����i�e?Qr�\"����\"c�y`���x�V�G�J��L���kO�Moޘu;f�Y�1�5&2����\Z�v	���oiJ��4fH&�t� �P��7�3��0�^?E`�&�$�vlSoEt� �$L<���+3w9�h�=$�}����6�ÞuQ{����c��� ���9x�y�V1V= ���̫`2W�Ma�;���P2���S�T��Pҧ%�b�����\n�����J��+d*\'��2��Ʃ��~��B�A��m���`P��j�ާGD��`HZ�+$2W�z���\nU��R/�0��,B�:��d��$f��b��m�5���khN����D>�l�c`\Z9U�1�Z����4\Z� +1#ca���S�1�<��0tka63�\Z�lm���\r��Fi�m\\[��i��tX\\4e��\Z�t8c�8YV(�� a&�8櫔��5�9����Ml�U9w��*�[շ�q���A�A������M�<�A��\r*� i���r�N�g##ӱ\\ؐ餍�\rL����A�&ތ���d�t|L�\"�������9��{��CS�n{�>I��أ�*n�o-�������ŕa��8�^���8/f�6�	��\na�~�g	��Q$6�����`&*���R�\\����M⁙��r�\\rc��\'K\"f0����Kǃu���,���z��G����}��4�8����bْem5^8{2\n69G��ax�	e6�[��2��愣e#)�\"�U����6�lrf;U�9�$��zO}L���jci-�����{_����T�����_���H��D�g[�cS��z�\"N��=bk8`=>�+.�;���%�a;�9H�i�]����8	�up\\�r�?*;V����\r��y�s��ҳ��$��x�Nv��	#��x(��	��������^\\U#��CchV�V3�M\n|%}��ל�Ja�\\Pȯ�\'�H�Gߠ�N�\"d�94h8�O��)�pYe��j�Q��$�A�\"xA^rPJ}�9�ZL\'�gg�M��Vh+�l�g`�)�\nt �zĸ��R��r��*m�\ZJ E)ږu����!X2��/T����<kj`�/ ��?Q*H9�Rr�]%\\[�i�cV��0��su5(RM�����.�a�#-:�L�R\0&����m�	���Pr�\"��V��pz�BN�ɷ�)�,�\rK/�q�E\r�c�D��aங�Ɩg6538�SՂ7�#H�I1x(.�(l�Ǹ�S�9W���s��<W�Ԍn2���.���k��\\#���905���;�-L$��9k�@\r�]D�0p�B{)\0e�!�Uɡ�L70��\rt����[kҵ��(�J+1qAZ�.�dRhH*�zǍ�\n\\���4:��a4��;�2�T��@,EͰ)C�xBQ��n��嬸\Z�ղ\0��dh�j(�5���g��K󸐬�\0Աt� c%�F�8�����)9�x\0ՠ��/��[����7PY��L�����Y*�]����+`#��_WX��ن��@M�~*��w�D��ئ�A� r���rq�qC��e�5���~AD�ʪ<�3(NKߏ!�ʸ~�ͤF����t����)5��U�%+`1(�*�:���m�JN�r�$���9b ��\\���708ׂ_�]E��`\n����Bn�Mhu�bQD#�9!�@����8�s�f��~�}@&�M�\0��h,@��qm�Rfm�scy�05H�\0݅��\Z-�;�Z�:k�6x�/܂�ɚ\0p]��4��0�/*�p�	��<n(8PV\'��g5�ą�h�b�:��?dҀ�4������zu���Q�1\0m��	�т��5�I�\Z�E�@aV�Q�=i�L���6ThL�sI��eޕq�	��Q������kM>LnFl��2�����x�:�e\Z�\Z�a�{L4pX�Bq�Ǌ̌�H2)��-0���F����\'kyzn;}���rN%�Z5�\"!��+�|\Z�qh��]C��\r5C��I�.\n��zUm/�4�Z-���	4TtK!(h(��S��nJ\0/O�PPX������j�](��t�\"�e����b��@����(DP�*�Rq��Y0 *=��x�r�pp�y�%b�?�ĕ�/0�S[��]��7m���OE`��Y-S\"M�d9��� ��՜��(j.�S�7t�|g��K�Ay�W����щ��;�D�:Eb\0W@\r�lZN��){�������n�#����(�u�44���4T��1h�L�d��8Ѭ����:ʔx*��ےIvm)���\Z���i�����di�$n���<l�P ��d��+W!�h��%��I`�<=�5U�MO5̠�pLt\n\r�p-;�3�ǀ!������T��\"� 5����\Z������5)���g)�)dF[k�\ZȣeJ��/_X��!�_����FL� �bl{��P��\nU��M����#!7@��8��4d���:��k�Y��Ap�w-�CB�zp$�%�\0�.o�89(H!	4�K����ǈf�/�\r\n����b�UʈA	�FPPq�F�NɃa{P�QXp�/(�:\0sJ������3\r�vT��م\Z�����/��\Z���b����&��V�֣s3M����%��}�,�eQ��LzAQ��6�E��RQ\0�I�#�i����Q�(�´�P�WG�I�մQ���\"\"]pk��/���і��Հj��Pئ ���<^�9|�H\0Dn���S�2�d�R@�`R|G4�)6��錵�=Mst\'#�J\0!u�Z���\0�8���0��i]�\"Ƥ�Y��J\\����Z��i�a��\Zh�p`��W� Z&��)�m�0}(��.r%��4ͅemP����km|�Nq9�X��C��yd���H4!V���\ne�`��$��O/D��g�%ʩ`�b�\n�U�kJ�\"�k�,�^���v��?f{�pv�,�P��䭤��b���1�6^�jMb���\\x�1,�����4p��H�$�k�Aw\r�G�B{r����!+)�_�haT�^�<�)��>�,`���#ei�������s`���c�(�Q�9*L�&����	e)I\nW�N�t7��8�4pé���|<zͼU��I��x�d�H�!�.��A����gs�\0���<�B��`�6��q��tj��L�*�L�W�#�G~\n�WU��=\"4\0��-0�a�B|y�!$�,?�Pf�4���1�R�_�&P�8�\0E	�dk8�$袓�/hj�&\"N�!�#� ^�:J��\0r k��!f���0G-��+��})��}�m8�Q|s�VWsr��k����=��M��Δ�U����H��+���;Z�1�yHƉ��y7��[����յe�����E������1P���a&�����u�p����e�4)ؒ	a�_��\r��cbT^�^�R���>[�P�P���c	[�\n�$1���P�PPC&�J8��j����L/S�Ch����	@X���з�?��=\\������zEU����?�贴�K��-xK���43M���q��,/\";=}�E�3�!S�Y?d��m@Wz�V�c\\\0U@�\\zq�e�s�G�~}���?x���[^/÷�k~���l�y�O����@eϟ/v��+�?\'�8l���nz��^�g�˓�˫u�<|���(�-v����g�W�*����f1],��n��h����g+��*�?��5|�?\n_��]�a\n���0E����R���n�`j(e���$n�2?�$�P��30z��@�\0�@kK3ؚTzY�%��t�pQ	�	ǜ\r�!��v	_{+�|�9�s�7����0m�h����`���z��\r�۔#bOhz�:���\0�mb��&E`c5#hVa�M�e�E�����K���:�%����S\0Մ\"��L�M�J$5��D��DRf��DA;��.q����2A=���b����+҂j\"�T����JR�Y#�,�T��<�&��J���$����+�&HG0�j�)ɠC��ɤ*���3���]o��dR����d�!�1bt�	d�c�	e?��A��Lt^�DҨzf�&&��}���M$u���y�4� s�I���WC�h� U�d�Hj��B�e\"Is�\\f̀Pr�1�D��H���\rR�Hz��	ò��D��q�&㚊E��j/�,1�R�J�B�+J��m�K[̴�r�\"��c�<��l�0��f\\9�Pr� ���Bq2/��J��y5����̫�B�yp�2���n�P�c�dB�%�қ�1�83���H*��\ZWx�Tf^h�>���S�n!li\',��c84H	n9��@��\0�T����&5?ρ��-|�����@*�!E����fr V.E��?\njJEg�0/%�,7�A����o��h%��\r��>���Rs��	�,9��Z����Dkq\nK��!���2�lK���L�9�ONU<ýDBjy;�/4��ÒR��dR��D=��ʖ�̩3�Gͱ��]����@(��)!AE K��y\\�t�1�{K)1��b�A�A�zv�f،V\\��V�|��v��i[��Ǥ�2�D��Ԛ�S��Q|�^�ɀ�Dژ�s+�/#Ax�`��C��%�:&U��dT��B��\'�]W�6U.!	���3	)�٣��j5R�JjK�Ƭ1	Ai�1NB	��J�A�$���Yi��D���*/m��T�=2�@H`�T��_���+\'�0���W&�<7kJ+R�OdM�*\n=m̚�(�֜RA0���\0dMl\'�T�fMpb��LV7�	��Ȝ\n�-�J3\'�LLh�̩T��x\ZS-�G�#���0��א1�q���19WyU�1e��tf��VK�Ju�B*������z�̚�,@�BD����̜�;���W4$�9�%�\nb����YjF��|>���2s���l5�\0h.:m5$�F�c�jr���n\ZJCW�X�+�JQ�\"��\\in�Ca��EC[D���Q(��c-o���}��弟Ik��h��)�F�)\0Eη�RX�Ε�2s��N7j�k�|DmMG�jNőn�k�2D�B]�&踥+�v���I!�&D�^��I���̮��K�r�7�s�j��TDɭ���I+�7���I+� +��3��+)dEf�ۜ@\'���×�_���\'Su�:�Y��t�������cC�p�6j�^N춊�9>okHK�*=6h<�1�a�J���R2i9\'��S3�J��$Sp�����8NS�tᬱ��Ч�T\n�$�9�$�ϐ���f<.	��(��CR�$Ø�Mf� �nTVz!N��l)g)�VTrjI�a�H�5Q<�Zg��|ʉ�d\r�2es�W�ݟBQ�\n ��o��c��9	n�<��4\"����jka�R�TMVx�׾ڌ�)d�<F��l������,����֬\nC�ө(ր�d�b�HCQ�l�L����,o�z�S���j5���1��V�����$�\rY-=:�-��:D���ͦ[�&��z���Z����_X.^��?ǐ�l:�N��o��>���Ko;�U��(^1	\\�f0�f�-��f5�Mn�e�\'L_\"ƹ<ޗ�.!N%�ᚂ��H�Z��X2pA�W|E�%�T�����+�>\"�Ix��7}�0�\\���:)�K�pH纙xY>8%uǣei�;�>+az_Q�F����b��uR�Z�%����O`Cy���]U)\\R���{����e�cN������}��]2s6*q��_&��w6(|���]�v2���o������޶	�\Z�F��vEg@����4�nI��E�2UNR�k�Kfr�W��MZ�H-\'9<JS��ϣA:��~N�����%i%?�Ku|ADEU:.�-��Q��;iJh0߹IsQF��!BknE�uUd�L�3���NeIA���X_�`�b}��u۷g��t���>A�g}!��1��?��?�l�F��B�\\C���eK�(�66:�\Z;U��u���b�{!T|��2J�i���SM�����n��-?\'<<�^v�}�C��}��8�7���邽���@��v�|���Y(�`��o��[כ�^��<�_9�n��o�h����7�������O�Ǻ^�g�{o��ڞo���o@��ޏ�*U>�=&HZ�;N�=�\nv̥�8�0���cȹ1~��O��d_���O�u=GVV��㾖���=\0��1ͽO��.���)�V��\'��PAv�T�b��)�N>�~gP���ɠ�_�Aͻe�9��{gO����������1p�X�x�Y\\.v���;��K�{O��?;{������|��־��?\'kr�Xk�w�ǋ$�A7���_�M�$ԶxGm}=����/V�#��˃�����1Z�&��a��*�粞�韶�<���������E[��p��������M_��~�\'\r?F���6��3Ɔן���˫�b�\Z��j�x|f�{=���A�{u3����⩕�S�+����~><1��?�,�v���U���r=�^߷���}�vۓ�z~�e�yӞu�ԝq��|���|V�y{������Ѯ��?n�)��A״�%���Ї\'���K6�bw������,{p���%Z�S�xpD������t��<�ޝ�\Z=�}�����̪=z� }����\'�G�\0���j�m�ͳ���n���-֫O��>���j����Y״]�Ί���鬫Rt�R-���vӝ�Ǖ���r�i��\\�t��~�Y_~�Mq��m���O�x�zp�\\Ϧ���_<���E���ɳ?L֛��yq�oS6���5Ko����?��Qۃ�n�֕ve�:�F#\'������� ��y�Х��z�ۼ�\'u>���ݳ.���9�\'���l�~}�7a�]QB�٢ۆ��P��?n?^,��������S(��}_���7�2��;�=���J�Y<u6����#tF�B��^.�n���?\\���5c��ͯ��`4>Jz�D��&��K��х���S�ƽ�fT����/��*\Zx���O�o9���ㄣ��\Z�B��.݄��E��=Y\\v�{A\0����z��]���y�g	�ɦ[\Z�;�P�_�����w[�p�>3���jpn�e5��G�A���j	��8�����䁖N��.�����o���z3�\'�]w�g�8�t��i��^�OO��`�\\q��[\n׏94�Ps��3ԋ�ϖBB�(�~�q|���R�.����ۄ����/_>`�O=�>].fC0e�#�������8��:�9_�O��������>��������3�]1Ht���3�(w�-��r�x=��!������S\nu!<t��W�����3�o0�K�H\n{2y�ޘP�`�ӫ����׫Y�)Y��`�,L��9H��e�Yk���m�\"�S�{���;���t���B�j\\m�W�f������O��7.���w�n3ݭý��ZG�J����KF������V\Z`1N�ؿ����ͻ�Ŭ��8Y�;�X��g=���k*�tʡt�u�(�/�\\>�L�.���������b��L7��\\�]�J��㱘}���c��\"�e7ӈd	D�?|�\'���G�ޛ߶����fH�x>�ysI�3H�]t��sϖ_M��y�0��6�ᮯ��;��A`�޲�Wp�W$m��z�ؽ���\\�({_RrFN���Q�o�-!�Byܱݽ\\v�.����DL����/�\n	����v�\\�5�<��`�\"��W95�iP��\\�t���<���#�n��$=q\'�����鷣o����\\��m1�ft������O~��o���j{E����մ�g�n��;���9ڊ�f��*�˽/��rI����n�n�H�ɕ���h�Di�2�I�4.T��rv�>��?���U}�O�̛�K�B�~�A�Ӷm��S\"�9���� ���A�Ӷm��S�<k�Y7w��� ���Y�N�~�A8P�Oj	�i�d�pਪ� ��9,�v�~<K�[�O9�izvVtggsQ�~\\�sX��h�p������}v���,�U ����ɅW�o^~�f�/�v�R9ȹ����w���~G���w���~G����;��Y�/99:��.���6S����f��<?ݬos&�E&�$13�~Z_eb�(��K4h��^^��ʲ6�3�8�Į��� �(��\Z��2�(=x�w��;M��p���������J���M��?ڄi��~�\'���٨[v�G����b��j�;��:������뗿;�L�������7�ݿ-~�~����?/�8��/������<6�}��e}����Q�ˤ��_|���_^?;��WZ__O�O>��/?�6}�~�\n�\0��_��˩͒:g\n.M�n�g���L}�>�����3%�^�]Xt�<ox���~�r��*j�T>D�g9Ts�]��V�������P�;�+��d�8]q��p�WR]9$�VW��H6Yu��=s@��sH\Z����:���W�v��O}6���l{4����Zl�}�j�MM����L����N���l��yUti��e7/�ӳҥe;w�i�M�<�gx����q��Q�]��TN�jڔ�eڝֳ�e]���\r�l');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'1_85e239543ee49ee9','pages_1'),
(2,'1_85e239543ee49ee9','pages_7'),
(3,'1_85e239543ee49ee9','pages_6'),
(4,'1_85e239543ee49ee9','pages_5'),
(5,'1_85e239543ee49ee9','tt_content_38'),
(6,'1_85e239543ee49ee9','sys_file_1'),
(7,'1_85e239543ee49ee9','sys_file_metadata_1'),
(8,'1_85e239543ee49ee9','tt_content_46'),
(9,'1_85e239543ee49ee9','tt_content_45'),
(10,'1_85e239543ee49ee9','tt_content_44'),
(11,'1_85e239543ee49ee9','tt_content_43'),
(12,'1_85e239543ee49ee9','tt_content_42'),
(13,'1_85e239543ee49ee9','tt_content_41'),
(14,'1_85e239543ee49ee9','tt_content_40'),
(15,'1_85e239543ee49ee9','tt_content_39'),
(16,'1_85e239543ee49ee9','tt_content_48'),
(17,'1_85e239543ee49ee9','tt_content_49'),
(18,'1_85e239543ee49ee9','tt_content_50'),
(19,'1_85e239543ee49ee9','tt_content_47'),
(20,'1_85e239543ee49ee9','pages_4'),
(21,'1_85e239543ee49ee9','pages_3'),
(22,'1_85e239543ee49ee9','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'1__0_0_1_1',1790013188,'x�mUM��8�/��v�|@ܧ������\\�sؓ˱\rq0c�N�������In��ғ�DP�>�_�*���e�`ً@��b����ڣ�hC�q9��j[�U�N�b����\ne�w����Y0�P^�1���k|`1R���Ur��5�Q����TF��_��VlQ���;�T��	/��8������iܑ��H��f[(�|�#Q|0����!�\"��Yh�,vc�i��G.>��#�C#�2�##\'m��Y�9Kc��Y�D�؁�or2�0<��;���J�cCZ���o�@� AI�;1\\<fx+����p�%{<wƂ��iȋ���\Z�sk��Z���7y�N#��	e^,�+˷�XÕ�.��]�b�b\\�����#��\Z�.eX��!L�>%�:�a �\"�,�x�_\r�We���]\'����Ҝ(z��l�i��XV��x�Q�CwI��]�/��2�5sՓ�3�7o���P[ssh79��i��t���Y�i1�m7CҴ�����\nÔ(�\"������|�#�1��N�6g�sJz\\w����Wf��l�����;��U�#oQ7�O�v�KPG�z�\'��*����K���ftS8�����UN>,s�n\'�n��;���^�������#�Ԡ�N&V���]ŷ��q��>�쳛%�����9M���@���V�_�\"�(��v�_������2Z��L�?�3�u)�n�#�f%`��G��ُ����<�Fb� �ECWd�\Z���.���X7�N��t�������D^|`�8� ���%�WeXH\0Y���T�t9�GPp+�)�~�v*��2аG^���E�y�w��rn(���f;Β6.�ǻ�K�t?��_��x˄<(^R�U�Ӧ�k!j��8|R5z���[t���G��H��m_�x����T|��z*�aXS!O�%�w>�H���닲�l�9)�v��}Y�m��t��l6����6���î�yU�x]Õ��OUU��r����Ȧ�U���>�)�5m��a:~�'),
(2,'7__0_0_1_1',1790013188,'x��WK��6�+��M��Z���`S��\"�zs艠(J&VU�Z����ޑHJ���(Р��Gr�y}3&(E�%�zU(C�ȫ螣�~�#% �(�J�n��b[ܥqQ�f�ʊhv�R��b-�l�b�xU��;�V�5����+٢�f��b���Q�}JH��fڗ�\0%w(����)*�����>�����L�-�pK�f$\r���y-AQ��=�d����%]^��ֳ����*^�n;��\0��㞊��M���RiI��ҨB�ߘu��)	}���Ob��0ܳ�[���J�aM\Z���E%��9%-ny��0�\Z!9s�D������Sb�h�y�\0�I�f���F�A5�h��~,�d��,�T���k&��o~b����=����ں�%J�$�����g�)���\Zz�����\Z\'��^���עm�qy_��ER�Hz0�h���\0�xa����À�d�KX��e��)&�S��:2`z��f�d�� 9�V�,ڎ�Qk1\Zq,=���0�4V&��hڎ���>r\rÔ�*D.�w�����2`xz3�XX�(�8�����\"C/:{5�+�؁G��Am_��N����+K&���4/]�|�X���	OK�:��RT�E,�����?�~����_>y4��/4��r��ro\'FX��	�z�g�f�<O �)�7��X��kM�;��s������=������q�	�L@��i�{\ZlK5|;9>������l�$�ꂕVW���آ�%���	.�ųb`�̶+2���V�ݸ�f��s�_uO,D�iq	���|#z5�MP@���.�k�J۽<�R��u	R�Po���r[R��\r9r��d�~w\\}�8���j���&+L�L�BZ�ِts~�o��B�\\[\\�he�0�\\C��qi9��-����o��y�.Y�Nx�_��/-��\r�Ҷ��CW�)ް��t�3�W���x�s9�&�l�m��o��m��\r����6�~��6����Ͷg�,8��md��F��[����p��O�6ؑ�\'�i�W\'�ۈ�?��o�$Ik�l�i�滼��َEB���y��e��uZ�uR���5���:��qVo���/MI~��ݦ��<���0�)�_��+'),
(3,'6__0_0_1_1',1790013188,'x��VM��6�+����?b\'��b�h�E��z�v��-W�\'濗�$[N�@�â��EQO�#Iȫ �#EA^5II4�2z$���Z1Z9��6��\'��Y�)��]�dnV\n�Ѐ�ɋ��$�:�I�^�1���6��ّ�Z+9��lH��TFt�r�P��H��G�\\���}��������1}Ѵa]=�\Z�������7홂���Z���������x�RT���(��k���eW�:���6�q����\n�Sh�h,rd�	���/r0�a��Cx��3~jX�W6�;{ଓ�ଡ��<f��J��&;�\\�Jɖ��1�e��䓹�`��sk�G��z+���p�}w��ʓ�Re�/4�������T��>�v啣�a�|��$-=���b������8{�A`��7���3�U:I+�4�<��+�e�40�O֔5�!\r1�\"��ԟzj\0f�t�\\e��i�ᮑ�����0��R��\Z���5�6�#j)Fk��)���Ham�/͛��oi����Q�T�Fn��<�����S�|\n\"lN�g�@�Y�q�-��b�gt#���x��%oQW����\'(��ZM\rjQ�8�����C�\r#���}���\'���c��Q���.�<�O_����_?2�Q/L�r7��ho+\\�DQ���u�I2��v���[\'�^\0#�}B��(V��?|ڌ\n��}��_z��S���N�ZZe)^�D@q ZK���]�����B�RꋏY� `ۗ��0W&�w�tuA�Nh��rkJ�{u�Y���\rf�	��Ԡ(r�%f!���d%�}�Mj�OwJȺa-K�Vd���֜�T�4��k��Mf��ۑ��h2V>�є>N*�hK��J�~��]��x���FW��(�:�|�pn\'�Z;�lf争��[�z�U/�o=���kL��$k{��庖�uƬ�ĕ�w���6s;�ƫ�u�=̭�6�����>������\r��?\\q����+��!�5���lHM�G��(i���Q� g�,͡,�$M�c�Y^%,��6Ny�Ow���L�v����Ⴑ<�-d��vqz��\"��IY��6G��<N��>��>'),
(4,'5__0_0_1_1',1790013188,'x��VM��(�/>�v��	}j���a5�*=�=!�Am�NG���[6`�$s�9�6K��zUg�]b�@qQ�w�W8�%O$�F�sk�k,m�(��:K�\"u#Lsj��H�.ja����=J�E�N���V6\"`�L�<F�8)���a{�S�$n�Q�ʶ\Zwζ��5N�:}�i�Y�`�/΃��֊��cΆԴ�zZ	��>�!��(mIG�h�lT��t<�؎4��c\\�e��(��{�g�-e��M~I��XM��Vo�J��D4T�9P����Ϫ��0Ҋ7Kj�*�F�QK+�������j%�5�e�0+*���Tk�RjՐ!2F�GL;@��s\'�1q�,���xo�Y��C��M�g-+�4�H+�R��/�|R����x`�Vz�kj��n�R����I���}�=����	\"��m�)N_[^�U�Tu�N�)[.�&���љ�\"W�&`a����cG��Ky^.\"|ČP񪁫�v�!�E�ŷ%�i	ok��{OԜ����S��\'-���f�4�{�Ҟ��#�j�D��\"��:��8zՇ�E#m$p]�J\r���z7*J�4�\'�Ly��,�W3��:\n���g�D���a��t^0�+��G�<+�|8�X���\'O0��gO�z�??�����>G:i@/,�m�rW�;�o�z��	�zͳ/	�d^�+鯹�� \0�8�{B�q���o�Ǡs3>����\r&mt::�Ȁ��H��\0g��Qp�63sb�>�x���ې��|R�\\mT��F�@��IF�YW�B�ם�|�=�`��K�_b�MG/�	�r*I#\0��U)�S���i�u��d V�(��$j�a��/�d�����(�C4�	�l\r!O�&<��=<過����q����(	�r%~���ey]�BDq8Րp�-�%��k|Y��Lud��\0�\'�jP4�h�������)k����Ei��yC�Ì����n-���g�V�|s�V���[�w��n�t��?�Va����*���ޫ��zU��z�lu�b�I\r�E��Zԏ���\r϶�rW��z[�m�*ݱU��i��)ڦ�YJy^���̶y*P���mV�\"?l8݉5|��K~�7G�nSh���'),
(5,'4__0_0_1_1',1790013188,'x��XM��&�+��I���c7sZ��K��2���6؍�6����5����ڝ��h\'��EQ���Ȇ<K�oI�܃\r�G��lo\'�5�D�׬nG\0%i��q��f$�8�b5����Jh1y�s�s�8`O\"��i-k�0X&\Z�#)�\nA�N\r�}ObEf^�:-�r����-�:u� �����\nv�h<.u���A0���kʁ��ڳOc�D�ڲN4z�j��9<;XOi7D;�qYn:đ�����}��B����e��X��5���o*j&+�d,��@�\'5�Kmē��xvI�򃠚�}`C~g9kT#sV�J6ӢT�n�j4����XʽL@=�S+�1��X�V����\'u?d-d�n2_�d�Z��eO{�E����A����v�-H�6����v�R�%5����Ce=4�B���4��ύv��(Z��R�ٔ\rO����c������!����Z�;!�����Y�OX/��j�U�Z���Eщ_C��$ܭ>Y�\Zl���h�!��X)l�|�7��Ϋ����G���h�:\"��/	��y�	�xj)�^��Q���r]�R�/���y7�{ܱ�}��\rj_��\\`�(���C/:�����S��.Ft��{o�Ķ����;�N�����rO~�������Ǔ=��������.�[��8�U�y�-a���2�\"�vg9���Dk�Ќ�T�Q{T=՝	��\\F��Ұ���xi��ji�}�^\"V��$byދ��,�e�=�`3�4N7q�L�����L&.�\r9c��3�/���4�yq�@���C��iҋH@�e΍i���7yg�$lR�\\�!�0>�{�i.D��4��������C����2�����6���ǂ/��#{���v�BL�%F��ߒ�&l2��p�Y/q�6�o6CH��؞\\������~��g>/���2��Zx�@x�/LxB��k�w7o@y�m�V��R��,���˷�>��uQ����/��K\Z�*�V)�_!�n{&F��C�W�ee�̛	t�ț�i�7ᤫD�J��D��K���D@�D��0�p����P�S�S�S�SoO��W��S��n��s	\n\n�*8�W��S��%��{JM�ݏ��Z���Bt���3��y�J�Y��dY�҄c.P�mNx��7�l�g�n�n@m2�+f<��@����t�9�\nT�x�R��(β��;.�7�oޤd�'),
(6,'3__0_0_1_1',1790013188,'x��XK��6�+�$ˣiz��j6�C��Գ��,�mh�c��5����`7��F�j�p�>��r���\'p��/<��q�e�Kf�s\Z��<��V[1X�<P��u;\0Q��6q�e�!�b�#YPV1�F/f�S�\Z��x�J�Y�����.\n�J)zؾ��<��NHśr2�m�@����[���Q{`��J��u\ZA0ݥCn�����cQTQؠK֨܉^�)�(��\Z�0l���(�t�#/�㞈��e\0\'�:��NIL��zu��F�Ƽ���d���^��PÞ��3K&G�.;φ�NnD�	�Pś��+���.��\\�B�\Z\r�1��ɴ�I]Z��)��2���g�Fž?��}��tͣeje���bR�]�BR�н�\ZD\n��\nw�S;T)����\Z���Sо2\Z�� �Rp\Zk��F�[i*DU��d������MQ�E�\0�5da����c��d�K��\\U��uL���\\ոE���\n�~��Vr�[u1h՛DͯQ���q\nc%3Is�NW3�T=�w��\\��!�%����퀓��<Ä�=�B/{[�\0�#��5�\\W���k��E%O�F8�;���F�+��3;2Yw���^�O,>����`��ȸw�D���8�cy9z�<����=����������Ó��\"�rYn�rg�En����<��0R�u�V~�\ZN�`2��+ԣ?K��ɸ\n�z�;��vsbHͦCZ�w��!��9@��;�XpΜ��y�>v��N���63Oc��t#����=�]NdbcM�+���;���{8�D3�[��=�D�:�Q��m�Sc\Z8��MΙ��oR�\\�&V?.�;�i*D$�4ls��ޝL�n�C����<?N����6���Ǽ�뗈%{���v`C����~�_7ao��%�K�z�����8��|Ju����<==�����X���\rb�3^vX\n����&<�|���7���|���e��=W�-����fR\'At����[�@�)��+10���\0�_A��%�o��o�+�I���V��J�U\"��%BxC\"D�D�0����Z�M����S뿩�(H�7��S��a��k	\n\nt��+��S�3J.Yu�b���\Z���Bt�����zX%�g���$\n����@�D�D;��\'$9�q��a�4�Eʲ�(iF`%��	!Y��-�;�i��$c��e1>l��$8��\"if�'),
(7,'1__0_0_0_0',1790013190,'x�mUM��8�/��v�|@ܧ������\\�sؓ˱\rq0c�N�������In��ғ�DP�>�_�*���e�`ً@��b����ڣ�hC�q9��j[�U�N�b����\ne�w����Y0�P^�1���k|`1R���Ur��5�Q����TF��_��VlQ���;�T��	/��8������iܑ��H��f[(�|�#Q|0����!�\"��Yh�,vc�i��G.>��#�C#�2�##\'m��Y�9Kc��Y�D�؁�or2�0<��;���J�cCZ���o�@� AI�;1\\<fx+����p�%{<wƂ��iȋ���\Z�sk��Z���7y�N#��	e^,�+˷�XÕ�.��]�b�b\\�����#��\Z�.eX��!L�>%�:�a �\"�,�x�_\r�We���]\'����Ҝ(z��l�i��XV��x�Q�CwI��]�/��2�5sՓ�3�7o���P[ssh79��i��t���Y�i1�m7CҴ�����\nÔ(�\"������|�#�1��N�6g�sJz\\w����Wf��l�����;��U�#oQ7�O�v�KPG�z�\'��*����K���ftS8�����UN>,s�n\'�n��;���^�������#�Ԡ�N&V���]ŷ��q��>�쳛%�����9M���@���V�_�\"�(��v�_������2Z��L�?�3�u)�n�#�f%`��G��ُ����<�Fb� �ECWd�\Z���.���X7�N��t�������D^|`�8� ���%�WeXH\0Y���T�t9�GPp+�)�~�v*��2аG^���E�y�w��rn(���f;Β6.�ǻ�K�t?��_��x˄<(^R�U�Ӧ�k!j��8|R5z���[t���G��H��m_�x����T|��z*�aXS!O�%�w>�H���닲�l�9)�v��}Y�m��t��l6����6���î�yU�x]Õ��OUU��r����Ȧ�U���>�)�5m��a:~�'),
(8,'7__0_0_0_0',1790013190,'x��WK��6�+��M��Z���`S��\"�zs艠(J&VU�Z����ޑHJ���(Р��Gr�y}3&(E�%�zU(C�ȫ螣�~�#% �(�J�n��b[ܥqQ�f�ʊhv�R��b-�l�b�xU��;�V�5����+٢�f��b���Q�}JH��fڗ�\0%w(����)*�����>�����L�-�pK�f$\r���y-AQ��=�d����%]^��ֳ����*^�n;��\0��㞊��M���RiI��ҨB�ߘu��)	}���Ob��0ܳ�[���J�aM\Z���E%��9%-ny��0�\Z!9s�D������Sb�h�y�\0�I�f���F�A5�h��~,�d��,�T���k&��o~b����=����ں�%J�$�����g�)���\Zz�����\Z\'��^���עm�qy_��ER�Hz0�h���\0�xa����À�d�KX��e��)&�S��:2`z��f�d�� 9�V�,ڎ�Qk1\Zq,=���0�4V&��hڎ���>r\rÔ�*D.�w�����2`xz3�XX�(�8�����\"C/:{5�+�؁G��Am_��N����+K&���4/]�|�X���	OK�:��RT�E,�����?�~����_>y4��/4��r��ro\'FX��	�z�g�f�<O �)�7��X��kM�;��s������=������q�	�L@��i�{\ZlK5|;9>������l�$�ꂕVW���آ�%���	.�ųb`�̶+2���V�ݸ�f��s�_uO,D�iq	���|#z5�MP@���.�k�J۽<�R��u	R�Po���r[R��\r9r��d�~w\\}�8���j���&+L�L�BZ�ِts~�o��B�\\[\\�he�0�\\C��qi9��-����o��y�.Y�Nx�_��/-��\r�Ҷ��CW�)ް��t�3�W���x�s9�&�l�m��o��m��\r����6�~��6����Ͷg�,8��md��F��[����p��O�6ؑ�\'�i�W\'�ۈ�?��o�$Ik�l�i�滼��َEB���y��e��uZ�uR���5���:��qVo���/MI~��ݦ��<���0�)�_��+'),
(9,'6__0_0_0_0',1790013190,'x��VM��6�+����?b\'��b�h�E��z�v��-W�\'濗�$[N�@�â��EQO�#Iȫ �#EA^5II4�2z$���Z1Z9��6��\'��Y�)��]�dnV\n�Ѐ�ɋ��$�:�I�^�1���6��ّ�Z+9��lH��TFt�r�P��H��G�\\���}��������1}Ѵa]=�\Z�������7홂���Z���������x�RT���(��k���eW�:���6�q����\n�Sh�h,rd�	���/r0�a��Cx��3~jX�W6�;{ଓ�ଡ��<f��J��&;�\\�Jɖ��1�e��䓹�`��sk�G��z+���p�}w��ʓ�Re�/4�������T��>�v啣�a�|��$-=���b������8{�A`��7���3�U:I+�4�<��+�e�40�O֔5�!\r1�\"��ԟzj\0f�t�\\e��i�ᮑ�����0��R��\Z���5�6�#j)Fk��)���Ham�/͛��oi����Q�T�Fn��<�����S�|\n\"lN�g�@�Y�q�-��b�gt#���x��%oQW����\'(��ZM\rjQ�8�����C�\r#���}���\'���c��Q���.�<�O_����_?2�Q/L�r7��ho+\\�DQ���u�I2��v���[\'�^\0#�}B��(V��?|ڌ\n��}��_z��S���N�ZZe)^�D@q ZK���]�����B�RꋏY� `ۗ��0W&�w�tuA�Nh��rkJ�{u�Y���\rf�	��Ԡ(r�%f!���d%�}�Mj�OwJȺa-K�Vd���֜�T�4��k��Mf��ۑ��h2V>�є>N*�hK��J�~��]��x���FW��(�:�|�pn\'�Z;�lf争��[�z�U/�o=���kL��$k{��庖�uƬ�ĕ�w���6s;�ƫ�u�=̭�6�����>������\r��?\\q����+��!�5���lHM�G��(i���Q� g�,͡,�$M�c�Y^%,��6Ny�Ow���L�v����Ⴑ<�-d��vqz��\"��IY��6G��<N��>��>'),
(10,'5__0_0_0_0',1790013190,'x��VM��(�/>�v��	}j���a5�*=�=!�Am�NG���[6`�$s�9�6K��zUg�]b�@qQ�w�W8�%O$�F�sk�k,m�(��:K�\"u#Lsj��H�.ja����=J�E�N���V6\"`�L�<F�8)���a{�S�$n�Q�ʶ\Zwζ��5N�:}�i�Y�`�/΃��֊��cΆԴ�zZ	��>�!��(mIG�h�lT��t<�؎4��c\\�e��(��{�g�-e��M~I��XM��Vo�J��D4T�9P����Ϫ��0Ҋ7Kj�*�F�QK+�������j%�5�e�0+*���Tk�RjՐ!2F�GL;@��s\'�1q�,���xo�Y��C��M�g-+�4�H+�R��/�|R����x`�Vz�kj��n�R����I���}�=����	\"��m�)N_[^�U�Tu�N�)[.�&���љ�\"W�&`a����cG��Ky^.\"|ČP񪁫�v�!�E�ŷ%�i	ok��{OԜ����S��\'-���f�4�{�Ҟ��#�j�D��\"��:��8zՇ�E#m$p]�J\r���z7*J�4�\'�Ly��,�W3��:\n���g�D���a��t^0�+��G�<+�|8�X���\'O0��gO�z�??�����>G:i@/,�m�rW�;�o�z��	�zͳ/	�d^�+鯹�� \0�8�{B�q���o�Ǡs3>����\r&mt::�Ȁ��H��\0g��Qp�63sb�>�x���ې��|R�\\mT��F�@��IF�YW�B�ם�|�=�`��K�_b�MG/�	�r*I#\0��U)�S���i�u��d V�(��$j�a��/�d�����(�C4�	�l\r!O�&<��=<過����q����(	�r%~���ey]�BDq8Րp�-�%��k|Y��Lud��\0�\'�jP4�h�������)k����Ei��yC�Ì����n-���g�V�|s�V���[�w��n�t��?�Va����*���ޫ��zU��z�lu�b�I\r�E��Zԏ���\r϶�rW��z[�m�*ݱU��i��)ڦ�YJy^���̶y*P���mV�\"?l8݉5|��K~�7G�nSh���'),
(11,'4__0_0_0_0',1790013190,'x��XM��&�+��I���c7sZ��K��2���6؍�6����5����ڝ��h\'��EQ���Ȇ<K�oI�܃\r�G��lo\'�5�D�׬nG\0%i��q��f$�8�b5����Jh1y�s�s�8`O\"��i-k�0X&\Z�#)�\nA�N\r�}ObEf^�:-�r����-�:u� �����\nv�h<.u���A0���kʁ��ڳOc�D�ڲN4z�j��9<;XOi7D;�qYn:đ�����}��B����e��X��5���o*j&+�d,��@�\'5�Kmē��xvI�򃠚�}`C~g9kT#sV�J6ӢT�n�j4����XʽL@=�S+�1��X�V����\'u?d-d�n2_�d�Z��eO{�E����A����v�-H�6����v�R�%5����Ce=4�B���4��ύv��(Z��R�ٔ\rO����c������!����Z�;!�����Y�OX/��j�U�Z���Eщ_C��$ܭ>Y�\Zl���h�!��X)l�|�7��Ϋ����G���h�:\"��/	��y�	�xj)�^��Q���r]�R�/���y7�{ܱ�}��\rj_��\\`�(���C/:�����S��.Ft��{o�Ķ����;�N�����rO~�������Ǔ=��������.�[��8�U�y�-a���2�\"�vg9���Dk�Ќ�T�Q{T=՝	��\\F��Ұ���xi��ji�}�^\"V��$byދ��,�e�=�`3�4N7q�L�����L&.�\r9c��3�/���4�yq�@���C��iҋH@�e΍i���7yg�$lR�\\�!�0>�{�i.D��4��������C����2�����6���ǂ/��#{���v�BL�%F��ߒ�&l2��p�Y/q�6�o6CH��؞\\������~��g>/���2��Zx�@x�/LxB��k�w7o@y�m�V��R��,���˷�>��uQ����/��K\Z�*�V)�_!�n{&F��C�W�ee�̛	t�ț�i�7ᤫD�J��D��K���D@�D��0�p����P�S�S�S�SoO��W��S��n��s	\n\n�*8�W��S��%��{JM�ݏ��Z���Bt���3��y�J�Y��dY�҄c.P�mNx��7�l�g�n�n@m2�+f<��@����t�9�\nT�x�R��(β��;.�7�oޤd�'),
(12,'3__0_0_0_0',1790013190,'x��XK��6�+�$ˣiz��j6�C��Գ��,�mh�c��5����`7��F�j�p�>��r���\'p��/<��q�e�Kf�s\Z��<��V[1X�<P��u;\0Q��6q�e�!�b�#YPV1�F/f�S�\Z��x�J�Y�����.\n�J)zؾ��<��NHśr2�m�@����[���Q{`��J��u\ZA0ݥCn�����cQTQؠK֨܉^�)�(��\Z�0l���(�t�#/�㞈��e\0\'�:��NIL��zu��F�Ƽ���d���^��PÞ��3K&G�.;φ�NnD�	�Pś��+���.��\\�B�\Z\r�1��ɴ�I]Z��)��2���g�Fž?��}��tͣeje���bR�]�BR�н�\ZD\n��\nw�S;T)����\Z���Sо2\Z�� �Rp\Zk��F�[i*DU��d������MQ�E�\0�5da����c��d�K��\\U��uL���\\ոE���\n�~��Vr�[u1h՛DͯQ���q\nc%3Is�NW3�T=�w��\\��!�%����퀓��<Ä�=�B/{[�\0�#��5�\\W���k��E%O�F8�;���F�+��3;2Yw���^�O,>����`��ȸw�D���8�cy9z�<����=����������Ó��\"�rYn�rg�En����<��0R�u�V~�\ZN�`2��+ԣ?K��ɸ\n�z�;��vsbHͦCZ�w��!��9@��;�XpΜ��y�>v��N���63Oc��t#����=�]NdbcM�+���;���{8�D3�[��=�D�:�Q��m�Sc\Z8��MΙ��oR�\\�&V?.�;�i*D$�4ls��ޝL�n�C����<?N����6���Ǽ�뗈%{���v`C����~�_7ao��%�K�z�����8��|Ju����<==�����X���\rb�3^vX\n����&<�|���7���|���e��=W�-����fR\'At����[�@�)��+10���\0�_A��%�o��o�+�I���V��J�U\"��%BxC\"D�D�0����Z�M����S뿩�(H�7��S��a��k	\n\nt��+��S�3J.Yu�b���\Z���Bt�����zX%�g���$\n����@�D�D;��\'$9�q��a�4�Eʲ�(iF`%��	!Y��-�;�i��$c��e1>l��$8��\"if�');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'1__0_0_1_1','pageId_1'),
(2,'7__0_0_1_1','pageId_1'),
(3,'7__0_0_1_1','pageId_7'),
(4,'6__0_0_1_1','pageId_1'),
(5,'6__0_0_1_1','pageId_6'),
(6,'5__0_0_1_1','pageId_1'),
(7,'5__0_0_1_1','pageId_5'),
(8,'4__0_0_1_1','pageId_1'),
(9,'4__0_0_1_1','pageId_2'),
(10,'4__0_0_1_1','pageId_4'),
(11,'3__0_0_1_1','pageId_1'),
(12,'3__0_0_1_1','pageId_2'),
(13,'3__0_0_1_1','pageId_3'),
(14,'1__0_0_0_0','pageId_1'),
(15,'7__0_0_0_0','pageId_1'),
(16,'7__0_0_0_0','pageId_7'),
(17,'6__0_0_0_0','pageId_1'),
(18,'6__0_0_0_0','pageId_6'),
(19,'5__0_0_0_0','pageId_1'),
(20,'5__0_0_0_0','pageId_5'),
(21,'4__0_0_0_0','pageId_1'),
(22,'4__0_0_0_0','pageId_2'),
(23,'4__0_0_0_0','pageId_4'),
(24,'3__0_0_0_0','pageId_1'),
(25,'3__0_0_0_0','pageId_2'),
(26,'3__0_0_0_0','pageId_3');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_logo` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1787420770,1787420770,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l10n_source\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_logo\":\"\"}',0,0,0,0,1,0,31,27,0,1787420770,0,0,0,1,0.5,1,'Camino','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'pagets__CaminoStartpage','pagets__CaminoContentpage','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(2,1,1787420770,1787420770,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"categories\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"media\":\"\",\"module\":\"\",\"rowDescription\":\"\",\"slug\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"tx_impexp_origuid\":\"\"}',0,0,0,0,1,0,31,27,0,0,0,0,0,2,0.5,254,'Footer navigation','/footer-navigation',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(3,2,1787420770,1787420770,0,0,0,0,'',256,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l10n_source\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_logo\":\"\"}',0,0,0,0,1,0,31,27,0,0,0,0,0,3,0.5,1,'Privacy','/privacy',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(4,2,1787420770,1787420770,0,0,0,0,'',128,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l10n_source\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_logo\":\"\"}',0,0,0,0,1,0,31,27,0,0,0,0,0,4,0.5,1,'Imprint','/imprint',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(5,1,1787420770,1787420770,0,0,0,0,'',128,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l10n_source\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_logo\":\"\"}',0,0,0,0,1,0,31,27,0,0,0,0,0,5,0.5,1,'FAQs','/faqs',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__CaminoContentpageSidebar','pagets__CaminoContentpage','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(6,1,1787420770,1787420770,0,0,0,0,'',64,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l10n_source\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_logo\":\"\"}',0,0,0,0,1,0,31,27,0,0,0,0,0,6,0.5,1,'Packing List','/packing-list',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__CaminoContentpage','pagets__CaminoContentpage','','',0,0,'','','',NULL,0,'',NULL,0,'',0),
(7,1,1787420770,1787420770,0,0,0,0,'',32,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l10n_source\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_logo\":\"\"}',0,0,0,0,1,0,31,27,0,0,0,0,0,7,0.5,1,'Camino Route Comparison','/camino-route-comparison',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'pagets__CaminoContentpageSidebar','pagets__CaminoContentpageSidebar','','',0,0,'','','',NULL,0,'',NULL,0,'',0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1787420823,1787420823,'/camino/max-kukurudziak-mrNvSPGBDk0-unsplash.webp','0b6c8c3fb4a5fef3161c679c5329efce71770dab','f4f34c530beaa7932a7f96c824072f063790283f','webp','max-kukurudziak-mrNvSPGBDk0-unsplash.webp','df13618ab849497a9136ed8a4cec93254e8cbd55',1787420823,1787420823,253052,1,2,'image/webp',0,0),
(2,0,1787420823,1787420823,'/camino/bernard-wortelboer-l5zWzwYnt_s-unsplash.webp','d4af945a531a7eba4700bfc08eaeb96c3cd08f21','f4f34c530beaa7932a7f96c824072f063790283f','webp','bernard-wortelboer-l5zWzwYnt_s-unsplash.webp','564568dff3ad84e2a48188652ec667423ba2e03c',1787420823,1787420823,66498,1,2,'image/webp',0,0),
(3,0,1787420823,1787420823,'/camino/jon-tyson-3r9S0C_R5Ds-unsplash.webp','0aa77c97ba0aece7e4d2a0072f7de84af4aa9ce3','f4f34c530beaa7932a7f96c824072f063790283f','webp','jon-tyson-3r9S0C_R5Ds-unsplash.webp','464432acddc38bf4046731add86601490d2f1a28',1787420823,1787420823,118412,1,2,'image/webp',0,0),
(4,0,1787420823,1787420823,'/camino/tomasz-anusiewicz-g2f1raDTczU-unsplash.webp','03d0ac0044157edfca426fd0936d1f0a11f79e75','f4f34c530beaa7932a7f96c824072f063790283f','webp','tomasz-anusiewicz-g2f1raDTczU-unsplash.webp','d3004cd7bc3646ea8fdbfaf002855e9a70f54285',1787420823,1787420823,92240,1,2,'image/webp',0,0),
(5,0,1787420823,1787420823,'/camino/victoriano-izquierdo-o7G89a9GFdA-unsplash.webp','64e9bd7babf104d295f615923f66f7716054f1ef','f4f34c530beaa7932a7f96c824072f063790283f','webp','victoriano-izquierdo-o7G89a9GFdA-unsplash.webp','e08b671b8a4818f4e5f1d0721b7d699ad7787185',1787420823,1787420823,99606,1,2,'image/webp',0,0),
(6,0,1787420823,1787420823,'/camino/damien-dufour-2mMrxyI13QU-unsplash.webp','30d0e0251f34479c1793d6e9ef4668e3f7eea637','f4f34c530beaa7932a7f96c824072f063790283f','webp','damien-dufour-2mMrxyI13QU-unsplash.webp','af779d8caff218c897f55ae321b1618b9b5ef505',1787420823,1787420823,49954,1,2,'image/webp',0,0),
(7,0,1787420823,1787420823,'/camino/andrew-milko-LspK43UdFo4-unsplash.webp','fe926470ed38932f7081d327185cd0def3cc39bd','f4f34c530beaa7932a7f96c824072f063790283f','webp','andrew-milko-LspK43UdFo4-unsplash.webp','5b0c8c2c73970603ee98dead73cf9c399448fb8c',1787420823,1787420823,40688,1,2,'image/webp',0,0),
(8,0,1787420823,1787420823,'/camino/fef4453b2185eb0e31f704b6224c66087807f19d.webp','ed80b7631d6a344dc1557d7561aaaccda850b9c6','f4f34c530beaa7932a7f96c824072f063790283f','webp','fef4453b2185eb0e31f704b6224c66087807f19d.webp','cefaff9b5980f2db89cf7b161d40eaa17dfc2afa',1787420823,1787420823,126304,1,2,'image/webp',0,0),
(9,0,1787420823,1787420823,'/camino/camino-frances.webp','c53f64a266deca9f193f79a86726d6d4291480b1','f4f34c530beaa7932a7f96c824072f063790283f','webp','camino-frances.webp','6895b44cf7212d433765861cea876a627aac7ceb',1787420823,1787420823,65814,1,2,'image/webp',0,0),
(10,0,1787420823,1787420823,'/camino/camino-portugues.webp','287907adbd74d415278486b666e8a1d073b898eb','f4f34c530beaa7932a7f96c824072f063790283f','webp','camino-portugues.webp','55d0749288a7228a0428bf1c41ff7ae49d154487',1787420823,1787420823,20162,1,2,'image/webp',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1787420770,1772031435,0,0,NULL,'{\"file\":\"\"}',0,0,0,0,NULL,NULL,0,1,'Photo by Max Kukurudziak on Unsplash',1200,800),
(2,0,1787420770,1772031435,0,0,NULL,'{\"file\":\"\"}',0,0,0,0,NULL,NULL,0,2,'Photo by Bernard Wortelboer on Unsplash',1200,800),
(3,0,1787420770,1772031435,0,0,NULL,'{\"file\":\"\"}',0,0,0,0,NULL,NULL,0,3,'Photo by Jon Tyson on Unsplash',900,1200),
(4,0,1787420770,1772031435,0,0,NULL,'{\"file\":\"\"}',0,0,0,0,NULL,NULL,0,4,'Photo by Tomasz Anusiewicz on Unsplash',1200,806),
(5,0,1787420770,1772031435,0,0,NULL,'{\"file\":\"\"}',0,0,0,0,NULL,NULL,0,5,'Photo by Victoriano Izquierdoon Unsplash',800,1200),
(6,0,1787420770,1772031435,0,0,NULL,'{\"file\":\"\"}',0,0,0,0,NULL,NULL,0,6,'Photo by Damien Dufour on Unsplash',1200,675),
(7,0,1787420770,1772031435,0,0,NULL,'{\"file\":\"\"}',0,0,0,0,NULL,NULL,0,7,'Photo by Andrew Milko on Unsplash',800,1200),
(8,0,1787420770,1772031435,0,0,NULL,'{\"file\":\"\"}',0,0,0,0,NULL,NULL,0,8,NULL,900,1200),
(9,0,1787420770,1772031435,0,0,NULL,'{\"file\":\"\"}',0,0,0,0,NULL,NULL,0,9,'Screenshot from https://caminofrances.info/',1200,601),
(10,0,1787420770,1772031435,0,0,NULL,'{\"file\":\"\"}',0,0,0,0,NULL,NULL,0,10,'Screenshot from https://www.pilgrim.es/',1200,1050);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1787421189,1787421188,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_e630126546.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_e630126546.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:61.0169491525424;s:8:\"\0*\0width\";d:1200;s:9:\"\0*\0height\";d:677.9661016949152;}}','05af1ee1909e978e8749832d83d219c0254403c1','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','e630126546',113,64),
(2,1787421189,1787421188,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_777f9f8161.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_777f9f8161.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:280;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:640;s:9:\"\0*\0height\";d:800;}}','07cc8c143875df5dddff480754dc330a3d0c7e58','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','777f9f8161',51,64),
(3,1787421189,1787421188,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_36510e0bc8.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_36510e0bc8.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:200;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:800;s:9:\"\0*\0height\";d:800;}}','bfdc0021fe3858932b8aabf20e481959929cd9ca','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','36510e0bc8',64,64),
(4,1787421189,1787421188,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_ba8e04ee95.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_ba8e04ee95.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:150;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:900;s:9:\"\0*\0height\";d:800;}}','5bc23a25d48be53e22819752e7c6bf41e151527d','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','ba8e04ee95',72,64),
(5,1787421189,1787421188,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_a683338280.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_a683338280.webp','','a:7:{s:5:\"width\";N;s:6:\"height\";i:64;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','92fd33366994563b175fa43f063f175f60baf50c','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','a683338280',96,64),
(6,1787421190,1787421190,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_9d46a7d1ce.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_9d46a7d1ce.webp',NULL,'a:7:{s:5:\"width\";s:4:\"960c\";s:6:\"height\";s:4:\"640c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','f365a0574819dec80839cd5f3800f40e02267865','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','9d46a7d1ce',960,640),
(7,1787421190,1787421190,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_82047d8c20.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_82047d8c20.webp',NULL,'a:7:{s:5:\"width\";s:4:\"720c\";s:6:\"height\";s:4:\"640c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:150;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:900;s:9:\"\0*\0height\";d:800;}}','50a9a388403f1c786f60755858e5bbb59fff78fc','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','82047d8c20',720,640),
(8,1787421190,1787421190,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_fe118fea8c.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_fe118fea8c.webp',NULL,'a:7:{s:5:\"width\";s:4:\"640c\";s:6:\"height\";s:4:\"640c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:200;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:800;s:9:\"\0*\0height\";d:800;}}','cc43d4762e0b994c9a375f528f667a01b1804673','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','fe118fea8c',640,640),
(9,1787421190,1787421190,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_d196ced23a.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_d196ced23a.webp',NULL,'a:7:{s:5:\"width\";s:4:\"512c\";s:6:\"height\";s:4:\"640c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:280;s:4:\"\0*\0y\";d:0;s:8:\"\0*\0width\";d:640;s:9:\"\0*\0height\";d:800;}}','afbc8af0388622283657d32d04831527fd8f38aa','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','d196ced23a',512,640),
(10,1787421190,1787421190,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_f6b7815c42.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_f6b7815c42.webp',NULL,'a:7:{s:5:\"width\";s:4:\"767c\";s:6:\"height\";s:4:\"432c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','935af23ebc2a0948fdd7b505ea7ad86e573d8fc0','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','f6b7815c42',767,432),
(11,1787421190,1787421190,1,1,'/_processed_/0/2/csm_max-kukurudziak-mrNvSPGBDk0-unsplash_0b0ff4effe.webp','csm_max-kukurudziak-mrNvSPGBDk0-unsplash_0b0ff4effe.webp',NULL,'a:7:{s:5:\"width\";s:4:\"479c\";s:6:\"height\";s:4:\"270c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";O:45:\"TYPO3\\CMS\\Core\\Imaging\\ImageManipulation\\Area\":4:{s:4:\"\0*\0x\";d:0;s:4:\"\0*\0y\";d:61.0169491525424;s:8:\"\0*\0width\";d:1200;s:9:\"\0*\0height\";d:677.9661016949152;}}','abb0f4e868d03de20aa5a5b9f07660e04b4f92d9','df13618ab849497a9136ed8a4cec93254e8cbd55','Image.CropScaleMask','0b0ff4effe',479,270);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,7,1787420770,1787420770,0,0,0,0,NULL,'',0,0,0,0,10,NULL,NULL,6,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(2,7,1787420770,1787420770,0,0,0,0,NULL,'',0,0,0,0,9,NULL,NULL,7,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(3,7,1787420770,1787420770,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,8,NULL,NULL,9,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0.25,\"width\":1,\"height\":0.5},\"selectedRatio\":\"3:2\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(4,7,1787420770,1787420770,0,0,0,0,NULL,'',0,0,0,0,7,NULL,NULL,11,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0.16666666666666666,\"width\":1,\"height\":0.6666666666666666},\"selectedRatio\":\"1:1\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(5,7,1787420770,1787420770,0,0,0,0,NULL,'',0,0,0,0,6,NULL,NULL,1,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0.0021875,\"y\":0,\"width\":0.995625,\"height\":1},\"selectedRatio\":\"16:9\",\"focusArea\":null,\"excludeFromSync\":false},\"sm\":{\"cropArea\":{\"x\":0.20018749999999996,\"y\":0,\"width\":0.5996250000000001,\"height\":1},\"selectedRatio\":\"16:15\",\"focusArea\":null,\"excludeFromSync\":false},\"md\":{\"cropArea\":{\"x\":0.12509375,\"y\":0,\"width\":0.7498125,\"height\":1},\"selectedRatio\":\"4:3\",\"focusArea\":null,\"excludeFromSync\":false},\"lg\":{\"cropArea\":{\"x\":0.078125,\"y\":0,\"width\":0.84375,\"height\":1},\"selectedRatio\":\"3:2\",\"focusArea\":null,\"excludeFromSync\":false},\"xl\":{\"cropArea\":{\"x\":0,\"y\":0.05555555555555555,\"width\":1,\"height\":0.8888888888888888},\"selectedRatio\":\"2:1\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(6,6,1787420770,1787420770,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,5,NULL,NULL,15,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(7,6,1787420770,1787420770,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,4,NULL,NULL,18,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(8,6,1787420770,1787420770,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"hidden\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,3,NULL,NULL,12,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0.288135593220339,\"width\":1,\"height\":0.423728813559322},\"selectedRatio\":\"16:9\",\"focusArea\":null,\"excludeFromSync\":false},\"sm\":{\"cropArea\":{\"x\":0,\"y\":0.1482176360225141,\"width\":1,\"height\":0.7035647279549718},\"selectedRatio\":\"16:15\",\"focusArea\":null,\"excludeFromSync\":false},\"md\":{\"cropArea\":{\"x\":0,\"y\":0.21867966991747934,\"width\":1,\"height\":0.5626406601650413},\"selectedRatio\":\"4:3\",\"focusArea\":null,\"excludeFromSync\":false},\"lg\":{\"cropArea\":{\"x\":0,\"y\":0.25,\"width\":1,\"height\":0.5},\"selectedRatio\":\"3:2\",\"focusArea\":null,\"excludeFromSync\":false},\"xl\":{\"cropArea\":{\"x\":0,\"y\":0.3125,\"width\":1,\"height\":0.375},\"selectedRatio\":\"2:1\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(9,5,1787420770,1787420770,0,0,0,0,NULL,'',0,0,0,0,2,NULL,NULL,21,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0.076271186440678,\"width\":1,\"height\":0.847457627118644},\"selectedRatio\":\"16:9\",\"focusArea\":null,\"excludeFromSync\":false},\"sm\":{\"cropArea\":{\"x\":0.14466666666666664,\"y\":0,\"width\":0.7106666666666667,\"height\":1},\"selectedRatio\":\"16:15\",\"focusArea\":null,\"excludeFromSync\":false},\"md\":{\"cropArea\":{\"x\":0.055666666666666725,\"y\":0,\"width\":0.8886666666666666,\"height\":1},\"selectedRatio\":\"4:3\",\"focusArea\":null,\"excludeFromSync\":false},\"lg\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"3:2\",\"focusArea\":null,\"excludeFromSync\":false},\"xl\":{\"cropArea\":{\"x\":0,\"y\":0.125,\"width\":1,\"height\":0.75},\"selectedRatio\":\"2:1\",\"focusArea\":null,\"excludeFromSync\":false}}',0),
(10,1,1787420770,1787420770,0,0,0,0,NULL,'',0,0,0,0,1,NULL,NULL,38,'tt_content','image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0.076271186440678,\"width\":1,\"height\":0.847457627118644},\"selectedRatio\":\"16:9\",\"focusArea\":null,\"excludeFromSync\":false},\"sm\":{\"cropArea\":{\"x\":0.23333333333333334,\"y\":0,\"width\":0.5333333333333333,\"height\":1},\"selectedRatio\":\"4:5\",\"focusArea\":null,\"excludeFromSync\":false},\"md\":{\"cropArea\":{\"x\":0.16666666666666666,\"y\":0,\"width\":0.6666666666666666,\"height\":1},\"selectedRatio\":\"1:1\",\"focusArea\":null,\"excludeFromSync\":false},\"lg\":{\"cropArea\":{\"x\":0.125,\"y\":0,\"width\":0.75,\"height\":1},\"selectedRatio\":\"9:8\",\"focusArea\":null,\"excludeFromSync\":false},\"xl\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"3:2\",\"focusArea\":null,\"excludeFromSync\":false}}',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1787420770,1787420770,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1787420770,1,'BE',1,0,1,'pages','{\"doktype\":\"1\",\"slug\":\"\\/\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":0,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"title\":\"Camino\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"no_search\":0,\"keywords\":null,\"description\":null,\"abstract\":null,\"author\":\"\",\"author_email\":\"\",\"is_siteroot\":1,\"l18n_cfg\":0,\"backend_layout\":\"pagets__CaminoStartpage\",\"backend_layout_next_level\":\"pagets__CaminoContentpage\",\"tsconfig_includes\":\"\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"sitemap_changefreq\":\"\",\"canonical_link\":\"\",\"og_title\":\"\",\"og_description\":null,\"twitter_title\":\"\",\"twitter_description\":null,\"tx_impexp_origuid\":1,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":1}',0,'0400$E7R-WO9AA8vWl0zBGhM9UjMsuP2outda:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1787420770,1,'BE',1,0,2,'pages','{\"doktype\":\"254\",\"slug\":\"\\/footer-navigation\",\"module\":\"\",\"hidden\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"title\":\"Footer navigation\",\"TSconfig\":null,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"tx_impexp_origuid\":2,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":2}',0,'0400$E7R-WO9AA8vWl0zBGhM9UjMsuP2outda:f11830df10b4b0bca2db34810c2241b3'),
(3,1787420770,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/privacy\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":2,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"title\":\"Privacy\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"no_search\":0,\"keywords\":null,\"description\":null,\"abstract\":null,\"author\":\"\",\"author_email\":\"\",\"is_siteroot\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"sitemap_changefreq\":\"\",\"canonical_link\":\"\",\"og_title\":\"\",\"og_description\":null,\"twitter_title\":\"\",\"twitter_description\":null,\"tx_impexp_origuid\":3,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":3}',0,'0400$E7R-WO9AA8vWl0zBGhM9UjMsuP2outda:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(4,1787420770,1,'BE',1,0,4,'pages','{\"doktype\":\"1\",\"slug\":\"\\/imprint\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":2,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"title\":\"Imprint\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"no_search\":0,\"keywords\":null,\"description\":null,\"abstract\":null,\"author\":\"\",\"author_email\":\"\",\"is_siteroot\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"sitemap_changefreq\":\"\",\"canonical_link\":\"\",\"og_title\":\"\",\"og_description\":null,\"twitter_title\":\"\",\"twitter_description\":null,\"tx_impexp_origuid\":4,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":4}',0,'0400$E7R-WO9AA8vWl0zBGhM9UjMsuP2outda:412add0b3eb6ec8f1cb6710aea92e21e'),
(5,1787420770,1,'BE',1,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/faqs\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"title\":\"FAQs\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"no_search\":0,\"keywords\":null,\"description\":null,\"abstract\":null,\"author\":\"\",\"author_email\":\"\",\"is_siteroot\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__CaminoContentpageSidebar\",\"backend_layout_next_level\":\"pagets__CaminoContentpage\",\"tsconfig_includes\":\"\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"sitemap_changefreq\":\"\",\"canonical_link\":\"\",\"og_title\":\"\",\"og_description\":null,\"twitter_title\":\"\",\"twitter_description\":null,\"tx_impexp_origuid\":5,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":5}',0,'0400$E7R-WO9AA8vWl0zBGhM9UjMsuP2outda:7ef5a4e3e11db8ac3fea4d7a75468161'),
(6,1787420770,1,'BE',1,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/packing-list\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":64,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"title\":\"Packing List\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"no_search\":0,\"keywords\":null,\"description\":null,\"abstract\":null,\"author\":\"\",\"author_email\":\"\",\"is_siteroot\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__CaminoContentpage\",\"backend_layout_next_level\":\"pagets__CaminoContentpage\",\"tsconfig_includes\":\"\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"sitemap_changefreq\":\"\",\"canonical_link\":\"\",\"og_title\":\"\",\"og_description\":null,\"twitter_title\":\"\",\"twitter_description\":null,\"tx_impexp_origuid\":6,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":6}',0,'0400$E7R-WO9AA8vWl0zBGhM9UjMsuP2outda:c75354c439a48dbde16b03ac553a080d'),
(7,1787420770,1,'BE',1,0,7,'pages','{\"doktype\":\"1\",\"slug\":\"\\/camino-route-comparison\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":0,\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":1,\"sorting\":32,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"title\":\"Camino Route Comparison\",\"TSconfig\":null,\"php_tree_stop\":0,\"extendToSubpages\":0,\"nav_title\":\"\",\"nav_hide\":0,\"subtitle\":\"\",\"target\":\"\",\"cache_tags\":\"\",\"no_search\":0,\"keywords\":null,\"description\":null,\"abstract\":null,\"author\":\"\",\"author_email\":\"\",\"is_siteroot\":0,\"l18n_cfg\":0,\"backend_layout\":\"pagets__CaminoContentpageSidebar\",\"backend_layout_next_level\":\"pagets__CaminoContentpageSidebar\",\"tsconfig_includes\":\"\",\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"sitemap_changefreq\":\"\",\"canonical_link\":\"\",\"og_title\":\"\",\"og_description\":null,\"twitter_title\":\"\",\"twitter_description\":null,\"tx_impexp_origuid\":7,\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_logo\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":7}',0,'0400$E7R-WO9AA8vWl0zBGhM9UjMsuP2outda:df50bb24cbce671cf0d61f42fbbef601'),
(8,1787420770,1,'BE',1,0,1,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":7,\"sys_language_uid\":0,\"uid_local\":\"10\",\"uid_foreign\":6,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":1}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:4cf496f597e7b095ce8b755e6cec3c0c'),
(9,1787420770,1,'BE',1,0,2,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":7,\"sys_language_uid\":0,\"uid_local\":\"9\",\"uid_foreign\":7,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":2}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:814fc0f720dfab882655a795e23a5b66'),
(10,1787420770,1,'BE',1,0,3,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\",\"pid\":7,\"sys_language_uid\":0,\"uid_local\":\"8\",\"uid_foreign\":9,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.25,\\\"width\\\":1,\\\"height\\\":0.5},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":3}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:d2c609347a4764200256b39b9425159a'),
(11,1787420770,1,'BE',1,0,4,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":7,\"sys_language_uid\":0,\"uid_local\":\"7\",\"uid_foreign\":11,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.16666666666666666,\\\"width\\\":1,\\\"height\\\":0.6666666666666666},\\\"selectedRatio\\\":\\\"1:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":4}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:cea5fcd7b97871880cfe3717d6b52ef4'),
(12,1787420770,1,'BE',1,0,5,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":7,\"sys_language_uid\":0,\"uid_local\":\"6\",\"uid_foreign\":1,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0.0021875,\\\"y\\\":0,\\\"width\\\":0.995625,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"16:9\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"sm\\\":{\\\"cropArea\\\":{\\\"x\\\":0.20018749999999996,\\\"y\\\":0,\\\"width\\\":0.5996250000000001,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"16:15\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"md\\\":{\\\"cropArea\\\":{\\\"x\\\":0.12509375,\\\"y\\\":0,\\\"width\\\":0.7498125,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"4:3\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"lg\\\":{\\\"cropArea\\\":{\\\"x\\\":0.078125,\\\"y\\\":0,\\\"width\\\":0.84375,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"xl\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.05555555555555555,\\\"width\\\":1,\\\"height\\\":0.8888888888888888},\\\"selectedRatio\\\":\\\"2:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":5}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:5f15a1453f67b933ed3314381f5d67e4'),
(13,1787420770,1,'BE',1,0,6,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\",\"pid\":6,\"sys_language_uid\":0,\"uid_local\":\"5\",\"uid_foreign\":15,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":6}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:768f9cd4e98812f969df7ebe17f11b50'),
(14,1787420770,1,'BE',1,0,7,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\",\"pid\":6,\"sys_language_uid\":0,\"uid_local\":\"4\",\"uid_foreign\":18,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":7}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:117c97010b9af15cb554d115dba4e316'),
(15,1787420770,1,'BE',1,0,8,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\",\"pid\":6,\"sys_language_uid\":0,\"uid_local\":\"3\",\"uid_foreign\":12,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.288135593220339,\\\"width\\\":1,\\\"height\\\":0.423728813559322},\\\"selectedRatio\\\":\\\"16:9\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"sm\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.1482176360225141,\\\"width\\\":1,\\\"height\\\":0.7035647279549718},\\\"selectedRatio\\\":\\\"16:15\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"md\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.21867966991747934,\\\"width\\\":1,\\\"height\\\":0.5626406601650413},\\\"selectedRatio\\\":\\\"4:3\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"lg\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.25,\\\"width\\\":1,\\\"height\\\":0.5},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"xl\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.3125,\\\"width\\\":1,\\\"height\\\":0.375},\\\"selectedRatio\\\":\\\"2:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":8}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(16,1787420770,1,'BE',1,0,9,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":5,\"sys_language_uid\":0,\"uid_local\":\"2\",\"uid_foreign\":21,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.076271186440678,\\\"width\\\":1,\\\"height\\\":0.847457627118644},\\\"selectedRatio\\\":\\\"16:9\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"sm\\\":{\\\"cropArea\\\":{\\\"x\\\":0.14466666666666664,\\\"y\\\":0,\\\"width\\\":0.7106666666666667,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"16:15\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"md\\\":{\\\"cropArea\\\":{\\\"x\\\":0.055666666666666725,\\\"y\\\":0,\\\"width\\\":0.8886666666666666,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"4:3\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"lg\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"xl\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.125,\\\"width\\\":1,\\\"height\\\":0.75},\\\"selectedRatio\\\":\\\"2:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":9}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:729356755eb8ee035abf6b9b02e20c8f'),
(17,1787420770,1,'BE',1,0,10,'sys_file_reference','{\"sorting_foreign\":1,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":1,\"sys_language_uid\":0,\"uid_local\":\"1\",\"uid_foreign\":38,\"tablenames\":\"tt_content\",\"fieldname\":\"image\",\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0.076271186440678,\\\"width\\\":1,\\\"height\\\":0.847457627118644},\\\"selectedRatio\\\":\\\"16:9\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"sm\\\":{\\\"cropArea\\\":{\\\"x\\\":0.23333333333333334,\\\"y\\\":0,\\\"width\\\":0.5333333333333333,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"4:5\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"md\\\":{\\\"cropArea\\\":{\\\"x\\\":0.16666666666666666,\\\"y\\\":0,\\\"width\\\":0.6666666666666666,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"1:1\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"lg\\\":{\\\"cropArea\\\":{\\\"x\\\":0.125,\\\"y\\\":0,\\\"width\\\":0.75,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"9:8\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false},\\\"xl\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"3:2\\\",\\\"focusArea\\\":null,\\\"excludeFromSync\\\":false}}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":10}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:b34a074e38840d41041eaee66c42bb0d'),
(18,1787420770,1,'BE',1,0,1,'tt_content','{\"CType\":\"camino_hero_small\",\"colPos\":\"2\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Camino Route Comparison\",\"header_link\":\"\",\"subheader\":\"Which Camino is Right for You?\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":1,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":1}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:7fa2c035f26826fe83eeecaaeddc4d40'),
(19,1787420770,1,'BE',1,0,2,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Camino de Finisterre \\u2013 The Way to the End of the World\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<ul><li data-list-item-id=\\\"e6e92c6a56010a050515893fcaefde71e\\\">Distance: 90 km (approx. 4 days)&nbsp;<\\/li><li data-list-item-id=\\\"e36427da8959003d95bee4be5f38ecc02\\\">Difficulty: Moderate&nbsp;<\\/li><li data-list-item-id=\\\"e18ebe20575240c5671424350f877f5a4\\\">Best for: Pilgrims who want to continue their journey beyond Santiago de Compostela<\\/li><\\/ul>\\n<p>The Camino de Finisterre is a natural extension of the pilgrimage for those who are not ready to stop walking. From Santiago, the route heads west through stunning coastal landscapes all the way to Cape Finisterre on the Atlantic Ocean \\u2014 a place once believed by medieval pilgrims to be the very edge of the known world.<\\/p>\\n<p>Reaching the cape is a deeply moving moment. Many pilgrims mark the occasion by watching the sunset over the ocean, a fitting and unforgettable end to an extraordinary journey.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":2,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":2}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:01dbc21fdb1263685b9147b3b1596ea8'),
(20,1787420770,1,'BE',1,0,3,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":64,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Camino Ingl\\u00e9s \\u2013 The English Way\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<ul><li data-list-item-id=\\\"e5c0ffc19bf05372033315bb33cb7b4e4\\\">Distance: 115 km (approx. 5\\u20137 days)&nbsp;<\\/li><li data-list-item-id=\\\"e61da94bfef3a661d0d4fde9d72eecc03\\\">Difficulty: Easy to Moderate&nbsp;<\\/li><li data-list-item-id=\\\"e7c9c2dbeab4936aa4d7e4d1e2239ce16\\\">Best for: Those with limited time or looking for a shorter, quieter Camino<\\/li><\\/ul>\\n<p>The Camino Ingl\\u00e9s starts from either A Coru\\u00f1a or Ferrol and offers a more compact route to Santiago without sacrificing the spirit of the pilgrimage. The path passes through small fishing villages and along beautiful coastal stretches, with a peaceful and introspective atmosphere that sets it apart from the busier routes.<\\/p>\\n<p>For those who cannot commit to a longer journey but still want a genuine Camino experience, the Ingl\\u00e9s is an ideal choice \\u2014 unhurried, scenic, and quietly rewarding.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":3,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":3}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:b92300cfb5d1d3645c9cb212a7f56c1f'),
(21,1787420770,1,'BE',1,0,4,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":32,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Camino Primitivo \\u2013 The Original Way\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<ul><li data-list-item-id=\\\"e6dee9acdc35898b2b524076fde110e53\\\">Distance: 320 km (approx. 12\\u201314 days)&nbsp;<\\/li><li data-list-item-id=\\\"e32bb04cb9beca73c9821d7a5cdda6284\\\">Difficulty: Challenging&nbsp;<\\/li><li data-list-item-id=\\\"e9a21debace0cfd3ae6179242de3ddbb6\\\">Best for: Adventurous pilgrims seeking solitude and a historic experience<\\/li><\\/ul>\\n<p>The Camino Primitivo holds a special place in the history of the pilgrimage \\u2014 it is the oldest of all the Camino routes, first walked by King Alfonso II in the 9th century. Beginning in Oviedo, it winds through the mountains and remote villages of Asturias and Galicia, offering a more isolated and contemplative experience with far fewer pilgrims along the way.<\\/p>\\n<p>The terrain is rugged and the climbs are demanding, but the stunning mountain scenery and sense of walking in the footsteps of the earliest pilgrims make it one of the most rewarding routes for those ready for the challenge.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":4,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":4}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:4d391f5ef79b8d5d10dffa8a07ca167d'),
(22,1787420770,1,'BE',1,0,5,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":16,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Camino del Norte \\u2013 The Northern Way\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<ul><li data-list-item-id=\\\"eb81577a658bbaaf3cbbdea9fab1eb8e9\\\">Distance: 825 km (approx. 34 days)&nbsp;<\\/li><li data-list-item-id=\\\"eac840a357cab461f47f7b67d0bf5efaa\\\">Difficulty: Challenging&nbsp;<\\/li><li data-list-item-id=\\\"e146334c28aac54323aa0c8689469dc74\\\">Best for: Experienced walkers seeking a rugged, coastal route with fewer crowds<\\/li><\\/ul>\\n<p>The Camino del Norte follows the northern coast of Spain along the Bay of Biscay, offering some of the most dramatic scenery of any Camino route. Steep climbs and descents through the Basque Country make it a physically demanding walk, but the reward is a quieter, more remote experience far from the busier trails further south.<\\/p>\\n<p>For experienced hikers looking for a greater challenge and a deeper sense of solitude, the Camino del Norte delivers spectacular coastal landscapes, fresh sea air, and a raw, unspoiled character that is hard to find elsewhere.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":5,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":5}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:c7626fc9bcba6f70beb6ebc085a400db'),
(23,1787420770,1,'BE',1,0,6,'tt_content','{\"CType\":\"textpic\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"26\",\"imagecols\":\"2\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":8,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Camino Portugu\\u00e9s \\u2013 The Portuguese Way\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<ul><li data-list-item-id=\\\"e3bd290e14521a07a8186e4d38d5ff2cf\\\">Distance: 240 km from Porto or 620 km from Lisbon (approx. 14\\u201342 days)&nbsp;<\\/li><li data-list-item-id=\\\"ee8b2be420786bfb38b1192315a1ecd4e\\\">Difficulty: Moderate&nbsp;<\\/li><li data-list-item-id=\\\"e53b26d6545840d67b839676e852b2560\\\">Best for: Those seeking a quieter route, coastal scenery, or a shorter journey<\\/li><\\/ul>\\n<p>The Camino Portugu\\u00eas winds through charming towns and villages, offering a mix of peaceful countryside and stunning coastal scenery. It is notably less crowded than the Camino Franc\\u00e9s, giving walkers more space to set their own pace and soak in the surroundings.<\\/p>\\n<p>Starting from Porto makes it an accessible option for those with less time, while beginning in Lisbon adds weeks of rich Portuguese landscapes and culture to the journey. Either way, it is a beautiful and rewarding route with a gentler, more relaxed atmosphere all the way to Santiago.<\\/p>\",\"imageborder\":0,\"image_zoom\":0,\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":6,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":6}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:c0db6803ab1ec5f70c36e2a72187867b'),
(24,1787420770,1,'BE',1,0,7,'tt_content','{\"CType\":\"textpic\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"25\",\"imagecols\":\"2\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":4,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Camino Franc\\u00e9s \\u2013 The French Way\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<ul><li data-list-item-id=\\\"e4427baccbfa326757c83a5dd887cb2ed\\\">Distance: approx. 800 km from Saint-Jean-Pied-de-Port (approx. 30\\u201335 days)&nbsp;<\\/li><li data-list-item-id=\\\"e808930077fe600a2c17c905a302e26ee\\\">Difficulty: Moderate to challenging&nbsp;<\\/li><li data-list-item-id=\\\"e7cb7a708fe43a9546e95a7280f3fd2c2\\\">Best for: First-time pilgrims seeking the classic Camino experience, iconic landmarks, and a vibrant walking community<\\/li><\\/ul>\\n<p>The Camino Franc\\u00e9s passes through some of the most iconic towns along any Camino route, including Pamplona, Burgos, and Le\\u00f3n. The landscape shifts from the lush green hills of the Pyrenees through vineyards and rolling countryside all the way to Galicia. With a lively atmosphere and a constant stream of fellow pilgrims, it is a route where community and connection come naturally.<\\/p>\\n<p>As the most popular and best-supported route, the Camino Franc\\u00e9s is an ideal choice for first-time pilgrims. Paths are well marked, accommodation is plentiful, and there is always someone to walk alongside.<\\/p>\",\"imageborder\":0,\"image_zoom\":0,\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":7,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":7}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:ea41b626baac59a1fe0716bc344af5d9'),
(25,1787420770,1,'BE',1,0,8,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"2\",\"tx_themecamino_header_style\":\"1\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":2,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Choosing the right Camino route depends on your fitness level, the time you have available, and what you are hoping to get out of the experience. Whether you are drawn to dramatic coastlines, mountain solitude, or the bustle of a well-travelled trail, there is a route that fits. Here is a comparison of the main routes to help you find the one that suits you best.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":8,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":8}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:2097d84972a039cb6bfe093b17089287'),
(26,1787420770,1,'BE',1,0,9,'tt_content','{\"CType\":\"camino_textmedia_teaser\",\"colPos\":\"1\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":1,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Where Every Path Leads Somewhere New\",\"header_link\":\"\",\"subheader\":\"Nature & Landscape\",\"bodytext\":\"<p>Rolling green hills, ancient forest tracks, and winding paths stretching endlessly ahead \\u2014 the Camino de Santiago is as much about the landscape as the destination. Lace up your boots and let the trail do the rest.<\\/p>\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":9,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":9}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:367f4f227870d8e2a11496a182574aa3'),
(27,1787420770,1,'BE',1,0,10,'tt_content','{\"CType\":\"camino_textteaser\",\"colPos\":\"1\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"bg-100\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":0,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Pack Light, Walk Far\",\"header_link\":\"\",\"subheader\":\"Everything you need fits in one bag\",\"bodytext\":\"<p>The Camino teaches you quickly that less is more. A well-chosen pack makes the difference between a joyful walk and a painful one. Discover our curated guide to Camino essentials and start your journey the right way.<\\/p>\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":10,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":10}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(28,1787420770,1,'BE',1,0,11,'tt_content','{\"CType\":\"camino_author\",\"colPos\":\"1\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":7,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Elena V\\u00e1squez\",\"subheader\":\" Senior Camino Guide\",\"bodytext\":\"The Camino does not care how fast you walk or how far you have come. It only asks that you keep going.\",\"tx_impexp_origuid\":11,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":11}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:7a14c618500ae24604910dfdd2f8ff12'),
(29,1787420770,1,'BE',1,0,12,'tt_content','{\"CType\":\"camino_hero_small\",\"colPos\":\"2\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":6,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Packing List\",\"header_link\":\"\",\"subheader\":\"for the Camino de Compostela\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":12,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":12}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:b13bbccfb8e2fc277be02db62485ced6'),
(30,1787420770,1,'BE',1,0,13,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"2\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"bg-10\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":6,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Remember: the key is to <strong>pack light<\\/strong>. The Camino is not about material comforts \\u2014 it is about the experience. Every item in your pack will be carried on your back for hundreds of kilometres, so when in doubt, leave it out. Keep it simple and let the journey speak for itself.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":13,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":13}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:aa58d78b4f5fe95c0d2d1cb36d041737'),
(31,1787420770,1,'BE',1,0,14,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":6,\"sorting\":64,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Optional Items\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Not essential, but worth considering depending on your preferences and the route you choose:<\\/p>\\n<ul><li data-list-item-id=\\\"eacc438e6b010624af619e33aea8d7f53\\\"><strong>Camera or GoPro<\\/strong>: for capturing the stunning landscapes and memorable moments along the way<\\/li><li data-list-item-id=\\\"e40d2f2a97b58000c944eb097b5ad2cfa\\\"><strong>Guidebook or map<\\/strong>: helpful for planning daily stages and finding points of interest<\\/li><li data-list-item-id=\\\"e72197f18bbaa28f23c1afe54a99d2fee\\\"><strong>Earplugs<\\/strong>: a small but invaluable addition for sleeping in shared albergue dormitories<\\/li><li data-list-item-id=\\\"e05a98d0eda19fb24b1a70b6822dc4336\\\"><strong>Thermal blanket<\\/strong>: lightweight and compact, useful to have in case of unexpected weather or emergencies<\\/li><\\/ul>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":14,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":14}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:338e104baa774eacaec42da729015b5f'),
(32,1787420770,1,'BE',1,0,15,'tt_content','{\"CType\":\"textpic\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"28\",\"imagecols\":\"2\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":6,\"sorting\":32,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Other Important Items\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>A few practical essentials to round out your pack:<\\/p>\\n<ul><li data-list-item-id=\\\"eff2ca7f64d3e4c62ac51e6a471392f37\\\"><strong>Pilgrim\'s Credential<\\/strong>: obtain this before setting off or at the first pilgrim office along the route \\u2014 you will need it for stamps and albergue access<\\/li><li data-list-item-id=\\\"e83b3d1cd22726e873f3698300ec0744d\\\"><strong>Phone and charger<\\/strong>: useful for navigation, weather updates, and emergency contacts<\\/li><li data-list-item-id=\\\"e9ffed5af0376900e1078d244c05dc80e\\\"><strong>Money<\\/strong>: carry euros for daily expenses such as food and accommodation; card payments are widely accepted but cash is handy in smaller villages<\\/li><li data-list-item-id=\\\"ed3851938702e8d268645d2fe9dba5a6c\\\"><strong>Camera<\\/strong>: for capturing the landscapes, people, and moments along the way<\\/li><li data-list-item-id=\\\"e34c75dfcca847ccf1751d024315e7ac0\\\"><strong>Notebook and pen<\\/strong>: many pilgrims find value in documenting their journey as they go<\\/li><\\/ul>\",\"imageborder\":0,\"image_zoom\":0,\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":15,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":15}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:cb118fde3da18e67b21a92b60bb8cbda'),
(33,1787420770,1,'BE',1,0,16,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":6,\"sorting\":16,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Extras\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>A few small additions that can make a big difference on the trail:<\\/p>\\n<ul><li data-list-item-id=\\\"ebf9c2c43f0cf7f0c05d3652cd0ed6fb0\\\"><strong>Sunscreen and lip balm<\\/strong>: SPF 30 or higher, reapply regularly on exposed stretches<\\/li><li data-list-item-id=\\\"e66fd2e7dfdf36ed675ed47cd7f5156f2\\\"><strong>First aid kit<\\/strong>: plasters, blister pads, pain relievers, and antiseptic cream at a minimum<\\/li><li data-list-item-id=\\\"e086f0bbf6d52516c9d55389f343cb0bc\\\"><strong>Water bottle or hydration system<\\/strong>: refill points are available along most routes<\\/li><li data-list-item-id=\\\"e8578c0f2337475c2943eaf8df9df9026\\\"><strong>Headlamp<\\/strong>: essential for early morning starts and late arrivals into town<\\/li><\\/ul>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":16,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":16}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:43f02d513e41a72738b96558f7ee9015'),
(34,1787420770,1,'BE',1,0,17,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":6,\"sorting\":8,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Toiletries\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Keep it minimal and travel-sized \\u2014 most albergues have basic facilities, and resupplying along the way is easy:<\\/p>\\n<ul><li data-list-item-id=\\\"e546ea834a98ec12e20c994e5e6448687\\\"><strong>Toothbrush and toothpaste<\\/strong>: travel-sized<\\/li><li data-list-item-id=\\\"e50afffb16a817156e2e187604331dc48\\\"><strong>Soap and shampoo<\\/strong>: travel-sized and eco-friendly where possible<\\/li><li data-list-item-id=\\\"e7f3eec303d72c3cc43921cb4a8dff697\\\"><strong>Toilet paper<\\/strong>: a small roll or pocket tissues for emergencies<\\/li><li data-list-item-id=\\\"e444b626ad96e7bcfb4d82e69dc1920bd\\\"><strong>Hand sanitizer<\\/strong>: essential for days when facilities are limited<\\/li><li data-list-item-id=\\\"e694760d1f86e9d075a60277788fbb8db\\\"><strong>Wet wipes<\\/strong>: handy for freshening up when a shower is not an option<\\/li><li data-list-item-id=\\\"e3b197e27a695e56b7b6f56f0eaa625eb\\\"><strong>Towel<\\/strong>: quick-dry and compact<\\/li><\\/ul>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":17,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":17}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:017157395cc6da9e5d2911de6dfd4b9e'),
(35,1787420770,1,'BE',1,0,18,'tt_content','{\"CType\":\"textpic\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"imagewidth\":null,\"imageheight\":null,\"imageorient\":\"27\",\"imagecols\":\"2\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":6,\"sorting\":4,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Clothing\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Pack light and stick to quick-dry fabrics \\u2014 cotton traps moisture and is best avoided on the trail:<\\/p>\\n<ul><li data-list-item-id=\\\"e3495eeaae4997ffdd6aff9b10184b4e8\\\"><strong>T-shirts or shirts<\\/strong>: 2\\u20133, quick-dry fabric<\\/li><li data-list-item-id=\\\"e2e4c302516a61547b324e23c0f1024b6\\\"><strong>Lightweight pants or shorts<\\/strong>: 2 pairs<\\/li><li data-list-item-id=\\\"e6045c5b158fa479cca22d5949c489d87\\\"><strong>Long-sleeve shirt<\\/strong>: 1, for sun protection or chilly evenings<\\/li><li data-list-item-id=\\\"e9418477ccb4d8e368d4aae08d0f0c1a1\\\"><strong>Lightweight fleece or jacket<\\/strong>: 1<\\/li><li data-list-item-id=\\\"e1dc2be38200268e61a3e2bffad13ee27\\\"><strong>Underwear<\\/strong>: 1\\u20132 sets, quick-dry<\\/li><li data-list-item-id=\\\"e01c8896728c1287c584822be0bb2e0c2\\\"><strong>Hat or cap<\\/strong>: 1, for sun protection<\\/li><li data-list-item-id=\\\"ebadc68e7d0ad77537ba7474b65b3b417\\\"><strong>Waterproof jacket or poncho<\\/strong>: essential \\u2014 rain is common, especially in Galicia<\\/li><li data-list-item-id=\\\"e5eef70e8621b31b9989e7008c0bf3f5d\\\"><strong>Buff or bandana<\\/strong>: useful for sweat, dust, or extra sun protection<\\/li><\\/ul>\",\"imageborder\":0,\"image_zoom\":0,\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":18,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":18}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:0a64be1ae1f9096cc345beb76e5e2095'),
(36,1787420770,1,'BE',1,0,19,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":6,\"sorting\":2,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Essential Items\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Before anything else, get these right \\u2014 your feet and your back will thank you for it:<\\/p>\\n<ul><li data-list-item-id=\\\"ea0427b43077372393b9d74d2ecb12e9d\\\"><strong>Backpack (35\\u201345L):<\\/strong> light and comfortable with good back support and a rain cover<\\/li><li data-list-item-id=\\\"ef8630e9da533c2be3fe4318cf443e4c0\\\"><strong>Walking shoes<\\/strong>: well-worn hiking shoes or sturdy walking shoes, waterproof if possible<\\/li><li data-list-item-id=\\\"e5bcfee4b8cce09f26e9478d3b29903c6\\\"><strong>Sandals<\\/strong>: lightweight, for after the day\'s walk and shared showers in albergues<\\/li><li data-list-item-id=\\\"e76ecc1b2981aec46f6bafa8e9306a630\\\"><strong>Walking socks<\\/strong>: moisture-wicking and blister-resistant, merino wool or synthetic, several pairs<\\/li><li data-list-item-id=\\\"e16e210e4038894be103a5edc1f216016\\\"><strong>Walking poles<\\/strong>: optional but helpful for steep descents and taking pressure off the knees<\\/li><\\/ul>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":19,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":19}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(37,1787420770,1,'BE',1,0,20,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":6,\"sorting\":1,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Walking the Camino de Compostela means traveling light \\u2014 every gram counts when you are covering hundreds of kilometres on foot. Here is a comprehensive packing list to help you prepare for the journey ahead, so you can focus on the walk and leave the worrying behind.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":20,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":20}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(38,1787420770,1,'BE',1,0,21,'tt_content','{\"CType\":\"camino_hero_small\",\"colPos\":\"2\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"FAQs\",\"header_link\":\"\",\"subheader\":\"Everything You Need to Know About the Camino de Compostela\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":21,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":21}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:7fd72e21409e45562c51e7581fc2cb0d'),
(39,1787420770,1,'BE',1,0,22,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"What is the Pilgrim\'s Credential and how do I get one?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>The <strong>Pilgrim\'s Credential<\\/strong>, or <strong>Credencial del Peregrino<\\/strong>, is a document you collect stamps in as you progress along the route. It is required for staying in albergues and serves as proof of your journey when collecting your <strong>Compostela Certificate<\\/strong> upon arrival in Santiago.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":22,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":22}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:1a929832156241f61c37ce68bcae4a3c'),
(40,1787420770,1,'BE',1,0,23,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":64,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"What should I do if I cannot finish the Camino?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Completing the entire route is not a requirement. Many pilgrims walk only a section of the Camino, and even a few days on the trail can be a meaningful and rewarding experience. There is no right or wrong way to walk it.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":23,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":23}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:0cf00ee1adffc41f8b3231c0de35256e'),
(41,1787420770,1,'BE',1,0,24,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":32,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Do I need to book accommodations in advance?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>During quieter seasons, advance booking is generally not necessary. However, if you are walking in summer or on a popular route such as the Camino Franc\\u00e9s, booking ahead is recommended to secure your spot.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":24,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":24}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:94bb7a1dbcc4ac71f45ee11546313fe2'),
(42,1787420770,1,'BE',1,0,25,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":16,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"How do I navigate the Camino?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>The routes are well marked with <strong>yellow arrows<\\/strong> and <strong>scallop shell symbols<\\/strong>, making it difficult to lose your way. Guidebooks, apps, and printed maps are also widely available to help you plan and navigate each stage.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":25,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":25}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:581bf77acde559fe457e0d401d2ada7b'),
(43,1787420770,1,'BE',1,0,26,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":8,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"What are the accommodations like?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Most pilgrims stay in <strong>albergues<\\/strong> \\u2014 simple, affordable pilgrim hostels located along the route. Guesthouses and hotels are also available for those who prefer more comfort, and some pilgrims choose to camp along the way.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":26,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":26}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:f6bb218c440a87df0e0eb5986e28af41'),
(44,1787420770,1,'BE',1,0,27,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":4,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Is the Camino suitable for beginners?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Yes. The Camino is accessible to walkers of all levels. You do not need to be an experienced hiker \\u2014 just have the right gear, a reasonable level of fitness, and the determination to keep going. Most routes involve daily walks of between 15 and 30 km on well-maintained paths.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":27,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":27}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:9c3671c42eb2c0522de6952ddc52c9a7'),
(45,1787420770,1,'BE',1,0,28,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":2,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Do I need to be religious to walk the Camino?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Not at all. While the Camino has deep spiritual roots, it is open to everyone. People of all faiths \\u2014 and none \\u2014 walk it for a wide range of reasons, from personal growth and adventure to connection and reflection.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":28,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":28}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:b5d015227f2b36f7786e2ff963ca9d51'),
(46,1787420770,1,'BE',1,0,29,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":1,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"How long does it take to walk the Camino?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>The time it takes depends on the route and your walking pace. The Camino Franc\\u00e9s, the most popular route, takes around <strong>30 to 35 days<\\/strong> from Saint-Jean-Pied-de-Port to Santiago. Those walking shorter sections can complete their journey in one to two weeks.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":29,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":29}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:12090f8e2b698e14ec860eca10ce232c'),
(47,1787420770,1,'BE',1,0,30,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":0,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"What is the Camino de Compostela?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>The Camino de Compostela, or Way of St. James, is a network of ancient pilgrimage routes leading to Santiago de Compostela in Spain. It has been a major spiritual and cultural route for over a thousand years, drawing pilgrims from all corners of the world.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":30,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":30}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:f6d670f6f6a9a0aecc0bb542c370acdf'),
(48,1787420770,1,'BE',1,0,31,'tt_content','{\"CType\":\"camino_textteaser\",\"colPos\":\"1\",\"header_layout\":\"2\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"bg-100\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Buen Camino Starts With Good Gear\",\"header_link\":\"\",\"subheader\":\"What to pack and what to leave behind\",\"bodytext\":\"<p>The right boots, the right pack, and a little preparation can make all the difference. Discover our essential packing guide before you hit the trail.<\\/p>\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":31,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":31}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:a338b89fc8d0d789df4b1fd4d37a174b'),
(49,1787420770,1,'BE',1,0,32,'tt_content','{\"CType\":\"camino_textteaser\",\"colPos\":\"1\",\"header_layout\":\"2\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"bg-10\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Walk at Your Own Pace\",\"header_link\":\"\",\"subheader\":\"No experience required\",\"bodytext\":\"<p>The Camino welcomes everyone \\u2014 seasoned hikers and first-time walkers alike. Find the route that matches your fitness, your time, and your spirit.<\\/p>\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":32,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":32}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:eeb3ef2adec88a8b5b3e3c510b74be1d'),
(50,1787420770,1,'BE',1,0,33,'tt_content','{\"CType\":\"camino_textteaser\",\"colPos\":\"1\",\"header_layout\":\"2\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"bg-80\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":5,\"sorting\":64,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Your First Step Starts Here\",\"header_link\":\"\",\"subheader\":\" Plan your Camino\",\"bodytext\":\"<p>Not sure where to begin? Our route guides, packing tips, and practical advice have everything you need to plan your first Camino with confidence.<\\/p>\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":33,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":33}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:c1c3d2254ecfaef40b15a18e94a89b96'),
(51,1787420770,1,'BE',1,0,34,'tt_content','{\"CType\":\"camino_hero_text_only\",\"colPos\":\"2\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":4,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Imprint\",\"header_link\":\"\",\"subheader\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"0\",\"tx_impexp_origuid\":34,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":34}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:5d9f35f4f50ff546dc3085666d071b48'),
(52,1787420770,1,'BE',1,0,35,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":4,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p><strong>Company Information<\\/strong><br \\/>[Company Name]<br \\/>[Street Address]<br \\/>[ZIP Code, City]<br \\/>[Country]<\\/p>\\n<p><strong>Represented by<\\/strong>:&nbsp;<br \\/>[Name], [Position]<\\/p>\\n<p><strong>Contact<\\/strong>:&nbsp;<br \\/>Phone: [+00 000 000000]<br \\/>Email: [email@example.com]<br \\/>Website: [www.example.com]<\\/p>\\n<p><strong>Commercial Register<\\/strong>: [Register Court] [Registration Number]<br \\/><strong>VAT Identification Number<\\/strong>: [VAT ID]<\\/p>\\n<p><strong>Responsible for content<\\/strong>:<br \\/>[Name]<br \\/>[Street Address]<br \\/>[ZIP Code, City]<\\/p>\\n<p><strong>Disclaimer<\\/strong>:<br \\/>This is dummy content for demonstration purposes only. Please replace all placeholder fields marked with [brackets] with your actual company information before publishing. The disclaimer text below should also be reviewed and adapted to your legal requirements.<\\/p>\\n<p>The contents of this website have been created with the utmost care. However, we cannot guarantee the accuracy, completeness, or timeliness of the information provided. External links have been checked at the time of linking; we accept no responsibility for their content.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":35,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":35}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:d31fbabb978b029b9ff62ab107e0a25e'),
(53,1787420770,1,'BE',1,0,36,'tt_content','{\"CType\":\"camino_hero_text_only\",\"colPos\":\"2\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":3,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Privacy\",\"header_link\":\"\",\"subheader\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"0\",\"tx_impexp_origuid\":36,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":36}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:6fdd460ee24b22c6f60683a1eee4989a'),
(54,1787420770,1,'BE',1,0,37,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":3,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p><strong>Privacy Policy<\\/strong><\\/p>\\n<p><i>This is dummy content for demonstration purposes only. Please replace all placeholder fields marked with [brackets] with your actual information and have this policy reviewed by a legal professional before publishing.<\\/i><\\/p>\\n<p><strong>1. Data Controller<\\/strong><\\/p>\\n<p>[Company Name] [Street Address] [ZIP Code, City] [Country]<br \\/>Email: [email@example.com] Phone: [+00 000 000000]<\\/p>\\n<p><strong>2. What Data We Collect<\\/strong><\\/p>\\n<p>We may collect the following types of personal data:<\\/p>\\n<ul><li data-list-item-id=\\\"e73f7ed080829a7ac2cac007851b4ae14\\\">Name and contact information (e.g. email address, phone number)<\\/li><li data-list-item-id=\\\"eb0a6937c4dcdde11e1e7b931d167e055\\\">Usage data (e.g. IP address, browser type, pages visited)<\\/li><li data-list-item-id=\\\"ecaca2c0bde0d835147d1d1224e40eeb7\\\">Data you provide voluntarily via contact forms or newsletter sign-ups<\\/li><\\/ul>\\n<p><strong>3. How We Use Your Data<\\/strong><\\/p>\\n<p>We use your data to:<\\/p>\\n<ul><li data-list-item-id=\\\"e0968fad6a96fb360521235e775efe232\\\">Provide and improve our services<\\/li><li data-list-item-id=\\\"ea6e7a178a7483e7bd304fa48e40bc95d\\\">Respond to your enquiries<\\/li><li data-list-item-id=\\\"ea10996ff2384057302f3e1c1335c9039\\\">Send newsletters or updates (only with your consent)<\\/li><li data-list-item-id=\\\"eae60168359bdcdb66d48e71ee7ec76ba\\\">Comply with legal obligations<\\/li><\\/ul>\\n<p><strong>4. Legal Basis for Processing<\\/strong><\\/p>\\n<p>We process your data on the following legal bases under GDPR Art. 6:<\\/p>\\n<ul><li data-list-item-id=\\\"ec27dc6763480f01e298ddf7cdfdebef5\\\">[Consent \\/ Contract \\/ Legal obligation \\/ Legitimate interest \\u2014 choose as applicable]<\\/li><\\/ul>\\n<p><strong>5. Data Sharing<\\/strong><\\/p>\\n<p>We do not sell your personal data. We may share data with [third-party service providers, e.g. hosting, analytics] only as necessary to operate our services.<\\/p>\\n<p><strong>6. Cookies<\\/strong><\\/p>\\n<p>This website uses cookies. [Describe your cookie usage here or refer to a separate cookie policy.]<\\/p>\\n<p><strong>7. Data Retention<\\/strong><\\/p>\\n<p>We retain personal data only for as long as necessary for the purposes stated above or as required by law. [Specify retention periods where applicable.]<\\/p>\\n<p><strong>8. Your Rights<\\/strong><\\/p>\\n<p>Under applicable data protection law you have the right to:<\\/p>\\n<ul><li data-list-item-id=\\\"efb0e8b720a64d18529aaa52d599138ac\\\">Access your personal data<\\/li><li data-list-item-id=\\\"e649073f2c3af6b9b76d808c2f4fdae7d\\\">Request correction or deletion<\\/li><li data-list-item-id=\\\"e50465a90f09b896b022b6dc6f2069c5d\\\">Object to or restrict processing<\\/li><li data-list-item-id=\\\"e8caaadbefc61a346dc99a4e58fca72ef\\\">Data portability<\\/li><li data-list-item-id=\\\"e346f5fc748730cb30e43802b58ffdd5d\\\">Lodge a complaint with a supervisory authority<\\/li><\\/ul>\\n<p>To exercise your rights, contact us at: [email@example.com]<\\/p>\\n<p><strong>9. Changes to This Policy<\\/strong><\\/p>\\n<p>We may update this privacy policy from time to time. The current version is always available on this page.<\\/p>\\n<p><strong>Last updated:<\\/strong> [Date]<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":37,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":37}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:63988be2047e9f9c26151c5b9b4770d7'),
(55,1787420770,1,'BE',1,0,38,'tt_content','{\"CType\":\"camino_hero\",\"colPos\":\"2\",\"header_layout\":\"2\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Walk the Camino de Compostela\",\"header_link\":\"\",\"subheader\":\"A journey of discovery, history, and transformation\",\"tx_themecamino_link\":\"7\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"chevron-right\",\"tx_impexp_origuid\":38,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":38}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:4bdce2eccaa2dfa57eb92d16572012a4'),
(56,1787420770,1,'BE',1,0,39,'tt_content','{\"CType\":\"camino_sociallinks\",\"colPos\":\"11\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Social Media Icons\",\"tx_impexp_origuid\":39,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":39}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:eb04e3ff75360f80fc27ed5d3e94f482'),
(57,1787420770,1,'BE',1,0,40,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"bg-80\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":64,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Start Your Camino\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Whether you walk for a week or a month, alone or with friends, the Camino meets you exactly where you are. There is no right or wrong way to walk it \\u2014 only your way.<\\/p>\\n<p>Buen Camino.&nbsp;<br \\/>Your journey begins with a single step.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":40,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":40}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:f63ce2811b6be061690bfdf008a41f07'),
(58,1787420770,1,'BE',1,0,41,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":32,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Santiago de Compostela\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Arriving in <strong>Santiago de Compostela<\\/strong> is a moment many pilgrims never forget. The main square fills with walkers from all over the world, coming together to celebrate, reflect, and attend the Pilgrim\'s Mass at the magnificent cathedral.<\\/p>\\n<p>Here you receive your <strong>Compostela Certificate<\\/strong>, the official recognition of your journey. But for many, reaching Santiago is not an ending \\u2014 it is the beginning of something that continues long after the walk is over.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":41,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":41}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:0d86f780a4565c319d6988991b035f3a'),
(59,1787420770,1,'BE',1,0,42,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":16,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Preparing for the Camino\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p><strong>When to Go<\\/strong><\\/p>\\n<p>Spring (April to June) is a favourite time to walk, with mild weather and blooming landscapes along the way. Autumn (September to October) offers cooler temperatures and fewer crowds, making it another excellent choice. Summer is popular but can be hot and busy, while winter is quiet and reflective \\u2014 rewarding for those prepared for more challenging conditions.<\\/p>\\n<p><strong>What to Pack<\\/strong><\\/p>\\n<p>Good preparation starts with comfortable walking shoes and a lightweight backpack. Bring weather-appropriate clothing and don\'t forget your Pilgrim Credential, used to collect stamps along the way and access pilgrim accommodation.<\\/p>\\n<p>Less is more on the Camino.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":42,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":42}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:5e996be55a352bc1f4f3f871c802dcec'),
(60,1787420770,1,'BE',1,0,43,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"bg-10\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":8,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"What to Expect on the Camino\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>Daily walks typically range from 15 to 30 km, with well-waymarked paths guided by yellow arrows and scallop shells. Accommodation options are plentiful, from affordable albergues to guesthouses and hotels, and the food along the way is simple, hearty, and full of regional character. More than anything, the Camino invites you into a slower, more mindful pace of life.<\\/p>\\n<p>No special training is required \\u2014 just preparation, curiosity, and an open heart.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":43,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":43}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:9390101edeadec5344c252f3b3b98ec9'),
(61,1787420770,1,'BE',1,0,44,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":4,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Why Walk the Camino?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p><strong>A Personal Journey&nbsp;<\\/strong><br \\/>Many pilgrims describe the Camino as a life-changing experience. Walking day after day creates space for reflection, clarity, and personal growth \\u2014 a rare opportunity to step away from the noise of everyday life.<\\/p>\\n<p><strong>History and Culture&nbsp;<\\/strong><br \\/>The routes are lined with Roman roads, medieval bridges, ancient churches, and UNESCO World Heritage sites, offering a rich journey through centuries of European history and tradition.<\\/p>\\n<p><strong>Community and Connection&nbsp;<\\/strong><br \\/>On the Camino, you are never truly alone. Friendships form naturally, languages mix freely, and shared meals around a table become memories that last long after the journey ends.<\\/p>\\n<p><strong>Nature and Simplicity&nbsp;<\\/strong><br \\/>From vineyards and forests to mountain passes and rugged coastlines, the Camino offers a chance to reconnect with the natural world \\u2014 and with yourself.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":44,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":44}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:3b272544b7c1a9f5690a42a5b760dca9'),
(62,1787420770,1,'BE',1,0,45,'tt_content','{\"CType\":\"camino_textmedia_teaser_grid\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"bg-80\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":2,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"The Main Camino Routes\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>The Camino de Compostela is a network of ancient pilgrimage routes, each leading to the Cathedral of Santiago de Compostela. Whether crossing mountain passes, following coastal paths, or winding through rolling countryside, every route has its own character and charm \\u2014 yet all share the same spirit of community, discovery, and adventure.<\\/p>\",\"tx_themecamino_link\":\"7\",\"tx_themecamino_link_label\":\"Compare all routes\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":45,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":45}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:ef25e3b02a873bda1a67249f52737086'),
(63,1787420770,1,'BE',1,0,46,'tt_content','{\"CType\":\"text\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":1,\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":1,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"What Is the Camino de Compostela?\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"<p>The <strong>Camino de Compostela<\\/strong>, also known as the <strong>Way of St. James<\\/strong>, is one of the world\'s most famous pilgrimage routes. It leads to the Cathedral of Santiago de Compostela in northwestern Spain, where the remains of Saint James the Apostle are said to rest.<\\/p>\\n<p>People from all walks of life travel the Camino:<\\/p>\\n<ul><li data-list-item-id=\\\"e7cee5c5bef25604019f517e8b2c2543e\\\">Pilgrims and spiritual seekers<\\/li><li data-list-item-id=\\\"ec742dc56cc6562510e5fb39fdcc61014\\\">Hikers and outdoor enthusiasts<\\/li><li data-list-item-id=\\\"e84898458aaab86be9e7c85024d176b48\\\">Cultural travelers and history lovers<\\/li><\\/ul>\\n<p>For many, it is more than just a journey \\u2014 it is an experience that stays with them long after they return home.<\\/p>\",\"linkToTop\":0,\"tx_themecamino_link\":\"\",\"tx_themecamino_link_label\":\"\",\"tx_themecamino_link_config\":\"0\",\"tx_themecamino_link_icon\":\"\",\"tx_impexp_origuid\":46,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":46}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:e98a5e9f23ca3235102a132a15092d64'),
(64,1787420770,1,'BE',1,0,47,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"10\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":0,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"\",\"tx_impexp_origuid\":47,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":47}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:4252955adc057961e279f23960919217'),
(65,1787420770,1,'BE',1,0,48,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"12\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"Camino Routes\",\"tx_impexp_origuid\":48,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":48}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:251e07b78ef27bce7293ccf22649b0e7'),
(66,1787420770,1,'BE',1,0,49,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"13\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"\",\"tx_impexp_origuid\":49,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":49}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:21e00c94bebf8e8e281aee5f17852bc1'),
(67,1787420770,1,'BE',1,0,50,'tt_content','{\"CType\":\"camino_linklist\",\"colPos\":\"14\",\"l18n_parent\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":64,\"fe_group\":\"\",\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"header\":\"\",\"tx_impexp_origuid\":50,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":50}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:ad9a6d0c0e3b3a79b7d6de8d41009d62'),
(68,1787420770,1,'BE',1,0,1,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":256,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"Camino Ingl\\u00e9s & Other Routes\",\"link\":\"7#3\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"More\",\"text\":\"The Camino Ingl\\u00e9s and several other lesser-known routes offer a wonderful alternative for those with limited time. Each has its own distinct character, landscapes, and history, making them a rewarding choice even for a shorter pilgrimage. No matter which route you choose, the spirit of the Camino remains the same.\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":1}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:dd25f3e4015703e546899e3ebabd22e9'),
(69,1787420770,1,'BE',1,0,2,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":128,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"Camino Primitivo\",\"link\":\"7#4\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"More\",\"text\":\"The Camino Primitivo is the oldest of all the Camino routes, tracing the original path walked by pilgrims centuries ago. Shorter than the Camino Franc\\u00e9s but more physically demanding, it winds through the mountains and forests of Asturias and Galicia. It is a rewarding choice for experienced walkers who prefer solitude and a deeper sense of history along the way.\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":2}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:e630006f70f868f0b396aa20096c8b34'),
(70,1787420770,1,'BE',1,0,3,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":64,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"7#2\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Camino de Finisterre\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":3}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:31a5c3914b4b733b3821fb4d1641a707'),
(71,1787420770,1,'BE',1,0,4,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":32,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"7#5\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Camino del Norte\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":4}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:8661ed16d641b0b51234a4acc99c9ffa'),
(72,1787420770,1,'BE',1,0,5,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":16,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/www.youtube.com\\/@typo3\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"YouTube\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":5}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:553a0b94d31bc6d75a24b3146e82c7b9'),
(73,1787420770,1,'BE',1,0,6,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":8,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"Camino del Norte\",\"link\":\"7#5\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"More\",\"text\":\"The Camino del Norte traces the northern coast of Spain, offering dramatic ocean views and rugged, unspoiled landscapes. It is a more demanding route than some of the other Caminos, but rewards those who walk it with stunning scenery and a quieter, more solitary experience away from the larger crowds.\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":6}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:a29cdb6aa8f1e8ff8bf21ca01298a2a5'),
(74,1787420770,1,'BE',1,0,7,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":4,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"7#3\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Camino Ingl\\u00e9s\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":7}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:c42cb0131c55877d6432782967a88164'),
(75,1787420770,1,'BE',1,0,8,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":2,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"3\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":8}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:61d4a0fd373c5c9c133848e4e4d98b45'),
(76,1787420770,1,'BE',1,0,9,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":1,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"7#6\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Camino Portugu\\u00e9s\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":9}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:e5291482bfd8fb9250717d6978c85a9d'),
(77,1787420770,1,'BE',1,0,10,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"5\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"FAQs\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":10}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:e94df647818cf75d345ec41f8addf24c'),
(78,1787420770,1,'BE',1,0,11,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":256,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/www.facebook.com\\/typo3\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Facebook\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":11}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:fac8d56653c7e446ea9b5b9f3a3630fe'),
(79,1787420770,1,'BE',1,0,12,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":128,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"Camino Portugu\\u00e9s\",\"link\":\"7#6\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"More\",\"text\":\"The Camino Portugu\\u00eas begins in either Lisbon or Porto and makes its way north through Portugal into Galicia. It is known for its coastal scenery, charming towns, and the warm hospitality of its people. With a gentler walking profile, it is a popular choice for those looking for a less demanding but equally rewarding journey.\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":12}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:33a5acd1e8390d67d0bf39f5ec009db0'),
(80,1787420770,1,'BE',1,0,13,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":64,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"7#4\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Camino Primitivo\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":13}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:0f1fa0fa151eb565f5e8d354a5f5cea8'),
(81,1787420770,1,'BE',1,0,14,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":32,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"4\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":14}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:d00d327965770bf21b1db955767c244b'),
(82,1787420770,1,'BE',1,0,15,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":16,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"7#7\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Camino Franc\\u00e9s\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":15}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:0e96270cc28b0e0448e8c8d3bf6087ec'),
(83,1787420770,1,'BE',1,0,16,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":8,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"6\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Packing List\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":16}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:e341eebdf1a80bbe5c2280ad0071cbfd'),
(84,1787420770,1,'BE',1,0,17,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":4,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"\",\"link\":\"https:\\/\\/www.instagram.com\\/typo3_official\\/\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"Instagram\",\"text\":null,\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":17}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:cdce7c684835f1aff41674d980a594c4'),
(85,1787420770,1,'BE',1,0,18,'tx_themecamino_list_item','{\"hidden\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"{\\\"link\\\":\\\"\\\"}\",\"pid\":1,\"sorting_foreign\":2,\"sys_language_uid\":0,\"l10n_source\":0,\"fieldname\":\"tx_themecamino_list_elements\",\"category\":\"\",\"date\":null,\"header\":\"Camino Franc\\u00e9s\",\"link\":\"7#7\",\"link_config\":\"\",\"link_icon\":\"\",\"link_label\":\"More\",\"text\":\"The Camino Franc\\u00e9s is the most popular route, beginning in Saint-Jean-Pied-de-Port in southern France before crossing the Pyrenees and winding through northern Spain. It passes through historic towns and vibrant villages, with well-established pilgrim services and a lively trail community all the way to Santiago.\",\"crdate\":1787420770,\"t3ver_stage\":0,\"tstamp\":1787420770,\"uid\":18}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:0dce8909c9bb0314b88774bb759d2987'),
(86,1787420770,2,'BE',1,0,10,'sys_file_metadata','{\"oldRecord\":{\"crdate\":1787420770,\"l10n_diffsource\":\"\",\"categories\":\"\",\"file\":10,\"description\":null},\"newRecord\":{\"crdate\":\"1772031435\",\"l10n_diffsource\":\"{\\\"file\\\":\\\"\\\"}\",\"categories\":\"0\",\"file\":0,\"description\":\"Screenshot from https:\\/\\/www.pilgrim.es\\/\"}}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:8dbe03b4f416ae13206477614b77d4ff'),
(87,1787420770,2,'BE',1,0,9,'sys_file_metadata','{\"oldRecord\":{\"crdate\":1787420770,\"l10n_diffsource\":\"\",\"categories\":\"\",\"file\":9,\"description\":null},\"newRecord\":{\"crdate\":\"1772031435\",\"l10n_diffsource\":\"{\\\"file\\\":\\\"\\\"}\",\"categories\":\"0\",\"file\":0,\"description\":\"Screenshot from https:\\/\\/caminofrances.info\\/\"}}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:4530a2995a6a3258dbbc4f4d138894bf'),
(88,1787420770,2,'BE',1,0,8,'sys_file_metadata','{\"oldRecord\":{\"crdate\":1787420770,\"l10n_diffsource\":\"\",\"categories\":\"\",\"file\":8},\"newRecord\":{\"crdate\":\"1772031435\",\"l10n_diffsource\":\"{\\\"file\\\":\\\"\\\"}\",\"categories\":\"0\",\"file\":0}}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:82fd7c26cbfc363ada265fa6697c28df'),
(89,1787420770,2,'BE',1,0,7,'sys_file_metadata','{\"oldRecord\":{\"crdate\":1787420770,\"l10n_diffsource\":\"\",\"categories\":\"\",\"file\":7,\"description\":null},\"newRecord\":{\"crdate\":\"1772031435\",\"l10n_diffsource\":\"{\\\"file\\\":\\\"\\\"}\",\"categories\":\"0\",\"file\":0,\"description\":\"Photo by Andrew Milko on Unsplash\"}}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:68800764a76bac096a27cd24eed52028'),
(90,1787420770,2,'BE',1,0,6,'sys_file_metadata','{\"oldRecord\":{\"crdate\":1787420770,\"l10n_diffsource\":\"\",\"categories\":\"\",\"file\":6,\"description\":null},\"newRecord\":{\"crdate\":\"1772031435\",\"l10n_diffsource\":\"{\\\"file\\\":\\\"\\\"}\",\"categories\":\"0\",\"file\":0,\"description\":\"Photo by Damien Dufour on Unsplash\"}}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:e6a344f1ab5990f58a7b79283de7fd48'),
(91,1787420770,2,'BE',1,0,5,'sys_file_metadata','{\"oldRecord\":{\"crdate\":1787420770,\"l10n_diffsource\":\"\",\"categories\":\"\",\"file\":5,\"description\":null},\"newRecord\":{\"crdate\":\"1772031435\",\"l10n_diffsource\":\"{\\\"file\\\":\\\"\\\"}\",\"categories\":\"0\",\"file\":0,\"description\":\"Photo by Victoriano Izquierdoon Unsplash\"}}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:024ca1b2aca7cde18b3a4741b930c46f'),
(92,1787420770,2,'BE',1,0,4,'sys_file_metadata','{\"oldRecord\":{\"crdate\":1787420770,\"l10n_diffsource\":\"\",\"categories\":\"\",\"file\":4,\"description\":null},\"newRecord\":{\"crdate\":\"1772031435\",\"l10n_diffsource\":\"{\\\"file\\\":\\\"\\\"}\",\"categories\":\"0\",\"file\":0,\"description\":\"Photo by Tomasz Anusiewicz on Unsplash\"}}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:3579fcab7d87ce942f97f120e288dcaa'),
(93,1787420770,2,'BE',1,0,3,'sys_file_metadata','{\"oldRecord\":{\"crdate\":1787420770,\"l10n_diffsource\":\"\",\"categories\":\"\",\"file\":3,\"description\":null},\"newRecord\":{\"crdate\":\"1772031435\",\"l10n_diffsource\":\"{\\\"file\\\":\\\"\\\"}\",\"categories\":\"0\",\"file\":0,\"description\":\"Photo by Jon Tyson on Unsplash\"}}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:744716d0525b6dd2220c8ea203b2700f'),
(94,1787420770,2,'BE',1,0,2,'sys_file_metadata','{\"oldRecord\":{\"crdate\":1787420770,\"l10n_diffsource\":\"\",\"categories\":\"\",\"file\":2,\"description\":null},\"newRecord\":{\"crdate\":\"1772031435\",\"l10n_diffsource\":\"{\\\"file\\\":\\\"\\\"}\",\"categories\":\"0\",\"file\":0,\"description\":\"Photo by Bernard Wortelboer on Unsplash\"}}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:fc9eb619b911d59baba52010a39bba35'),
(95,1787420770,2,'BE',1,0,1,'sys_file_metadata','{\"oldRecord\":{\"crdate\":1787420770,\"l10n_diffsource\":\"\",\"categories\":\"\",\"file\":1,\"description\":null},\"newRecord\":{\"crdate\":\"1772031435\",\"l10n_diffsource\":\"{\\\"file\\\":\\\"\\\"}\",\"categories\":\"0\",\"file\":0,\"description\":\"Photo by Max Kukurudziak on Unsplash\"}}',0,'0400$EDS-7zGaODR2tL2Fz1PgSyAnY-1BF2Rf:854e1c32ce3c7fa132091f2f1dea69c4'),
(96,1787420770,2,'BE',1,0,50,'tt_content','{\"oldRecord\":{\"tx_themecamino_list_elements\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_themecamino_list_elements\":2,\"l18n_diffsource\":\"{\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:ad9a6d0c0e3b3a79b7d6de8d41009d62'),
(97,1787420770,2,'BE',1,0,49,'tt_content','{\"oldRecord\":{\"tx_themecamino_list_elements\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_themecamino_list_elements\":3,\"l18n_diffsource\":\"{\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:21e00c94bebf8e8e281aee5f17852bc1'),
(98,1787420770,2,'BE',1,0,48,'tt_content','{\"oldRecord\":{\"tx_themecamino_list_elements\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_themecamino_list_elements\":3,\"l18n_diffsource\":\"{\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:251e07b78ef27bce7293ccf22649b0e7'),
(99,1787420770,2,'BE',1,0,47,'tt_content','{\"oldRecord\":{\"tx_themecamino_list_elements\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_themecamino_list_elements\":2,\"l18n_diffsource\":\"{\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:4252955adc057961e279f23960919217'),
(100,1787420770,2,'BE',1,0,45,'tt_content','{\"oldRecord\":{\"tx_themecamino_list_elements\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_themecamino_list_elements\":5,\"l18n_diffsource\":\"{\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:ef25e3b02a873bda1a67249f52737086'),
(101,1787420770,2,'BE',1,0,39,'tt_content','{\"oldRecord\":{\"tx_themecamino_list_elements\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_themecamino_list_elements\":3,\"l18n_diffsource\":\"{\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:eb04e3ff75360f80fc27ed5d3e94f482'),
(102,1787420770,2,'BE',1,0,38,'tt_content','{\"oldRecord\":{\"image\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"image\":1,\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:4bdce2eccaa2dfa57eb92d16572012a4'),
(103,1787420770,2,'BE',1,0,21,'tt_content','{\"oldRecord\":{\"image\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"image\":1,\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:7fd72e21409e45562c51e7581fc2cb0d'),
(104,1787420770,2,'BE',1,0,18,'tt_content','{\"oldRecord\":{\"image\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"image\":1,\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:0a64be1ae1f9096cc345beb76e5e2095'),
(105,1787420770,2,'BE',1,0,15,'tt_content','{\"oldRecord\":{\"image\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"image\":1,\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:cb118fde3da18e67b21a92b60bb8cbda'),
(106,1787420770,2,'BE',1,0,12,'tt_content','{\"oldRecord\":{\"image\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"image\":1,\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:b13bbccfb8e2fc277be02db62485ced6'),
(107,1787420770,2,'BE',1,0,11,'tt_content','{\"oldRecord\":{\"image\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"},\"newRecord\":{\"image\":1,\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:7a14c618500ae24604910dfdd2f8ff12'),
(108,1787420770,2,'BE',1,0,9,'tt_content','{\"oldRecord\":{\"image\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"image\":1,\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:367f4f227870d8e2a11496a182574aa3'),
(109,1787420770,2,'BE',1,0,7,'tt_content','{\"oldRecord\":{\"image\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"image\":1,\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:ea41b626baac59a1fe0716bc344af5d9'),
(110,1787420770,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"image\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"image_zoom\\\":\\\"\\\",\\\"imageborder\\\":\\\"\\\",\\\"imagecols\\\":\\\"\\\",\\\"imageheight\\\":\\\"\\\",\\\"imageorient\\\":\\\"\\\",\\\"imagewidth\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"image\":1,\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:c0db6803ab1ec5f70c36e2a72187867b'),
(111,1787420770,2,'BE',1,0,1,'tt_content','{\"oldRecord\":{\"image\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"image\\\":\\\"\\\",\\\"l10n_source\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_impexp_origuid\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\",\\\"tx_themecamino_link\\\":\\\"\\\",\\\"tx_themecamino_link_config\\\":\\\"\\\",\\\"tx_themecamino_link_icon\\\":\\\"\\\",\\\"tx_themecamino_link_label\\\":\\\"\\\"}\"},\"newRecord\":{\"image\":1,\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:7fa2c035f26826fe83eeecaaeddc4d40'),
(112,1787420770,2,'BE',1,0,1,'sys_file_metadata','{\"oldRecord\":{\"file\":0},\"newRecord\":{\"file\":\"1\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:854e1c32ce3c7fa132091f2f1dea69c4'),
(113,1787420770,2,'BE',1,0,2,'sys_file_metadata','{\"oldRecord\":{\"file\":0},\"newRecord\":{\"file\":\"2\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:fc9eb619b911d59baba52010a39bba35'),
(114,1787420770,2,'BE',1,0,3,'sys_file_metadata','{\"oldRecord\":{\"file\":0},\"newRecord\":{\"file\":\"3\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:744716d0525b6dd2220c8ea203b2700f'),
(115,1787420770,2,'BE',1,0,4,'sys_file_metadata','{\"oldRecord\":{\"file\":0},\"newRecord\":{\"file\":\"4\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:3579fcab7d87ce942f97f120e288dcaa'),
(116,1787420770,2,'BE',1,0,5,'sys_file_metadata','{\"oldRecord\":{\"file\":0},\"newRecord\":{\"file\":\"5\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:024ca1b2aca7cde18b3a4741b930c46f'),
(117,1787420770,2,'BE',1,0,6,'sys_file_metadata','{\"oldRecord\":{\"file\":0},\"newRecord\":{\"file\":\"6\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:e6a344f1ab5990f58a7b79283de7fd48'),
(118,1787420770,2,'BE',1,0,7,'sys_file_metadata','{\"oldRecord\":{\"file\":0},\"newRecord\":{\"file\":\"7\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:68800764a76bac096a27cd24eed52028'),
(119,1787420770,2,'BE',1,0,8,'sys_file_metadata','{\"oldRecord\":{\"file\":0},\"newRecord\":{\"file\":\"8\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:82fd7c26cbfc363ada265fa6697c28df'),
(120,1787420770,2,'BE',1,0,9,'sys_file_metadata','{\"oldRecord\":{\"file\":0},\"newRecord\":{\"file\":\"9\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:4530a2995a6a3258dbbc4f4d138894bf'),
(121,1787420770,2,'BE',1,0,10,'sys_file_metadata','{\"oldRecord\":{\"file\":0},\"newRecord\":{\"file\":\"10\"}}',0,'0400$93aEefoWeZdjx8Exv4lWwKvZWb-rXFZp:8dbe03b4f416ae13206477614b77d4ff'),
(122,1787420770,2,'BE',1,0,45,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"tx_themecamino_list_elements\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"tx_themecamino_link\\\":\\\"\\\"}\"}}',0,'0400$rYyVzTYqRsTqPqkqbwgc_vltPssoOLM7:ef25e3b02a873bda1a67249f52737086'),
(123,1787420770,2,'BE',1,0,38,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"image\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"tx_themecamino_link\\\":\\\"\\\"}\"}}',0,'0400$rYyVzTYqRsTqPqkqbwgc_vltPssoOLM7:4bdce2eccaa2dfa57eb92d16572012a4');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1787420770,1,2,45,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":45,\"history\":\"122\"}',1,0,'',0,'','info',NULL,NULL),
(2,1787420770,1,2,38,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','','{\"table\":\"tt_content\",\"uid\":38,\"history\":\"123\"}',1,0,'',0,'','info',NULL,NULL),
(3,1787420887,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1476107295: PHP Warning: preg_match(): Compilation failed: quantifier does not follow a repeatable item at offset 1 in /var/www/html/vendor/typo3/cms-core/Classes/Middleware/VerifyHostHeader.php line 101 | TYPO3\\CMS\\Core\\Error\\Exception thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/ErrorHandler.php in line 142. Requested URL: https://perm-kit-typo3-example.local/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(4,1787421183,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('05e31069018e49ad1a3b1dcab0336352','tt_content',49,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',13,'',0,0,2147483647,0,0,''),
('087374f47c98d89b43c0c85ad707ab36','tt_content',45,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',2,0,'tx_themecamino_list_item',6,'',0,0,2147483647,0,0,''),
('0a3d49a43dd6e7ece4b6c2de0580468d','sys_file_reference',2,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',9,'',0,0,2147483647,0,0,''),
('0b9523b8656eea7eb65b918de4e72364','tt_content',48,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',9,'',0,0,2147483647,0,0,''),
('0cc620d9c54d8bbc43cbef65ca87e898','tx_themecamino_list_item',6,'link',0,0,2147483647,0,'','typolink','8c314417bb1dfc7fc9917cc7b04df3f2:0',0,0,'tt_content',5,'',0,0,2147483647,0,0,''),
('1069e62ca6aa2f0efee79416cc2e1e72','tt_content',45,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',18,'',0,0,2147483647,0,0,''),
('107849c8889029b5ef67048442f77f62','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',10,'',0,0,2147483647,0,0,''),
('152180b67625112f6965cdd848944754','tx_themecamino_list_item',1,'link',0,0,2147483647,0,'','typolink','ec20807294251533bdcd1d534b5fc2df:0',0,0,'tt_content',3,'',0,0,2147483647,0,0,''),
('15fd99ffa7357c9b1d4290d396f2780f','sys_file_metadata',4,'file',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('16b37bd4a0f17e775e3adf93a8b52516','tt_content',48,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',15,'',0,0,2147483647,0,0,''),
('1963d6d547840a6691e16c07ed1e60ac','tx_themecamino_list_item',4,'link',0,0,2147483647,0,'','typolink','c47f0d5bb9be0643b33351a8facdaf1d:0',0,0,'tt_content',5,'',0,0,2147483647,0,0,''),
('19a2faeeadbcd48af620b2e51e4fdd17','tt_content',45,'tx_themecamino_link',0,0,2147483647,0,'','typolink','f0b10b729568b362e2512827105160c7:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('1d4e82dd90fdc1f703a4740fb9440ca0','tt_content',49,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',7,'',0,0,2147483647,0,0,''),
('22e73aa869347277eb1f98fc138067d2','sys_file_metadata',2,'file',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('246f1108002d2250da745fe754474712','tx_themecamino_list_item',13,'link',0,0,2147483647,0,'','typolink','0fea545b8bd02e74ecca72afc84f647e:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('2ce902cae778b9a56de801356dcddf0c','sys_file_reference',7,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',4,'',0,0,2147483647,0,0,''),
('2f3a9e6148446886db1dd50fbd8a3354','sys_file_reference',9,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',2,'',0,0,2147483647,0,0,''),
('3061a446df348eeb85dc3de05f8553a4','tx_themecamino_list_item',3,'link',0,0,2147483647,0,'','typolink','32d2f1d7dc8e7917d9f04df2a6ed27e4:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('30e4ee1609ad27501cf69a2654f81b66','tx_themecamino_list_item',2,'link',0,0,2147483647,0,'','typolink','9bd4e954461e64da67767dfd21ef95c8:0',0,0,'tt_content',4,'',0,0,2147483647,0,0,''),
('38be22f8d7dd8631f54cf32d6debd930','tx_themecamino_list_item',1,'link',0,0,2147483647,0,'','typolink','610cbb33b3873e48393b131cb801640a:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('3b5fca447fb7791e6b890192d2806662','tx_themecamino_list_item',4,'link',0,0,2147483647,0,'','typolink','bfe2d7c4c08d800235592fb491566934:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('3cefb75ca745e90d2a1a38fbc0fccb43','tt_content',21,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',9,'',0,0,2147483647,0,0,''),
('422302d3cf0bfb6da70759a51ed9aba8','tx_themecamino_list_item',12,'link',0,0,2147483647,0,'','typolink','1d859ab160c187369b7d1853b7c2cfcb:0',0,0,'tt_content',6,'',0,0,2147483647,0,0,''),
('4396206b493a55f5591711d43a43266e','tx_themecamino_list_item',7,'link',0,0,2147483647,0,'','typolink','08bd011eaf009767d3d94e29659f161b:0',0,0,'tt_content',3,'',0,0,2147483647,0,0,''),
('442d0b5aa0e4b5342c7a5a5653d56658','tx_themecamino_list_item',13,'link',0,0,2147483647,0,'','typolink','2576ef7c9e8f1a5fcceb49ceb4f884cf:0',0,0,'tt_content',4,'',0,0,2147483647,0,0,''),
('490fbf4362f8e7dcb44d171d9f3be975','tt_content',45,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',4,0,'tx_themecamino_list_item',1,'',0,0,2147483647,0,0,''),
('49a2a020e5a3f76552f868c5633cd764','tx_themecamino_list_item',10,'link',0,0,2147483647,0,'','typolink','dd2b19377953a5241ce27cd624fa606a:0',0,0,'pages',5,'',0,0,2147483647,0,0,''),
('4b602b021da9699d9e12a03ccd4c134d','sys_file_reference',6,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',5,'',0,0,2147483647,0,0,''),
('4cdb029fc7f678f995fe6ab9ae56aa05','tx_themecamino_list_item',18,'link',0,0,2147483647,0,'','typolink','c61069f8ff0a300fb35291bad575ff5d:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('504e1e0c1635a14b0c13c5e204f39f37','tt_content',1,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',5,'',0,0,2147483647,0,0,''),
('5188f384c25b822669b39c3b400bd35d','tx_themecamino_list_item',14,'link',0,0,2147483647,0,'','typolink','7f7f686617170d1421363b2a6b9fb738:0',0,0,'pages',4,'',0,0,2147483647,0,0,''),
('522e8d6cab27b43b6493fac5cd39a3ca','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('59085e06a5b4aab704af4fe13e7f9f25','tt_content',39,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',17,'',0,0,2147483647,0,0,''),
('5a66d86dc352112858d15389591eb2b0','tt_content',45,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',12,'',0,0,2147483647,0,0,''),
('619c3ae7e2b10d37a9284bd2ca5d9363','tx_themecamino_list_item',2,'link',0,0,2147483647,0,'','typolink','5c58dcd9811feb14896f016056788445:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('6204477910491c93def33dc814ace2fc','tx_themecamino_list_item',6,'link',0,0,2147483647,0,'','typolink','f2b704270d906067488966be756cb840:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('639ad7da6747b34084e96c9360ebc7e4','sys_file_metadata',9,'file',0,0,2147483647,0,'','','',0,0,'sys_file',9,'',0,0,2147483647,0,0,''),
('64b2a394e0c1aa7126a38e5bebdb72a5','sys_file',8,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('64ed2396e3ad0c418faeab4beedfd5f9','tt_content',45,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',3,0,'tx_themecamino_list_item',2,'',0,0,2147483647,0,0,''),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('69b826151ca621176aea1b27d0f0508a','tx_themecamino_list_item',18,'link',0,0,2147483647,0,'','typolink','c406a12510c194d084a1435c8ca8fddd:0',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('6d41860ecc914e6b7319cbc920ad98cc','tx_themecamino_list_item',16,'link',0,0,2147483647,0,'','typolink','fa32ddb757323b7c08cb0179cbeac638:0',0,0,'pages',6,'',0,0,2147483647,0,0,''),
('6d64df115856bb6c637d8707449e2676','tx_themecamino_list_item',9,'link',0,0,2147483647,0,'','typolink','84107f75d566dd2261477a80424cd84e:0',0,0,'tt_content',6,'',0,0,2147483647,0,0,''),
('7106458409a1a556fb1c60516e842efb','tt_content',18,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',7,'',0,0,2147483647,0,0,''),
('749c139782b4eb23b38db282c37d5815','tt_content',50,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',16,'',0,0,2147483647,0,0,''),
('76befe87324e6bb22075cde92dd1d498','tt_content',39,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',2,0,'tx_themecamino_list_item',5,'',0,0,2147483647,0,0,''),
('77c1b13d2222b2a264bf63ae39a484d0','sys_file',9,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('786e131be796ac4b5888c15f165f7546','sys_file',7,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('799a32a25fe75ff23acede08537861ac','tt_content',47,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',0,0,'tx_themecamino_list_item',14,'',0,0,2147483647,0,0,''),
('83af79dd2cebb1569ddf61622df52bcb','sys_file_metadata',7,'file',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('879cee5a9571ea2e31c260bfd657420d','tt_content',49,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',2,0,'tx_themecamino_list_item',3,'',0,0,2147483647,0,0,''),
('9007b97bbb373a088e39dbfd723a9094','sys_file_metadata',6,'file',0,0,2147483647,0,'','','',0,0,'sys_file',6,'',0,0,2147483647,0,0,''),
('a584c675c94a1ae29e74f647cdb8e3b3','sys_file',4,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a67c87ac9f62a7f1f8477d8f35853aaf','sys_file_reference',3,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',8,'',0,0,2147483647,0,0,''),
('a7170607ddf8b588a1879f28dfa225c6','sys_file_reference',5,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',6,'',0,0,2147483647,0,0,''),
('a98d2d3e935306e49b97780fced304b0','tx_themecamino_list_item',15,'link',0,0,2147483647,0,'','typolink','25e6a1897ad3619758bcfedf5281f1fd:0',0,0,'tt_content',7,'',0,0,2147483647,0,0,''),
('aa9c027404b716aa2c94132d985dc844','tx_themecamino_list_item',8,'link',0,0,2147483647,0,'','typolink','df21e67c5642ee38feb58bbb600ab260:0',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('ad92a7d4a0b5d864fcd31905c0791f3b','sys_file',5,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('afe442b548425b0113fe1072b430fb3f','tx_themecamino_list_item',15,'link',0,0,2147483647,0,'','typolink','39228df5d53ff569fd165291d0a48e32:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('b29f51a7f7e6e6dcc6d99be7849ae442','sys_file',2,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b3ac640efdbf7023350fb5c607a75923','tt_content',38,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',10,'',0,0,2147483647,0,0,''),
('bcef129a645ca5cde4975849eeadb889','tx_themecamino_list_item',12,'link',0,0,2147483647,0,'','typolink','7444514527f5e6db2be78e898b8d5da3:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('c06b3c90be1682863611bc75918d070f','tt_content',47,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',8,'',0,0,2147483647,0,0,''),
('c6131865efc82ca42b51993e17ee4515','tt_content',50,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',10,'',0,0,2147483647,0,0,''),
('ce9f19b6de747ff379a24086c1985f85','sys_file_metadata',5,'file',0,0,2147483647,0,'','','',0,0,'sys_file',5,'',0,0,2147483647,0,0,''),
('d0c08436fce4ac5bda076a8eebe136a0','tt_content',48,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',2,0,'tx_themecamino_list_item',4,'',0,0,2147483647,0,0,''),
('d6c9be1c4d8ef31e0cea744886e7273f','sys_file_reference',10,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('d762da2cbea3fc2bcaf1db96ded74dd7','sys_file',3,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('d9539d399a1ad92c8fa58b3cdc7567f1','tt_content',39,'tx_themecamino_list_elements',0,0,2147483647,0,'','','',1,0,'tx_themecamino_list_item',11,'',0,0,2147483647,0,0,''),
('da3230059ca05b6c57d8a807b6ab8381','tt_content',12,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,''),
('da3d88bce1f8d47ee5763aadfab6558a','sys_file_metadata',8,'file',0,0,2147483647,0,'','','',0,0,'sys_file',8,'',0,0,2147483647,0,0,''),
('db40710ca0f77deab61c998e3707bc29','tt_content',38,'tx_themecamino_link',0,0,2147483647,0,'','typolink','80e08b6ab400a2dfffb2b7cc6fafb21e:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('dc55cca02c447704220ab80b9b8b65cb','sys_file_metadata',10,'file',0,0,2147483647,0,'','','',0,0,'sys_file',10,'',0,0,2147483647,0,0,''),
('de044d072f267b2eac888d255e170abd','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('e1bb040b8dc2858a10e771c886bd23e5','tt_content',6,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('e3595e870a8b402d8071edf4009d6ee9','tt_content',11,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,''),
('e57819c9593256ccf290e9ff8910fb40','tx_themecamino_list_item',3,'link',0,0,2147483647,0,'','typolink','1a06c9c34e36f294dbf6706741961140:0',0,0,'tt_content',2,'',0,0,2147483647,0,0,''),
('e6d1231d15b9b30923b161ff80a14ec5','sys_file_metadata',3,'file',0,0,2147483647,0,'','','',0,0,'sys_file',3,'',0,0,2147483647,0,0,''),
('f0049ad46c773201e4ec1e71e9cc52cc','tt_content',9,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('f09ff1668d77d6d56d09dc91ed6cb21b','tx_themecamino_list_item',7,'link',0,0,2147483647,0,'','typolink','9ba48aa816956a3aba306f5e3edf505b:0',0,0,'pages',7,'',0,0,2147483647,0,0,''),
('f30fad14543a4dd14ba9bb9ca05d9e5e','tt_content',7,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,0,''),
('f6062209d87aa82eace335f4ab0c7610','sys_file',10,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f65a0036c032c205fbec731c7f9abb9d','sys_file',6,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f9c64f1c71a8b40ffa94f38fcbb366b0','sys_file_metadata',1,'file',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('fa34ae3c22e0c71ffbfee202591e33d0','tt_content',15,'image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',6,'',0,0,2147483647,0,0,''),
('ff61b0bee3e2aab732905f8af0489ef7','tx_themecamino_list_item',9,'link',0,0,2147483647,0,'','typolink','a43febf660da844a7428af8808d52dd9:0',0,0,'pages',7,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsMigration','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsNormalizationMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Backend\\Upgrades\\UserSettingsScrubbingMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(12,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(13,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(14,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','theme_camino:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','theme_camino:Initialisation/dataImported','i:1;'),
(35,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','typo3/app:ext_tables_static+adt.sql','s:0:\"\";'),
(39,'core','formProtectionSessionToken:2','s:64:\"04a2d8fd95a0515df3bcb8c6d6e15ff0491de63977476e5836875353240074c9\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_themecamino_list_elements` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_themecamino_link` text NOT NULL DEFAULT '',
  `tx_themecamino_link_label` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_link_config` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_link_icon` varchar(255) NOT NULL DEFAULT '',
  `tx_themecamino_header_style` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,7,1787420770,1787420770,0,0,0,0,'',768,'',0,0,0,0,NULL,'{\"image\":\"\"}',0,0,0,0,'default',2,NULL,1,'camino_hero_small',0,0,'','',0,'Camino Route Comparison',0,'','','Which Camino is Right for You?',NULL,1,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(2,7,1787420770,1787420770,0,0,0,0,'',640,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,2,'text',0,0,'','',0,'Camino de Finisterre – The Way to the End of the World',0,'','','','<ul><li data-list-item-id=\"e6e92c6a56010a050515893fcaefde71e\">Distance: 90 km (approx. 4 days)&nbsp;</li><li data-list-item-id=\"e36427da8959003d95bee4be5f38ecc02\">Difficulty: Moderate&nbsp;</li><li data-list-item-id=\"e18ebe20575240c5671424350f877f5a4\">Best for: Pilgrims who want to continue their journey beyond Santiago de Compostela</li></ul>\n<p>The Camino de Finisterre is a natural extension of the pilgrimage for those who are not ready to stop walking. From Santiago, the route heads west through stunning coastal landscapes all the way to Cape Finisterre on the Atlantic Ocean — a place once believed by medieval pilgrims to be the very edge of the known world.</p>\n<p>Reaching the cape is a deeply moving moment. Many pilgrims mark the occasion by watching the sunset over the ocean, a fitting and unforgettable end to an extraordinary journey.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(3,7,1787420770,1787420770,0,0,0,0,'',576,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,3,'text',0,0,'','',0,'Camino Inglés – The English Way',0,'','','','<ul><li data-list-item-id=\"e5c0ffc19bf05372033315bb33cb7b4e4\">Distance: 115 km (approx. 5–7 days)&nbsp;</li><li data-list-item-id=\"e61da94bfef3a661d0d4fde9d72eecc03\">Difficulty: Easy to Moderate&nbsp;</li><li data-list-item-id=\"e7c9c2dbeab4936aa4d7e4d1e2239ce16\">Best for: Those with limited time or looking for a shorter, quieter Camino</li></ul>\n<p>The Camino Inglés starts from either A Coruña or Ferrol and offers a more compact route to Santiago without sacrificing the spirit of the pilgrimage. The path passes through small fishing villages and along beautiful coastal stretches, with a peaceful and introspective atmosphere that sets it apart from the busier routes.</p>\n<p>For those who cannot commit to a longer journey but still want a genuine Camino experience, the Inglés is an ideal choice — unhurried, scenic, and quietly rewarding.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(4,7,1787420770,1787420770,0,0,0,0,'',544,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,4,'text',0,0,'','',0,'Camino Primitivo – The Original Way',0,'','','','<ul><li data-list-item-id=\"e6dee9acdc35898b2b524076fde110e53\">Distance: 320 km (approx. 12–14 days)&nbsp;</li><li data-list-item-id=\"e32bb04cb9beca73c9821d7a5cdda6284\">Difficulty: Challenging&nbsp;</li><li data-list-item-id=\"e9a21debace0cfd3ae6179242de3ddbb6\">Best for: Adventurous pilgrims seeking solitude and a historic experience</li></ul>\n<p>The Camino Primitivo holds a special place in the history of the pilgrimage — it is the oldest of all the Camino routes, first walked by King Alfonso II in the 9th century. Beginning in Oviedo, it winds through the mountains and remote villages of Asturias and Galicia, offering a more isolated and contemplative experience with far fewer pilgrims along the way.</p>\n<p>The terrain is rugged and the climbs are demanding, but the stunning mountain scenery and sense of walking in the footsteps of the earliest pilgrims make it one of the most rewarding routes for those ready for the challenge.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(5,7,1787420770,1787420770,0,0,0,0,'',528,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,5,'text',0,0,'','',0,'Camino del Norte – The Northern Way',0,'','','','<ul><li data-list-item-id=\"eb81577a658bbaaf3cbbdea9fab1eb8e9\">Distance: 825 km (approx. 34 days)&nbsp;</li><li data-list-item-id=\"eac840a357cab461f47f7b67d0bf5efaa\">Difficulty: Challenging&nbsp;</li><li data-list-item-id=\"e146334c28aac54323aa0c8689469dc74\">Best for: Experienced walkers seeking a rugged, coastal route with fewer crowds</li></ul>\n<p>The Camino del Norte follows the northern coast of Spain along the Bay of Biscay, offering some of the most dramatic scenery of any Camino route. Steep climbs and descents through the Basque Country make it a physically demanding walk, but the reward is a quieter, more remote experience far from the busier trails further south.</p>\n<p>For experienced hikers looking for a greater challenge and a deeper sense of solitude, the Camino del Norte delivers spectacular coastal landscapes, fresh sea air, and a raw, unspoiled character that is hard to find elsewhere.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(6,7,1787420770,1787420770,0,0,0,0,'',520,'',0,0,0,0,NULL,'{\"image\":\"\"}',0,0,0,0,'default',0,NULL,6,'textpic',0,0,'','',0,'Camino Portugués – The Portuguese Way',0,'','','','<ul><li data-list-item-id=\"e3bd290e14521a07a8186e4d38d5ff2cf\">Distance: 240 km from Porto or 620 km from Lisbon (approx. 14–42 days)&nbsp;</li><li data-list-item-id=\"ee8b2be420786bfb38b1192315a1ecd4e\">Difficulty: Moderate&nbsp;</li><li data-list-item-id=\"e53b26d6545840d67b839676e852b2560\">Best for: Those seeking a quieter route, coastal scenery, or a shorter journey</li></ul>\n<p>The Camino Português winds through charming towns and villages, offering a mix of peaceful countryside and stunning coastal scenery. It is notably less crowded than the Camino Francés, giving walkers more space to set their own pace and soak in the surroundings.</p>\n<p>Starting from Porto makes it an accessible option for those with less time, while beginning in Lisbon adds weeks of rich Portuguese landscapes and culture to the journey. Either way, it is a beautiful and rewarding route with a gentler, more relaxed atmosphere all the way to Santiago.</p>',1,0,NULL,NULL,26,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(7,7,1787420770,1787420770,0,0,0,0,'',516,'',0,0,0,0,NULL,'{\"image\":\"\"}',0,0,0,0,'default',0,NULL,7,'textpic',0,0,'','',0,'Camino Francés – The French Way',0,'','','','<ul><li data-list-item-id=\"e4427baccbfa326757c83a5dd887cb2ed\">Distance: approx. 800 km from Saint-Jean-Pied-de-Port (approx. 30–35 days)&nbsp;</li><li data-list-item-id=\"e808930077fe600a2c17c905a302e26ee\">Difficulty: Moderate to challenging&nbsp;</li><li data-list-item-id=\"e7cb7a708fe43a9546e95a7280f3fd2c2\">Best for: First-time pilgrims seeking the classic Camino experience, iconic landmarks, and a vibrant walking community</li></ul>\n<p>The Camino Francés passes through some of the most iconic towns along any Camino route, including Pamplona, Burgos, and León. The landscape shifts from the lush green hills of the Pyrenees through vineyards and rolling countryside all the way to Galicia. With a lively atmosphere and a constant stream of fellow pilgrims, it is a route where community and connection come naturally.</p>\n<p>As the most popular and best-supported route, the Camino Francés is an ideal choice for first-time pilgrims. Paths are well marked, accommodation is plentiful, and there is always someone to walk alongside.</p>',1,0,NULL,NULL,25,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(8,7,1787420770,1787420770,0,0,0,0,'',514,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,8,'text',0,0,'','',0,'',2,'','','','<p>Choosing the right Camino route depends on your fitness level, the time you have available, and what you are hoping to get out of the experience. Whether you are drawn to dramatic coastlines, mountain solitude, or the bustle of a well-travelled trail, there is a route that fits. Here is a comparison of the main routes to help you find the one that suits you best.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',1),
(9,7,1787420770,1787420770,0,0,0,0,'',513,'',0,0,0,0,NULL,'{\"image\":\"\"}',0,0,0,0,'default',1,NULL,9,'camino_textmedia_teaser',0,0,'','',0,'Where Every Path Leads Somewhere New',0,'','','Nature & Landscape','<p>Rolling green hills, ancient forest tracks, and winding paths stretching endlessly ahead — the Camino de Santiago is as much about the landscape as the destination. Lace up your boots and let the trail do the rest.</p>',1,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','','',0),
(10,7,1787420770,1787420770,0,0,0,0,'',512,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'bg-100',1,NULL,10,'camino_textteaser',0,0,'','',0,'Pack Light, Walk Far',0,'','','Everything you need fits in one bag','<p>The Camino teaches you quickly that less is more. A well-chosen pack makes the difference between a joyful walk and a painful one. Discover our curated guide to Camino essentials and start your journey the right way.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(11,7,1787420770,1787420770,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"image\":\"\"}',0,0,0,0,'default',1,NULL,11,'camino_author',0,0,'','',0,'Elena Vásquez',0,'','',' Senior Camino Guide','The Camino does not care how fast you walk or how far you have come. It only asks that you keep going.',1,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','','',0),
(12,6,1787420770,1787420770,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"image\":\"\"}',0,0,0,0,'default',2,NULL,12,'camino_hero_small',0,0,'','',0,'Packing List',0,'','','for the Camino de Compostela',NULL,1,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(13,6,1787420770,1787420770,0,0,0,0,'',128,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'bg-10',0,NULL,13,'text',0,0,'','',0,'',2,'','','','<p>Remember: the key is to <strong>pack light</strong>. The Camino is not about material comforts — it is about the experience. Every item in your pack will be carried on your back for hundreds of kilometres, so when in doubt, leave it out. Keep it simple and let the journey speak for itself.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(14,6,1787420770,1787420770,0,0,0,0,'',64,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,14,'text',0,0,'','',0,'Optional Items',0,'','','','<p>Not essential, but worth considering depending on your preferences and the route you choose:</p>\n<ul><li data-list-item-id=\"eacc438e6b010624af619e33aea8d7f53\"><strong>Camera or GoPro</strong>: for capturing the stunning landscapes and memorable moments along the way</li><li data-list-item-id=\"e40d2f2a97b58000c944eb097b5ad2cfa\"><strong>Guidebook or map</strong>: helpful for planning daily stages and finding points of interest</li><li data-list-item-id=\"e72197f18bbaa28f23c1afe54a99d2fee\"><strong>Earplugs</strong>: a small but invaluable addition for sleeping in shared albergue dormitories</li><li data-list-item-id=\"e05a98d0eda19fb24b1a70b6822dc4336\"><strong>Thermal blanket</strong>: lightweight and compact, useful to have in case of unexpected weather or emergencies</li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(15,6,1787420770,1787420770,0,0,0,0,'',32,'',0,0,0,0,NULL,'{\"image\":\"\"}',0,0,0,0,'default',0,NULL,15,'textpic',0,0,'','',0,'Other Important Items',0,'','','','<p>A few practical essentials to round out your pack:</p>\n<ul><li data-list-item-id=\"eff2ca7f64d3e4c62ac51e6a471392f37\"><strong>Pilgrim\'s Credential</strong>: obtain this before setting off or at the first pilgrim office along the route — you will need it for stamps and albergue access</li><li data-list-item-id=\"e83b3d1cd22726e873f3698300ec0744d\"><strong>Phone and charger</strong>: useful for navigation, weather updates, and emergency contacts</li><li data-list-item-id=\"e9ffed5af0376900e1078d244c05dc80e\"><strong>Money</strong>: carry euros for daily expenses such as food and accommodation; card payments are widely accepted but cash is handy in smaller villages</li><li data-list-item-id=\"ed3851938702e8d268645d2fe9dba5a6c\"><strong>Camera</strong>: for capturing the landscapes, people, and moments along the way</li><li data-list-item-id=\"e34c75dfcca847ccf1751d024315e7ac0\"><strong>Notebook and pen</strong>: many pilgrims find value in documenting their journey as they go</li></ul>',1,0,NULL,NULL,28,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(16,6,1787420770,1787420770,0,0,0,0,'',16,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,16,'text',0,0,'','',0,'Extras',0,'','','','<p>A few small additions that can make a big difference on the trail:</p>\n<ul><li data-list-item-id=\"ebf9c2c43f0cf7f0c05d3652cd0ed6fb0\"><strong>Sunscreen and lip balm</strong>: SPF 30 or higher, reapply regularly on exposed stretches</li><li data-list-item-id=\"e66fd2e7dfdf36ed675ed47cd7f5156f2\"><strong>First aid kit</strong>: plasters, blister pads, pain relievers, and antiseptic cream at a minimum</li><li data-list-item-id=\"e086f0bbf6d52516c9d55389f343cb0bc\"><strong>Water bottle or hydration system</strong>: refill points are available along most routes</li><li data-list-item-id=\"e8578c0f2337475c2943eaf8df9df9026\"><strong>Headlamp</strong>: essential for early morning starts and late arrivals into town</li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(17,6,1787420770,1787420770,0,0,0,0,'',8,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,17,'text',0,0,'','',0,'Toiletries',0,'','','','<p>Keep it minimal and travel-sized — most albergues have basic facilities, and resupplying along the way is easy:</p>\n<ul><li data-list-item-id=\"e546ea834a98ec12e20c994e5e6448687\"><strong>Toothbrush and toothpaste</strong>: travel-sized</li><li data-list-item-id=\"e50afffb16a817156e2e187604331dc48\"><strong>Soap and shampoo</strong>: travel-sized and eco-friendly where possible</li><li data-list-item-id=\"e7f3eec303d72c3cc43921cb4a8dff697\"><strong>Toilet paper</strong>: a small roll or pocket tissues for emergencies</li><li data-list-item-id=\"e444b626ad96e7bcfb4d82e69dc1920bd\"><strong>Hand sanitizer</strong>: essential for days when facilities are limited</li><li data-list-item-id=\"e694760d1f86e9d075a60277788fbb8db\"><strong>Wet wipes</strong>: handy for freshening up when a shower is not an option</li><li data-list-item-id=\"e3b197e27a695e56b7b6f56f0eaa625eb\"><strong>Towel</strong>: quick-dry and compact</li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(18,6,1787420770,1787420770,0,0,0,0,'',4,'',0,0,0,0,NULL,'{\"image\":\"\"}',0,0,0,0,'default',0,NULL,18,'textpic',0,0,'','',0,'Clothing',0,'','','','<p>Pack light and stick to quick-dry fabrics — cotton traps moisture and is best avoided on the trail:</p>\n<ul><li data-list-item-id=\"e3495eeaae4997ffdd6aff9b10184b4e8\"><strong>T-shirts or shirts</strong>: 2–3, quick-dry fabric</li><li data-list-item-id=\"e2e4c302516a61547b324e23c0f1024b6\"><strong>Lightweight pants or shorts</strong>: 2 pairs</li><li data-list-item-id=\"e6045c5b158fa479cca22d5949c489d87\"><strong>Long-sleeve shirt</strong>: 1, for sun protection or chilly evenings</li><li data-list-item-id=\"e9418477ccb4d8e368d4aae08d0f0c1a1\"><strong>Lightweight fleece or jacket</strong>: 1</li><li data-list-item-id=\"e1dc2be38200268e61a3e2bffad13ee27\"><strong>Underwear</strong>: 1–2 sets, quick-dry</li><li data-list-item-id=\"e01c8896728c1287c584822be0bb2e0c2\"><strong>Hat or cap</strong>: 1, for sun protection</li><li data-list-item-id=\"ebadc68e7d0ad77537ba7474b65b3b417\"><strong>Waterproof jacket or poncho</strong>: essential — rain is common, especially in Galicia</li><li data-list-item-id=\"e5eef70e8621b31b9989e7008c0bf3f5d\"><strong>Buff or bandana</strong>: useful for sweat, dust, or extra sun protection</li></ul>',1,0,NULL,NULL,27,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(19,6,1787420770,1787420770,0,0,0,0,'',2,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,19,'text',0,0,'','',0,'Essential Items',0,'','','','<p>Before anything else, get these right — your feet and your back will thank you for it:</p>\n<ul><li data-list-item-id=\"ea0427b43077372393b9d74d2ecb12e9d\"><strong>Backpack (35–45L):</strong> light and comfortable with good back support and a rain cover</li><li data-list-item-id=\"ef8630e9da533c2be3fe4318cf443e4c0\"><strong>Walking shoes</strong>: well-worn hiking shoes or sturdy walking shoes, waterproof if possible</li><li data-list-item-id=\"e5bcfee4b8cce09f26e9478d3b29903c6\"><strong>Sandals</strong>: lightweight, for after the day\'s walk and shared showers in albergues</li><li data-list-item-id=\"e76ecc1b2981aec46f6bafa8e9306a630\"><strong>Walking socks</strong>: moisture-wicking and blister-resistant, merino wool or synthetic, several pairs</li><li data-list-item-id=\"e16e210e4038894be103a5edc1f216016\"><strong>Walking poles</strong>: optional but helpful for steep descents and taking pressure off the knees</li></ul>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(20,6,1787420770,1787420770,0,0,0,0,'',1,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,20,'text',0,0,'','',0,'',0,'','','','<p>Walking the Camino de Compostela means traveling light — every gram counts when you are covering hundreds of kilometres on foot. Here is a comprehensive packing list to help you prepare for the journey ahead, so you can focus on the walk and leave the worrying behind.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(21,5,1787420770,1787420770,0,0,0,0,'',768,'',0,0,0,0,NULL,'{\"image\":\"\"}',0,0,0,0,'default',2,NULL,21,'camino_hero_small',0,0,'','',0,'FAQs',0,'','','Everything You Need to Know About the Camino de Compostela',NULL,1,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(22,5,1787420770,1787420770,0,0,0,0,'',640,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,22,'text',0,0,'','',0,'What is the Pilgrim\'s Credential and how do I get one?',0,'','','','<p>The <strong>Pilgrim\'s Credential</strong>, or <strong>Credencial del Peregrino</strong>, is a document you collect stamps in as you progress along the route. It is required for staying in albergues and serves as proof of your journey when collecting your <strong>Compostela Certificate</strong> upon arrival in Santiago.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(23,5,1787420770,1787420770,0,0,0,0,'',576,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,23,'text',0,0,'','',0,'What should I do if I cannot finish the Camino?',0,'','','','<p>Completing the entire route is not a requirement. Many pilgrims walk only a section of the Camino, and even a few days on the trail can be a meaningful and rewarding experience. There is no right or wrong way to walk it.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(24,5,1787420770,1787420770,0,0,0,0,'',544,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,24,'text',0,0,'','',0,'Do I need to book accommodations in advance?',0,'','','','<p>During quieter seasons, advance booking is generally not necessary. However, if you are walking in summer or on a popular route such as the Camino Francés, booking ahead is recommended to secure your spot.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(25,5,1787420770,1787420770,0,0,0,0,'',528,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,25,'text',0,0,'','',0,'How do I navigate the Camino?',0,'','','','<p>The routes are well marked with <strong>yellow arrows</strong> and <strong>scallop shell symbols</strong>, making it difficult to lose your way. Guidebooks, apps, and printed maps are also widely available to help you plan and navigate each stage.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(26,5,1787420770,1787420770,0,0,0,0,'',520,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,26,'text',0,0,'','',0,'What are the accommodations like?',0,'','','','<p>Most pilgrims stay in <strong>albergues</strong> — simple, affordable pilgrim hostels located along the route. Guesthouses and hotels are also available for those who prefer more comfort, and some pilgrims choose to camp along the way.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(27,5,1787420770,1787420770,0,0,0,0,'',516,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,27,'text',0,0,'','',0,'Is the Camino suitable for beginners?',0,'','','','<p>Yes. The Camino is accessible to walkers of all levels. You do not need to be an experienced hiker — just have the right gear, a reasonable level of fitness, and the determination to keep going. Most routes involve daily walks of between 15 and 30 km on well-maintained paths.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(28,5,1787420770,1787420770,0,0,0,0,'',514,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,28,'text',0,0,'','',0,'Do I need to be religious to walk the Camino?',0,'','','','<p>Not at all. While the Camino has deep spiritual roots, it is open to everyone. People of all faiths — and none — walk it for a wide range of reasons, from personal growth and adventure to connection and reflection.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(29,5,1787420770,1787420770,0,0,0,0,'',513,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,29,'text',0,0,'','',0,'How long does it take to walk the Camino?',0,'','','','<p>The time it takes depends on the route and your walking pace. The Camino Francés, the most popular route, takes around <strong>30 to 35 days</strong> from Saint-Jean-Pied-de-Port to Santiago. Those walking shorter sections can complete their journey in one to two weeks.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(30,5,1787420770,1787420770,0,0,0,0,'',512,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,30,'text',0,0,'','',0,'What is the Camino de Compostela?',0,'','','','<p>The Camino de Compostela, or Way of St. James, is a network of ancient pilgrimage routes leading to Santiago de Compostela in Spain. It has been a major spiritual and cultural route for over a thousand years, drawing pilgrims from all corners of the world.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(31,5,1787420770,1787420770,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'bg-100',1,NULL,31,'camino_textteaser',0,0,'','',0,'Buen Camino Starts With Good Gear',2,'','','What to pack and what to leave behind','<p>The right boots, the right pack, and a little preparation can make all the difference. Discover our essential packing guide before you hit the trail.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(32,5,1787420770,1787420770,0,0,0,0,'',128,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'bg-10',1,NULL,32,'camino_textteaser',0,0,'','',0,'Walk at Your Own Pace',2,'','','No experience required','<p>The Camino welcomes everyone — seasoned hikers and first-time walkers alike. Find the route that matches your fitness, your time, and your spirit.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(33,5,1787420770,1787420770,0,0,0,0,'',64,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"rowDescription\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'bg-80',1,NULL,33,'camino_textteaser',0,0,'','',0,'Your First Step Starts Here',2,'','',' Plan your Camino','<p>Not sure where to begin? Our route guides, packing tips, and practical advice have everything you need to plan your first Camino with confidence.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(34,4,1787420770,1787420770,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"rowDescription\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',2,NULL,34,'camino_hero_text_only',0,0,'','',0,'Imprint',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','0',0),
(35,4,1787420770,1787420770,0,0,0,0,'',128,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,35,'text',0,0,'','',0,'',0,'','','','<p><strong>Company Information</strong><br />[Company Name]<br />[Street Address]<br />[ZIP Code, City]<br />[Country]</p>\n<p><strong>Represented by</strong>:&nbsp;<br />[Name], [Position]</p>\n<p><strong>Contact</strong>:&nbsp;<br />Phone: [+00 000 000000]<br />Email: [email@example.com]<br />Website: [www.example.com]</p>\n<p><strong>Commercial Register</strong>: [Register Court] [Registration Number]<br /><strong>VAT Identification Number</strong>: [VAT ID]</p>\n<p><strong>Responsible for content</strong>:<br />[Name]<br />[Street Address]<br />[ZIP Code, City]</p>\n<p><strong>Disclaimer</strong>:<br />This is dummy content for demonstration purposes only. Please replace all placeholder fields marked with [brackets] with your actual company information before publishing. The disclaimer text below should also be reviewed and adapted to your legal requirements.</p>\n<p>The contents of this website have been created with the utmost care. However, we cannot guarantee the accuracy, completeness, or timeliness of the information provided. External links have been checked at the time of linking; we accept no responsibility for their content.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(36,3,1787420770,1787420770,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"rowDescription\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',2,NULL,36,'camino_hero_text_only',0,0,'','',0,'Privacy',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','0',0),
(37,3,1787420770,1787420770,0,0,0,0,'',128,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,37,'text',0,0,'','',0,'',0,'','','','<p><strong>Privacy Policy</strong></p>\n<p><i>This is dummy content for demonstration purposes only. Please replace all placeholder fields marked with [brackets] with your actual information and have this policy reviewed by a legal professional before publishing.</i></p>\n<p><strong>1. Data Controller</strong></p>\n<p>[Company Name] [Street Address] [ZIP Code, City] [Country]<br />Email: [email@example.com] Phone: [+00 000 000000]</p>\n<p><strong>2. What Data We Collect</strong></p>\n<p>We may collect the following types of personal data:</p>\n<ul><li data-list-item-id=\"e73f7ed080829a7ac2cac007851b4ae14\">Name and contact information (e.g. email address, phone number)</li><li data-list-item-id=\"eb0a6937c4dcdde11e1e7b931d167e055\">Usage data (e.g. IP address, browser type, pages visited)</li><li data-list-item-id=\"ecaca2c0bde0d835147d1d1224e40eeb7\">Data you provide voluntarily via contact forms or newsletter sign-ups</li></ul>\n<p><strong>3. How We Use Your Data</strong></p>\n<p>We use your data to:</p>\n<ul><li data-list-item-id=\"e0968fad6a96fb360521235e775efe232\">Provide and improve our services</li><li data-list-item-id=\"ea6e7a178a7483e7bd304fa48e40bc95d\">Respond to your enquiries</li><li data-list-item-id=\"ea10996ff2384057302f3e1c1335c9039\">Send newsletters or updates (only with your consent)</li><li data-list-item-id=\"eae60168359bdcdb66d48e71ee7ec76ba\">Comply with legal obligations</li></ul>\n<p><strong>4. Legal Basis for Processing</strong></p>\n<p>We process your data on the following legal bases under GDPR Art. 6:</p>\n<ul><li data-list-item-id=\"ec27dc6763480f01e298ddf7cdfdebef5\">[Consent / Contract / Legal obligation / Legitimate interest — choose as applicable]</li></ul>\n<p><strong>5. Data Sharing</strong></p>\n<p>We do not sell your personal data. We may share data with [third-party service providers, e.g. hosting, analytics] only as necessary to operate our services.</p>\n<p><strong>6. Cookies</strong></p>\n<p>This website uses cookies. [Describe your cookie usage here or refer to a separate cookie policy.]</p>\n<p><strong>7. Data Retention</strong></p>\n<p>We retain personal data only for as long as necessary for the purposes stated above or as required by law. [Specify retention periods where applicable.]</p>\n<p><strong>8. Your Rights</strong></p>\n<p>Under applicable data protection law you have the right to:</p>\n<ul><li data-list-item-id=\"efb0e8b720a64d18529aaa52d599138ac\">Access your personal data</li><li data-list-item-id=\"e649073f2c3af6b9b76d808c2f4fdae7d\">Request correction or deletion</li><li data-list-item-id=\"e50465a90f09b896b022b6dc6f2069c5d\">Object to or restrict processing</li><li data-list-item-id=\"e8caaadbefc61a346dc99a4e58fca72ef\">Data portability</li><li data-list-item-id=\"e346f5fc748730cb30e43802b58ffdd5d\">Lodge a complaint with a supervisory authority</li></ul>\n<p>To exercise your rights, contact us at: [email@example.com]</p>\n<p><strong>9. Changes to This Policy</strong></p>\n<p>We may update this privacy policy from time to time. The current version is always available on this page.</p>\n<p><strong>Last updated:</strong> [Date]</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(38,1,1787420770,1787420770,0,0,0,0,'',768,'',0,0,0,0,NULL,'{\"tx_themecamino_link\":\"\"}',0,0,0,0,'default',2,NULL,38,'camino_hero',0,0,'','',0,'Walk the Camino de Compostela',2,'','','A journey of discovery, history, and transformation',NULL,1,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'7','','0','chevron-right',0),
(39,1,1787420770,1787420770,0,0,0,0,'',640,'',0,0,0,0,NULL,'{\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',11,NULL,39,'camino_sociallinks',0,0,'','',0,'Social Media Icons',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,3,'','','','',0),
(40,1,1787420770,1787420770,0,0,0,0,'',576,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'bg-80',0,NULL,40,'text',0,0,'','',0,'Start Your Camino',0,'','','','<p>Whether you walk for a week or a month, alone or with friends, the Camino meets you exactly where you are. There is no right or wrong way to walk it — only your way.</p>\n<p>Buen Camino.&nbsp;<br />Your journey begins with a single step.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(41,1,1787420770,1787420770,0,0,0,0,'',544,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,41,'text',0,0,'','',0,'Santiago de Compostela',0,'','','','<p>Arriving in <strong>Santiago de Compostela</strong> is a moment many pilgrims never forget. The main square fills with walkers from all over the world, coming together to celebrate, reflect, and attend the Pilgrim\'s Mass at the magnificent cathedral.</p>\n<p>Here you receive your <strong>Compostela Certificate</strong>, the official recognition of your journey. But for many, reaching Santiago is not an ending — it is the beginning of something that continues long after the walk is over.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(42,1,1787420770,1787420770,0,0,0,0,'',528,NULL,0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,42,'text',0,0,'','',0,'Preparing for the Camino',0,'','','','<p><strong>When to Go</strong></p>\n<p>Spring (April to June) is a favourite time to walk, with mild weather and blooming landscapes along the way. Autumn (September to October) offers cooler temperatures and fewer crowds, making it another excellent choice. Summer is popular but can be hot and busy, while winter is quiet and reflective — rewarding for those prepared for more challenging conditions.</p>\n<p><strong>What to Pack</strong></p>\n<p>Good preparation starts with comfortable walking shoes and a lightweight backpack. Bring weather-appropriate clothing and don\'t forget your Pilgrim Credential, used to collect stamps along the way and access pilgrim accommodation.</p>\n<p>Less is more on the Camino.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(43,1,1787420770,1787420770,0,0,0,0,'',520,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'bg-10',0,NULL,43,'text',0,0,'','',0,'What to Expect on the Camino',0,'','','','<p>Daily walks typically range from 15 to 30 km, with well-waymarked paths guided by yellow arrows and scallop shells. Accommodation options are plentiful, from affordable albergues to guesthouses and hotels, and the food along the way is simple, hearty, and full of regional character. More than anything, the Camino invites you into a slower, more mindful pace of life.</p>\n<p>No special training is required — just preparation, curiosity, and an open heart.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(44,1,1787420770,1787420770,0,0,0,0,'',516,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,44,'text',0,0,'','',0,'Why Walk the Camino?',0,'','','','<p><strong>A Personal Journey&nbsp;</strong><br />Many pilgrims describe the Camino as a life-changing experience. Walking day after day creates space for reflection, clarity, and personal growth — a rare opportunity to step away from the noise of everyday life.</p>\n<p><strong>History and Culture&nbsp;</strong><br />The routes are lined with Roman roads, medieval bridges, ancient churches, and UNESCO World Heritage sites, offering a rich journey through centuries of European history and tradition.</p>\n<p><strong>Community and Connection&nbsp;</strong><br />On the Camino, you are never truly alone. Friendships form naturally, languages mix freely, and shared meals around a table become memories that last long after the journey ends.</p>\n<p><strong>Nature and Simplicity&nbsp;</strong><br />From vineyards and forests to mountain passes and rugged coastlines, the Camino offers a chance to reconnect with the natural world — and with yourself.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(45,1,1787420770,1787420770,0,0,0,0,'',514,'',0,0,0,0,NULL,'{\"tx_themecamino_link\":\"\"}',0,0,0,0,'bg-80',0,NULL,45,'camino_textmedia_teaser_grid',0,0,'','',0,'The Main Camino Routes',0,'','','','<p>The Camino de Compostela is a network of ancient pilgrimage routes, each leading to the Cathedral of Santiago de Compostela. Whether crossing mountain passes, following coastal paths, or winding through rolling countryside, every route has its own character and charm — yet all share the same spirit of community, discovery, and adventure.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,5,'7','Compare all routes','0','',0),
(46,1,1787420770,1787420770,0,0,0,0,'',513,'',0,0,0,0,NULL,'{\"CType\":\"\",\"bodytext\":\"\",\"categories\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"l10n_source\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\",\"tx_impexp_origuid\":\"\",\"tx_themecamino_header_style\":\"\",\"tx_themecamino_link\":\"\",\"tx_themecamino_link_config\":\"\",\"tx_themecamino_link_icon\":\"\",\"tx_themecamino_link_label\":\"\"}',0,0,0,0,'default',0,NULL,46,'text',0,0,'','',0,'What Is the Camino de Compostela?',0,'','','','<p>The <strong>Camino de Compostela</strong>, also known as the <strong>Way of St. James</strong>, is one of the world\'s most famous pilgrimage routes. It leads to the Cathedral of Santiago de Compostela in northwestern Spain, where the remains of Saint James the Apostle are said to rest.</p>\n<p>People from all walks of life travel the Camino:</p>\n<ul><li data-list-item-id=\"e7cee5c5bef25604019f517e8b2c2543e\">Pilgrims and spiritual seekers</li><li data-list-item-id=\"ec742dc56cc6562510e5fb39fdcc61014\">Hikers and outdoor enthusiasts</li><li data-list-item-id=\"e84898458aaab86be9e7c85024d176b48\">Cultural travelers and history lovers</li></ul>\n<p>For many, it is more than just a journey — it is an experience that stays with them long after they return home.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,0,'','','0','',0),
(47,1,1787420770,1787420770,0,0,0,0,'',512,'',0,0,0,0,NULL,'{\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',10,NULL,47,'camino_linklist',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,2,'','','','',0),
(48,1,1787420770,1787420770,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',12,NULL,48,'camino_linklist',0,0,'','',0,'Camino Routes',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,3,'','','','',0),
(49,1,1787420770,1787420770,0,0,0,0,'',128,NULL,0,0,0,0,NULL,'{\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',13,NULL,49,'camino_linklist',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,3,'','','','',0),
(50,1,1787420770,1787420770,0,0,0,0,'',64,NULL,0,0,0,0,NULL,'{\"tx_themecamino_list_elements\":\"\"}',0,0,0,0,'default',14,NULL,50,'camino_linklist',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,2,'','','','',0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tx_themecamino_list_item`
--

DROP TABLE IF EXISTS `tx_themecamino_list_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_themecamino_list_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `fieldname` varchar(255) NOT NULL DEFAULT '',
  `category` varchar(50) NOT NULL DEFAULT '',
  `date` bigint(20) DEFAULT NULL,
  `header` varchar(255) NOT NULL DEFAULT '',
  `images` int(10) unsigned NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `link_config` varchar(255) NOT NULL DEFAULT '',
  `link_icon` varchar(255) NOT NULL DEFAULT '',
  `link_label` varchar(255) NOT NULL DEFAULT '',
  `text` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_themecamino_list_item`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tx_themecamino_list_item` WRITE;
/*!40000 ALTER TABLE `tx_themecamino_list_item` DISABLE KEYS */;
INSERT INTO `tx_themecamino_list_item` VALUES
(1,1,1787420770,1787420770,0,0,5,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,45,'tt_content','tx_themecamino_list_elements','',NULL,'Camino Inglés & Other Routes',0,'7#3','','','More','The Camino Inglés and several other lesser-known routes offer a wonderful alternative for those with limited time. Each has its own distinct character, landscapes, and history, making them a rewarding choice even for a shorter pilgrimage. No matter which route you choose, the spirit of the Camino remains the same.'),
(2,1,1787420770,1787420770,0,0,4,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,45,'tt_content','tx_themecamino_list_elements','',NULL,'Camino Primitivo',0,'7#4','','','More','The Camino Primitivo is the oldest of all the Camino routes, tracing the original path walked by pilgrims centuries ago. Shorter than the Camino Francés but more physically demanding, it winds through the mountains and forests of Asturias and Galicia. It is a rewarding choice for experienced walkers who prefer solitude and a deeper sense of history along the way.'),
(3,1,1787420770,1787420770,0,0,3,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,49,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'7#2','','','Camino de Finisterre',NULL),
(4,1,1787420770,1787420770,0,0,3,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,48,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'7#5','','','Camino del Norte',NULL),
(5,1,1787420770,1787420770,0,0,3,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,39,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.youtube.com/@typo3','','','YouTube',NULL),
(6,1,1787420770,1787420770,0,0,3,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,45,'tt_content','tx_themecamino_list_elements','',NULL,'Camino del Norte',0,'7#5','','','More','The Camino del Norte traces the northern coast of Spain, offering dramatic ocean views and rugged, unspoiled landscapes. It is a more demanding route than some of the other Caminos, but rewards those who walk it with stunning scenery and a quieter, more solitary experience away from the larger crowds.'),
(7,1,1787420770,1787420770,0,0,2,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,49,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'7#3','','','Camino Inglés',NULL),
(8,1,1787420770,1787420770,0,0,2,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,47,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'3','','','',NULL),
(9,1,1787420770,1787420770,0,0,2,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,48,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'7#6','','','Camino Portugués',NULL),
(10,1,1787420770,1787420770,0,0,2,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,50,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'5','','','FAQs',NULL),
(11,1,1787420770,1787420770,0,0,2,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,39,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.facebook.com/typo3','','','Facebook',NULL),
(12,1,1787420770,1787420770,0,0,2,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,45,'tt_content','tx_themecamino_list_elements','',NULL,'Camino Portugués',0,'7#6','','','More','The Camino Português begins in either Lisbon or Porto and makes its way north through Portugal into Galicia. It is known for its coastal scenery, charming towns, and the warm hospitality of its people. With a gentler walking profile, it is a popular choice for those looking for a less demanding but equally rewarding journey.'),
(13,1,1787420770,1787420770,0,0,1,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,49,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'7#4','','','Camino Primitivo',NULL),
(14,1,1787420770,1787420770,0,0,1,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,47,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'4','','','',NULL),
(15,1,1787420770,1787420770,0,0,1,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,48,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'7#7','','','Camino Francés',NULL),
(16,1,1787420770,1787420770,0,0,1,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,50,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'6','','','Packing List',NULL),
(17,1,1787420770,1787420770,0,0,1,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,39,'tt_content','tx_themecamino_list_elements','',NULL,'',0,'https://www.instagram.com/typo3_official/','','','Instagram',NULL),
(18,1,1787420770,1787420770,0,0,1,0,0,0,NULL,'{\"link\":\"\"}',0,0,0,0,45,'tt_content','tx_themecamino_list_elements','',NULL,'Camino Francés',0,'7#7','','','More','The Camino Francés is the most popular route, beginning in Saint-Jean-Pied-de-Port in southern France before crossing the Pyrenees and winding through northern Spain. It passes through historic towns and vibrant villages, with well-established pilgrim services and a lively trail community all the way to Santiago.');
/*!40000 ALTER TABLE `tx_themecamino_list_item` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-08-22 19:54:37
